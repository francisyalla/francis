package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.dao.ProductDAO;
import com.capgemini.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
	ProductDAO productDAO = new ProductDAO();
	
	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		return productDAO.updateProducts(Category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		return productDAO.getProductDetails();
	}
	
	public boolean isHikeValid(int hike) throws ProductException
	{
		boolean hikeValid = false;
		if(hike<0)
		{
			throw new ProductException("Hike should be Greater than Zero");
		}
		else
		{
			hikeValid = true;
		}
		return hikeValid;
	}
	
	public boolean isCategoryValid(String category) throws ProductException
	{
		boolean categoryValid = false;
		if(!productDAO.isCategoryValid(category))
		{
			throw new ProductException("This Category Does Not Exist");
		}
		else
		{
			categoryValid = true;
		}
		return categoryValid;
	}
	
}

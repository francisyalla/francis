package com.capgemini.productmgmt.bean;

public class Product {
	
	private String productName;
	private int productPrice;
	private String productCategory;
	
	public Product() {
		super();
	}

	public Product(String productName, int productPrice, String productCategory) {
		super();
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	@Override
	public String toString() {
		return "Product [productName=" + productName + ", productPrice=" + productPrice + ", productCategory="
				+ productCategory + "]";
	}
	
}

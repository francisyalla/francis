package com.capgemini.productmgmt.exception;
/**
 * 
 * @author anudhawa
 *
 */
public class ProductException extends Exception {

	/**
	 * Exception Class
	 */
	private static final long serialVersionUID = 1L;
	public ProductException(String message)
	{
		super(message);
	}
}

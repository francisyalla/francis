package com.capgemini.realestatebean;

public class FlatOwner {
private int ownerId;
private String ownerName;
private long ownerNum;
public FlatOwner() {
	super();
	// TODO Auto-generated constructor stub
}
public FlatOwner(int ownerId, String ownerName, long ownerNum) {
	super();
	this.ownerId = ownerId;
	this.ownerName = ownerName;
	this.ownerNum = ownerNum;
}
public int getOwnerId() {
	return ownerId;
}
public void setOwnerId(int ownerId) {
	this.ownerId = ownerId;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public long getOwnerNum() {
	return ownerNum;
}
public void setOwnerNum(long ownerNum) {
	this.ownerNum = ownerNum;
}
@Override
public String toString() {
	return "FlatOwner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownerNum=" + ownerNum + "]";
}

}

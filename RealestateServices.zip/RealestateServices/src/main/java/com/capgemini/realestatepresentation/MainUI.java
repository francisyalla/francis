package com.capgemini.realestatepresentation;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.realestatebean.RealestateBean;
import com.capgemini.realestateservice.*;
import com.capgemini.registrationexception.RegistrationException;
public class MainUI {
	/**
	 * 
	 * @author karkovvu
	 * @version 1.0
	 * This is MainUI class taking user inputs
	 */
	/**
	 * Customerservice object initialized to call service method
	 * @param args
	 * @throws RegistrationException 
	 */
		public static void main(String[] args) throws RegistrationException {

			String continueChoice;
			boolean continueValue = false;

			RealestateService service = new RealestateServiceImpl();
			Scanner scanner = new Scanner(System.in);
			Scanner scanner1 = new Scanner(System.in);
			do {

				System.out.println("****  Welcome to Flat Registration **** ");
				System.out.println("1.Register Flat ");
				System.out.println("2.display Flat Registration Details");
				System.out.println("3.exit");

			

				int choice = 0;
				boolean choiceFlag = false;

				do {
					
					System.out.println("Enter your choice");
					try {
						choice = scanner.nextInt();
						choiceFlag = true;

						
						boolean NameFlag = false;
						int Type = 0;
						switch (choice) {

						case 1:
							do {
								try {
									ArrayList<Integer> ownerId=service.getAllOwnerIds();
									System.out.println("existing owner Id are:"+ownerId);
								} catch (RegistrationException e) {
									e.printStackTrace();
								}
								System.out.println("enter your ownerId:");
								int id=scanner.nextInt();
								
								System.out.println("Enter  Falt Type(1-1BHK,2.-2BHK):");
								
								try {
									Type = scanner1.nextInt(); 
								} catch (InputMismatchException e) {
									e.getMessage();
								}
								NameFlag=true;
								/*try {
									service.validate Name( Name);
									NameFlag = true;
								} catch (Exception e) {
									NameFlag = false;
									System.err.println(e.getMessage());
								}*/
							} while (!NameFlag);

							int Area = 0;
							boolean AreaFlag = false;
							do {
							
								System.out.println("Enter  FlatArea:");
								try {
									Area = scanner.nextInt();
									//service.validateArea(Area);
									AreaFlag = true;
								} catch (InputMismatchException e) {
									AreaFlag = false;
									System.err.println("Cost should be in digits");
								}
							} while (!AreaFlag);
							
							double Rent = 0;
							boolean RentFlag = false;
							do {
							
								System.out.println("Enter  Flat Rent:");
								try {
									Rent = scanner.nextDouble();
									RentFlag = true;
								} catch (InputMismatchException e) {
									RentFlag = false;
									System.err.println("Cost should be in digits");
								}
							} while (!RentFlag);
							double Deposit = 0;
							boolean DepositFlag = false;
							do {
							
								System.out.println("Enter  Flat Deposit:");
								try {
									Deposit = scanner.nextDouble();
									//service.validateCost(vehicleCost);
									DepositFlag = true;
								} catch (InputMismatchException e) {
									DepositFlag = false;
									System.err.println("Cost should be in digits");
								}
							} while (!DepositFlag);



							RealestateBean register = new RealestateBean(Type, Area, Rent,Deposit);
	                      /**
			        * adddetails() take inputs for customer registration.
			        */

							try {
								RealestateBean id1 = service.registerFlat(register);
								System.out.println("Flat registered succesfully: " + id1.getFlatId());
					} catch (RegistrationException e) {
								System.err.println(e.getMessage());
							}

							break;

						case 2:
							System.out.println("Flat Details are");
							
	                           
								Map<Integer, RealestateBean > map1=service.getFlatDetails();
								System.out.println(map1);
							break;

						case 3:
							System.out.println("Thank u, visit again");
							System.exit(0);
							break;
						default:
							System.out.println("Input should be 1,2,3,4 or 5");
							choiceFlag = false;
							break;
						}

					} catch (InputMismatchException exception) {
						choiceFlag = false;
						System.err.println("Input should contain only digits");
					}
				} while (!choiceFlag);

				do {
				
					System.out.println("do you want to continue again [Yes/No]");
					continueChoice = scanner1.nextLine();
					if (continueChoice.equalsIgnoreCase("yes")) {
						continueValue = true;
						break;
					} else if (continueChoice.equalsIgnoreCase("no")) {
						System.out.println("thank you");
						continueValue = false;
						break;
					} else {
						System.out.println("Enter Yes or No");
						continueValue = false;
						continue;
					}
				} while (!continueValue);

			} while (continueValue);
			scanner.close();
			scanner1.close();
		}

	}




package com.capgemini.registrationdao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.capgemini.realestatebean.RealestateBean;
import com.capgemini.registrationexception.RegistrationException;

public interface IRegistrationDao {
	RealestateBean registerFlat(RealestateBean flat) throws RegistrationException ;
	Map<Integer, RealestateBean> map=new HashMap<>();
	ArrayList<Integer> getAllOwnerIds() throws RegistrationException;
	Map<Integer, RealestateBean> getFlatDetails();

}

package com.capgemini.registrationdao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.capgemini.realestatebean.FlatOwner;
import com.capgemini.realestatebean.RealestateBean;
import com.capgemini.registrationexception.RegistrationException;
import com.capgemini.utility.FlatUtility;

public class RegistrationDaoImpl implements IRegistrationDao {
	public RealestateBean registerFlat(RealestateBean flat) throws RegistrationException{
		map.put(flat.getFlatId(), flat);
		return flat;
	}

	public ArrayList<Integer> getAllOwnerIds() throws RegistrationException {
		ArrayList<Integer> array=new ArrayList<>();
		Collection<Integer> collection=FlatUtility.owners.keySet();
		array.addAll(collection);
		return array;
	}

	@Override
	public Map<Integer, RealestateBean> getFlatDetails() {
		return map;
	}

}

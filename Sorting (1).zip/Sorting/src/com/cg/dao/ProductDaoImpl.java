package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.repository.ProductRepository;

public class ProductDaoImpl implements ProductDao {
	Map<Integer, Product> map=ProductRepository.getAllProducts();

	@Override
	public List<Product> getAllProducts() {
		HashMap<Integer, Product> map=ProductRepository.getAllProducts();
		Collection<Product> collections=map.values();
		List<Product> productlist=new ArrayList<>();
		productlist.addAll(collections);
		Collections.sort(productlist);
		return productlist;
	}

	

	@Override
	public HashMap<Integer,Product> addProducts(Product product) {
		HashMap<Integer, Product> map=ProductRepository.getAllProducts();
		map.put(product.getPid(), product);
		return map;
	}

	@Override
	public HashMap<Integer,Product> deleteProduct(int productId) {
		boolean containsFlag=false;
		HashMap<Integer, Product> map=ProductRepository.getAllProducts();
		if(map.containsKey(productId)) {
			map.remove(productId);
			containsFlag=true;
		}
		else {
			try {
				throw new ProductException("Id id not present in the map");
			} catch (ProductException e) {
				System.err.println(e.getMessage());
			}
		}
		return map;
	}
	

}

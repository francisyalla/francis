package com.cg.service;

import java.util.List;
import java.util.Map;


import com.cg.bean.GSTBean;
import com.cg.exception.GSTException;


public interface IGSTService {

	boolean isNameValid(String productName) throws GSTException;

	boolean isWeightValid(int productWeight) throws GSTException;

	boolean isDistanceValid(int distance) throws GSTException;

	int addProduct(GSTBean product) throws GSTException;

	double getTransportCharge(int distance, int productWeight) throws GSTException;

	double getGST(double transportCharges) throws GSTException;

	List<GSTBean> getAllProducts() throws GSTException;



}

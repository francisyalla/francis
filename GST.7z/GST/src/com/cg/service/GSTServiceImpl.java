package com.cg.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;


import com.cg.bean.GSTBean;
import com.cg.dao.GSTDaoImpl;
import com.cg.dao.IGSTDao;
import com.cg.exception.GSTException;


public class GSTServiceImpl implements IGSTService {
	IGSTDao dao=new GSTDaoImpl();

	@Override
	public boolean isNameValid(String productName) throws GSTException {
		String regEx="^[A-Z]{1}[a-zA-z]{4,}$";
		boolean nameFlag=false;
		if(!Pattern.matches(regEx, productName)) {
			throw new GSTException("Name should start with capital and followed by 4 characters");
		}	
		else
			nameFlag=true;
		return nameFlag;
		
	}

	@Override
	public boolean isWeightValid(int productWeight) throws GSTException{
		boolean weightFlag=false;
		if(productWeight<1) {
			throw new GSTException("Weight should be greater than 1kg");
		}
		else
			weightFlag=true;
		return weightFlag;
	}

	@Override
	public boolean isDistanceValid(int distance) throws GSTException{
		boolean distanceFlag=false;
		if(distance<=100) {
			throw new GSTException("Distance should be greater than 100Km");
		}
		else
			distanceFlag=true;
		return distanceFlag;
	}

	@Override
	public int addProduct(GSTBean product) throws GSTException{
		return dao.addProduct(product);
	}

	@Override
	public double getTransportCharge(int distance, int productWeight) throws GSTException{
		
		return dao.getTransportCharge(distance,productWeight);
	}

	@Override
	public double getGST(double transportCharges) throws GSTException {
		
		return dao.getGST(transportCharges);
	}

	@Override
	public List<GSTBean> getAllProducts() throws GSTException {
		List<GSTBean> list  =new  ArrayList<GSTBean>();
		Collection<GSTBean> col = dao.getAllProducts().values();
		list.addAll(col);
		return list;
	}
}

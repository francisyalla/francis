package com.cg.dao;

import java.util.HashMap;
import java.util.Map;


import com.cg.bean.GSTBean;
import com.cg.exception.GSTException;

public interface IGSTDao {
	Map<Integer, GSTBean> map=new HashMap<>();


	int addProduct(GSTBean product) throws GSTException;

	double getTransportCharge(int distance, int productWeight) throws GSTException;

	double getGST(double transportCharges);

	Map<Integer, GSTBean> getAllProducts() throws GSTException;

}

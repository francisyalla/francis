package com.cg.bean;

public class GSTBean {
	private int productId;
	private String productName;
	private int productWeight;
	private int distance;
	public GSTBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GSTBean(int productId, String productName, int productWeight, int distance) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productWeight = productWeight;
		this.distance = distance;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductWeight() {
		return productWeight;
	}
	public void setProductWeight(int productWeight) {
		this.productWeight = productWeight;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	@Override
	public String toString() {
		return "GSTBean [productId=" + productId + ", productName=" + productName + ", productWeight=" + productWeight
				+ ", distance=" + distance + "]";
	}
	public GSTBean(String productName, int productWeight, int distance) {
		super();
		this.productName = productName;
		this.productWeight = productWeight;
		this.distance = distance;
	}
	
	
	

}

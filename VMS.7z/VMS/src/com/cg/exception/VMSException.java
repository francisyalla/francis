package com.cg.exception;

public class VMSException extends Exception {

	public VMSException(String message) {
		super( message);
	}
	

	
	}



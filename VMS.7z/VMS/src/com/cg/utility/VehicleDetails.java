package com.cg.utility;

import java.util.Map;
import java.util.TreeMap;

import com.cg.bean.Vehicle;

public class VehicleDetails {

	public static Map<Integer, Vehicle> vehicles=new TreeMap<>();
	static {
		vehicles.put(111, new Vehicle(111, "Activa", 65000, "Honda"));	
		vehicles.put(111, new Vehicle(222, "Rx", 75000, "Yamaha"));	
		vehicles.put(111, new Vehicle(444, "Enfield", 65000, "Royal"));	
		vehicles.put(111, new Vehicle(555, "Unicorn", 95000, "Honda"));	
		vehicles.put(111, new Vehicle(777, "jupiter", 55000, "Honda"));	
	}
	public static Map<Integer, Vehicle>getvehicle(){
		return vehicles;
	}
	public static void setVehicles(Map<Integer, Vehicle> vehicles) {
		VehicleDetails.vehicles = vehicles;
	
}
	}

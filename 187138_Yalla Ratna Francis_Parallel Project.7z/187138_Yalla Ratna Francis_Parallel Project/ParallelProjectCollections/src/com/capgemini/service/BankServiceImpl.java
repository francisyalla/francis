package com.capgemini.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.bean.AccountBean;
import com.capgemini.bean.TransactionBean;
import com.capgemini.dao.BankDao;
import com.capgemini.dao.BankDaoImpl;
import com.capgemini.exception.BankException;



public class BankServiceImpl implements BankService{

	BankDao dao=new BankDaoImpl();
	
	@Override
	public boolean validateName(String name) throws BankException {

		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankException("First Letter should be Capital and Length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
	@Override
	public boolean validateGender(String gender) throws BankException {
		boolean resultFlag=false;
		if(gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female")) {
			resultFlag = true;
		}else {
			
			throw new BankException("Gender should be only Male or Female");
		}
		return resultFlag;
	}
	@Override
	public boolean validateBalance(double balance) throws BankException{
		boolean resultFlag=false;
		if(balance<0) {
			throw new BankException("Balance should be greater than Zero");
		}else {
			resultFlag=true;
		}
		return resultFlag;
		
	}

	@Override
	public long addDetails(AccountBean account) {
		long accountNo=(long)(Math.random()*100000000);
		account.setAccountNo(accountNo);
		
		return dao.addDetails(account);
	}

	@Override
	public Map<Long, AccountBean> accountDetails(AccountBean account) {
		
		return dao.accountDetails(account);
	}

	@Override
	public long addDeposit(long accountNo, long depositAmount) {
		
		return dao.addDeposit(accountNo, depositAmount);
	}

	@Override
	public long addWithDraw(long accountNo, long withDrawAmount) {
		
		return dao.addWithDraw(accountNo, withDrawAmount);
	}

	@Override
	public double balanceCheck() {
		
		return dao.balanceCheck();
	}

	@Override
	public long fundDetails(long accountNo, long fundAmount) {
		
		return dao.fundDetails(accountNo, fundAmount);
	}

	@Override
	public int addTransaction(TransactionBean transaction) {
		int id=(int)(Math.random()*1000);
		transaction.setTransactionId(id);
		return dao.addTransaction(transaction);
	}

	@Override
	public Map<Integer, TransactionBean> transactionDetails(TransactionBean transaction) {
		
		return dao.transactionDetails(transaction);
	}
	
}

package com.capgemini.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.bean.AccountBean;
import com.capgemini.bean.TransactionBean;
import com.capgemini.exception.BankException;



public class BankDaoImpl implements BankDao{

	static Map<Long, AccountBean> accountDetail=new HashMap<>();
	static Map<Integer, TransactionBean> transactionDetail=new HashMap<>();
	
	@Override
	public long addDetails(AccountBean account) {
		accountDetail.put(account.getAccountNo(), account);
		return account.getAccountNo();
	}

	

	@Override
	public Map<Long, AccountBean> accountDetails(AccountBean account) {
		//Map<Long, Account> accountDetail=new HashMap<Long, Account>();
		accountDetail.put(account.getAccountNo(), account);
		return accountDetail;
	}



	@Override
	public long addDeposit(long accountNo, long depositAmount) {
		long depositBalance=0; 
	
		Iterator<AccountBean> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			AccountBean acc=iterator.next();
		long accNo=acc.getAccountNo();
		double bal=acc.getBalance();
		if(accNo==accountNo)
		{
			depositBalance=(long)bal+depositAmount;
			acc.setBalance(depositBalance);
			break;
		}
		
	}
return depositBalance;
}



	@Override
	public long addWithDraw(long accountNo, long withDrawAmount) {
		long drawBalance=0; 
		
		Iterator<AccountBean> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			AccountBean acc=iterator.next();
		
		long accNo=acc.getAccountNo();
		double bal=acc.getBalance();
		if(accNo==accountNo)
		{
			if(bal>withDrawAmount)
			{
			drawBalance=(long)bal-withDrawAmount;
			acc.setBalance(drawBalance);
			break;
			}
			else
			{
				try {
					throw new BankException("Enter valid amount");
				} catch (BankException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			}
		}
		
	}
		return drawBalance;
	}



	



	@Override
	 public double balanceCheck() {
		double bal=0;
		Iterator<AccountBean> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			AccountBean acc=iterator.next();
		
		
		 bal=acc.getBalance();
	
		
		
	}
		return bal;
	}



	@Override
	public long fundDetails(long accountNo, long fundAmount) {
long fundBalance=0; 
		
		Iterator<AccountBean> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			AccountBean acc=iterator.next();
		
		long accNo=acc.getAccountNo();
		double bal=acc.getBalance();
		if(accNo==accountNo)
		{
			fundBalance=(long)bal-fundAmount;
			acc.setBalance(fundBalance);
			break;
		}
		
	}
		return fundBalance;
	}



	@Override
	public int addTransaction(TransactionBean transaction) {
		transactionDetail.put(transaction.getTransactionId(), transaction);
		return transaction.getTransactionId();
	}



	



	@Override
	public Map<Integer, TransactionBean> transactionDetails(TransactionBean transaction) {
		transactionDetail.put(transaction.getTransactionId(), transaction);
		return transactionDetail;
		
	}
		
	
}

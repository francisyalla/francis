package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.InsufficientBalanceException;

public interface BankService {

	public long addCust(Customer customer);
	Customer getCustomer(long accountNo, String password);
	public boolean isNameValid(String name) throws InsufficientBalanceException;
	public boolean isPhoneValid(String name) throws InsufficientBalanceException;
	public boolean isEmailValid(String name) throws InsufficientBalanceException;
	public boolean isAccountValid(long accountNo,String password) throws InsufficientBalanceException;
	public boolean isAccountNoValid(long accountNo) throws InsufficientBalanceException;
	public boolean deposit(float amount, long accountNo) throws InsufficientBalanceException;
	public boolean withdraw(float amount, long accountNo) throws InsufficientBalanceException;
	public boolean fundTransfer(float amount,long accountNo, long accountNo2) throws InsufficientBalanceException;
	public List<Transaction> printTransaction(long accountNo);
}

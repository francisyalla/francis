package com.capgemini.service;


import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.dao.BankDao;
import com.capgemini.dao.BankDaoImpl;
import com.capgemini.exception.InsufficientBalanceException;

public class BankServiceImpl implements BankService{
	
	BankDao bdao=new BankDaoImpl();
	BankDaoImpl bankDao = new BankDaoImpl();

	@Override
	public long addCust(Customer customer) {
		return bankDao.addCustomer(customer);
	}

	@Override
	public Customer getCustomer(long accountNo, String password) {
		return bankDao.getCustomer(accountNo, password);
	}

	@Override
	public boolean isNameValid(String name) throws InsufficientBalanceException {
		boolean namevalid = false;
		String regex = "^[A-Z]{1}[A-Za-z]{1,}$";
		if (!Pattern.matches(regex, name)) {
			throw new InsufficientBalanceException("First Letter Should be Capital");
		} else {
			namevalid = true;
		}
		return namevalid;
	}

	@Override
	public boolean isPhoneValid(String mobile) throws InsufficientBalanceException {
		boolean phonevalid = false;
		String regex = "^[7-9]{1}[0-9]{9}$";
		if (!Pattern.matches(regex, mobile)) {
			throw new InsufficientBalanceException("Enter Valid Phone Number");
		} else {
			phonevalid = true;
		}
		return phonevalid;
	}

	@Override
	public boolean isEmailValid(String email) throws InsufficientBalanceException {
		boolean emailValid = false;
		String regex = "^(.+)@(.+)$";
		if (!Pattern.matches(regex, email)) {
			throw new InsufficientBalanceException("Enter Valid Email");
		} else {
			emailValid = true;
		}
		return emailValid;
	}

	@Override
	public boolean isAccountNoValid(long accountNo) throws InsufficientBalanceException {
		boolean accountvalid = false;
		if(!bankDao.accountNoValid(accountNo))
		{
			throw new InsufficientBalanceException("No Account Exists!!!!!");
		}
		else
		{
			accountvalid = true;
		}
		return accountvalid;
	}
	
	@Override
	public boolean isAccountValid(long accountNo,String password) throws InsufficientBalanceException{
		boolean accountvalid = false;
		if(!bankDao.accountValid(accountNo,password))
		{
			throw new InsufficientBalanceException("Invalid Credentials!!!!!");
		}
		else
		{
			accountvalid = true;
		}
		return accountvalid;
	}
	
	@Override
	public boolean deposit(float amount, long accountNo) throws InsufficientBalanceException {
		boolean depositvalid = false;
		if(!bankDao.depositAmount(amount, accountNo))
		{
			throw new InsufficientBalanceException("Transaction failed : Amount cannot be less than zero");
		}
		else
		{
			depositvalid = true;
		}
		return depositvalid;
	}

	@Override
	public boolean withdraw(float amount, long accountNo) throws InsufficientBalanceException {
		boolean withdrawvalid = false;
		if(!bankDao.withdrawAmount(amount, accountNo))
		{
			throw new InsufficientBalanceException("Transaction failed : Insufficient Balance");
		}
		else
		{
			withdrawvalid = true;
		}
		return withdrawvalid;
	}

	@Override
	public boolean fundTransfer(float amount, long accountNo, long accountNo2) throws InsufficientBalanceException {
		boolean transfervalid = false;
		if(!bankDao.fundTransferAmount(amount, accountNo, accountNo2))
		{
			throw new InsufficientBalanceException("Transaction failed");
		}
		else
		{
			transfervalid = true;
		}
		return transfervalid;
	}

	@Override
	public List<Transaction> printTransaction(long accountNo) {
		return bankDao.printTransactions(accountNo);
	}
}

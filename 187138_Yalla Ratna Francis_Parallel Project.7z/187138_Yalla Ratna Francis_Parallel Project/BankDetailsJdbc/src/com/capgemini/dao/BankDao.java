package com.capgemini.dao;


import java.util.List;
import java.util.Map;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.InsufficientBalanceException;

public interface BankDao {
	public long addCustomer(Customer customer);
	//public boolean updateCustomer(Customer customer);
	//boolean deleteCustomer(int customerId);
	Customer getCustomer(long accountNo, String password);
	Map<Integer, Customer> getCustomers();
	public boolean accountValid(long accountNo,String password);
	public boolean accountNoValid(long accountNo);
	public boolean depositAmount(float amount, long accountNo) throws InsufficientBalanceException;
	public boolean withdrawAmount(float amount, long accountNo) throws InsufficientBalanceException;
	public boolean fundTransferAmount(float amount,long accountNo, long accountNo2) throws InsufficientBalanceException;
	public List<Transaction> printTransactions(long accountNo);
	
}

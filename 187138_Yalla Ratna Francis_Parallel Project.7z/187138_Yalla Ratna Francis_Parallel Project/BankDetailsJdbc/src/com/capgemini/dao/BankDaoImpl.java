
    
package com.capgemini.dao;


import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;

import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.ui.BankDB;
import com.capgemini.ui.DBconnection;



public class BankDaoImpl implements BankDao{


    BankDB bank = new BankDB();
    Customer customer = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;
    int row = -1;


    @Override
    public long addCustomer(Customer customer) {
        long accountNo = 1;
        try (Connection connection = DBconnection.getconnection();) {
            statement = connection.prepareStatement("select customersequ.NEXTVAL from dual");
            resultSet = statement.executeQuery();
            if (resultSet.next())
                accountNo = resultSet.getLong(1);
            statement = connection.prepareStatement(
                    "insert into customer(accountno,firstname,email,mobile,password) values(?,?,?,?,?)");
            statement.setLong(1, accountNo);
            statement.setString(2, customer.getName());
            statement.setString(3, customer.getEmail());
            statement.setString(4, customer.getMobile());
            statement.setString(5, customer.getPassword());
            row = statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return accountNo;
    }


    @Override
    public boolean accountNoValid(long accountNo) {
        String name = null;
        try (Connection connection = DBconnection.getconnection();) {
            statement = connection.prepareStatement("select firstname from customer where accountno=?");
            statement.setLong(1, accountNo);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                name = resultSet.getString("firstname");
            }
            if (name != null) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public boolean accountValid(long accountNo, String password) {
        String name = null;
        try (Connection connection = DBconnection.getconnection();) {
            statement = connection.prepareStatement("select firstname from customer where accountno=? and password=?");
            statement.setLong(1, accountNo);
            statement.setString(2, password);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                name = resultSet.getString("firstname");
            }
            if (name != null) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public Customer getCustomer(long accountNo, String password) {
        try (Connection connection = DBconnection.getconnection();) {
            statement = connection.prepareStatement("select * from customer where accountno=?");
            statement.setLong(1, accountNo);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                customer = new Customer();
                customer.setAccountNo(resultSet.getLong("accountno"));
                customer.setName(resultSet.getString("firstname"));
                customer.setEmail(resultSet.getString("email"));
                customer.setBalance(resultSet.getFloat("balance"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }


    @Override
    public Map<Integer, Customer> getCustomers() {
        return null;
    }

    @Override
    public boolean depositAmount(float amount, long accountNo) throws InsufficientBalanceException {
        float balance = 0;
        boolean deposit = true;
        if (amount < 0) {
            deposit = false;
        } else {
            try (Connection connection = DBconnection.getconnection();) {
                statement = connection.prepareStatement("select balance from customer where accountno=?");
                statement.setLong(1, accountNo);
                resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    balance = resultSet.getFloat("balance");
                }
                amount = balance + amount;
                statement = connection.prepareStatement("update customer set balance=? where accountno=?");
                statement.setDouble(1, amount);
                statement.setLong(2, accountNo);
                row = statement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return deposit;
    }


    @Override
    public boolean withdrawAmount(float amount, long accountNo) throws InsufficientBalanceException {
        boolean withdraw = false;
        float balance = 0;
        try (Connection connection = DBconnection.getconnection();) {
            statement = connection.prepareStatement("select balance from customer where accountno=?");
            statement.setLong(1, accountNo);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                
                balance = resultSet.getFloat("balance");
                
                System.out.println("Original Balance = "+balance);
            }
            if (balance > amount) {
                
                balance = balance - amount;
                
                System.out.println("Withdraw Balance = "+balance);
                
                statement = connection.prepareStatement("update customer set balance=? where accountno=?");
                statement.setDouble(1, balance);
                statement.setLong(2, accountNo);
                row = statement.executeUpdate();
                withdraw=true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
        }
        return withdraw;
    }


    
    
    @Override
        public boolean fundTransferAmount(float amount, long accountNo1, long accountNo2) throws InsufficientBalanceException {
            boolean transfer = false;
            long transactionid = 0;
            try (Connection connection = DBconnection.getconnection();) {


                if (!withdrawAmount(amount, accountNo1)) {
                    System.out.println("NO withrdaw");
                }
                
                if (!depositAmount(amount, accountNo2)) {
                    System.out.println("NO deposit");
                }
                
                
                statement = connection.prepareStatement("select transactionseq.NEXTVAL from dual");
                resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    transactionid = resultSet.getLong(1);
                }
                statement = connection.prepareStatement(
                        "insert into transaction1(transactionid,transactiontype,accountno,amount) values(?,?,?,?)");
                statement.setLong(1, transactionid);
                statement.setString(2, "CR");
                statement.setLong(3, accountNo1);
                statement.setFloat(4, amount);


                int row1 = statement.executeUpdate();


                statement = connection.prepareStatement("select transactionseq.NEXTVAL from dual");
                resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    transactionid = resultSet.getLong(1);
                }
                statement = connection.prepareStatement(
                        "insert into transaction1(transactionid,transactiontype,accountNo,amount) values(?,?,?,?)");
                statement.setLong(1, transactionid);
                statement.setString(2, "DB");
                statement.setLong(3, accountNo2);
                statement.setFloat(4, amount);


                int row2 = statement.executeUpdate();


                transfer = true;


            } catch (SQLException e) {
                e.printStackTrace();


            } catch (Exception e) {
                e.printStackTrace();
            }
            return transfer;
        }


        @Override
        public List<Transaction> printTransactions(long accountNo) {
            Transaction transaction = null;
            List<Transaction> transactionList = new ArrayList<>();
            try(Connection connection = DBconnection.getconnection();) {
                statement = connection.prepareStatement("select * from transaction1 where accountNo=? ");
                statement.setLong(1, accountNo);
                resultSet= statement.executeQuery();
                while(resultSet.next())
                {
                    transaction = new Transaction();
                    transaction.setTransactionId(resultSet.getLong("transactionid"));
                    transaction.setAccountNo(accountNo);
                    transaction.setTransactionType(resultSet.getString("transactiontype"));
                   // transaction.setTransactionDate(resultSet.getString("transactiondate"));
                    transaction.setAmount(resultSet.getFloat("amount"));
                    transactionList.add(transaction);
                }
                
            } catch (SQLException e) {
                e.printStackTrace();


            } catch (Exception e) {
                e.printStackTrace();
            }
            return transactionList;
        }
    }
     
























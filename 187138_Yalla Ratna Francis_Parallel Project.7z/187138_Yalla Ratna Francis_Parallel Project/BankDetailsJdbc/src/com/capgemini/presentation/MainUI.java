package com.capgemini.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.service.BankServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		BankServiceImpl bankServiceImpl = new BankServiceImpl();
		Scanner scanner = new Scanner(System.in);
		long accountNo = 0;
		String password = null;
		int option = 0;
		boolean exit = false;
		// String continueChoice1;
		// boolean continueValue = false;
		do {
			boolean firstCheck = false;
			do {
				try {
					System.out.println("\nSelect An Option");
					System.out.println("1.Register New Account\n2.Login To Account\n3.Exit");
					option = scanner.nextInt();
					switch (option) {
					case 0: {
						scanner.close();
						System.exit(0);
					}
					case 1: {
						System.out.println("\nNew Account Register");
						boolean validate = false;
						String name = null;
						scanner.nextLine();
						while (!validate) {
							try {
								scanner = new Scanner(System.in);
								System.out.println("\nEnter First Name: ");
								name = scanner.nextLine();
								bankServiceImpl.isNameValid(name);
								validate = true;
							} catch (InsufficientBalanceException e) {
								System.err.println(e.getMessage());
							}
						}

						validate = false;
						String email = null;
						do {
							try {
								System.out.println("\nEnter Valid Email : ");
								email = scanner.next();
								bankServiceImpl.isEmailValid(email);
								validate = true;
							} catch (InsufficientBalanceException e) {
								System.err.println(e.getMessage());
								scanner.nextLine();
							}
						} while (!validate);

						validate = false;
						String mobile = null;
						do {
							try {
								System.out.println("\nEnter Phone Number : ");
								mobile = scanner.next();
								bankServiceImpl.isPhoneValid(mobile);
								validate = true;
							} catch (InsufficientBalanceException e) {
								System.err.println(e.getMessage());
								scanner.nextLine();
							}
						} while (!validate);

						System.out.println("Enter Password : ");
						password = scanner.next();

						Customer customer = new Customer(name, email, mobile, password);

						accountNo = bankServiceImpl.addCust(customer);

						System.out.println("Your Account Is Created : " + accountNo);
					}
						break;
					case 2: {
						System.out.println("\n*****LOGIN*****");
						boolean check = false;
						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("\nEnter Account Number : ");
								accountNo = scanner.nextLong();
								System.out.println("Enter Password : ");
								password = scanner.next();
								bankServiceImpl.isAccountValid(accountNo, password);
								check = true;
							} catch (InsufficientBalanceException e) {
								System.err.println("\n"+e.getMessage());
								scanner.nextLine();
								check = false;
							}
						} while (!check);
					}
						int continueChoice = 0;
						float amount = 0.0f;
						boolean secondCheck = false;
						do {
							try {
								System.out.println("\n********Transactions********");
								System.out.println(
										"\n1.Show Balance\n2.Deposit\n3.Withdraw\n4.Fund Transfer\n5.Print Transactions\n"
												+ "0.Logout");
								continueChoice = scanner.nextInt();
								boolean valid = false;
								switch (continueChoice) {
								case 0: {
									secondCheck = true;
									firstCheck = true;
									break;
								}
								case 1:
									System.out.println("Account balance : "
											+ bankServiceImpl.getCustomer(accountNo, password).getBalance());
									break;
								case 2:
									do {
										System.out.println("Enter the Amount you want to deposit : ");
										try {
											scanner = new Scanner(System.in);
											amount = scanner.nextFloat();
											bankServiceImpl.deposit(amount, accountNo);
											valid = true;
										} catch (InsufficientBalanceException e) {
											System.err.println(e.getMessage());
											valid = true;
										} catch (InputMismatchException e) {
											System.err.println("Only numeric Values");
											valid = false;
										}
									} while (!valid);
									break;
								case 3:
									do {
										System.out.println("Enter the Amount you want to Withdraw : ");
										try {
											amount = scanner.nextLong();
											bankServiceImpl.withdraw(amount, accountNo);
											valid = true;
										} catch (InsufficientBalanceException e) {
											System.err.println(e.getMessage());
											valid = true;
										} catch (InputMismatchException e) {
											System.err.println("Only numeric Values");
											valid = false;
										}
									} while (!valid);
									break;
								case 4:
									long accountNo2 = 0;
									do {
										System.out.println("Enter the Account Number you want to Transfer : ");
										try {
											accountNo2 = scanner.nextLong();
											bankServiceImpl.isAccountNoValid(accountNo2);
											valid = true;
										} catch (InsufficientBalanceException e) {
											System.err.println(e.getMessage());
											valid = false;
										} catch (InputMismatchException e) {
											System.err.println("Only numeric Values");
											valid = false;
										}
									} while (!valid);
									do {
										System.out.println("Enter the Amount you want to Transfer : ");
										try {
											amount = scanner.nextLong();
											bankServiceImpl.fundTransfer(amount, accountNo, accountNo2);
											valid = true;
										} catch (InsufficientBalanceException e) {
											System.err.println(e.getMessage());
											valid = false;
										} catch (InputMismatchException e) {
											System.err.println("Only numeric Values");
											valid = false;
										}
									} while (!valid);
									
									break;
								case 5:
									System.out.println("Transactions of AccountNo :" + accountNo);
									Iterator<Transaction> iterator = bankServiceImpl.printTransaction(accountNo)
											.iterator();
									while (iterator.hasNext()) {
										System.out.println(iterator.next());
									}
									break;
								default:
									System.err.println("Enter Correct Choice.......");
									secondCheck = false;
									break;
								}
							} catch (InputMismatchException e) {
								System.err.println("Only Numeric Values");
								scanner.nextLine();
							}
						} while (!secondCheck);
						break;
					default:
						System.err.println("Enter Correct Choice.......");
						firstCheck = false;
						break;
					}
				} catch (InputMismatchException e) {
					System.err.println("Only Numeric Values");
					scanner.nextLine();
					firstCheck = false;
				}
			} while (!firstCheck);

		} while (!exit);

	}

}

package com.capgemini.mainlayer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.Exceptionlayer.AccountException;
import com.capgemini.beanlayer.Account;
import com.capgemini.beanlayer.Customer;
import com.capgemini.beanlayer.Transaction;
import com.capgemini.servicelayer.Service;
import com.capgemini.servicelayer.ServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("eneter to our World Bank ");
		Scanner scanner = new Scanner(System.in);
		Account account = null;
		Transaction transaction = null;
		Service service = new ServiceImpl();
		int transacId = 0;
		Customer customer = null;
		boolean choiceflag = false;
		String continueChoice;
		long accountNo = 0;

		do {

			System.out.println("1.Create account \n 2.Login \n 3. Exit");
			System.out.println("enter your choice:");
			int choice = 0;
			try {
				choice = scanner.nextInt();
				choiceflag = true;
				switch (choice) {
				case 1: {
					String name = null;
					boolean status1 = false;
					String email = null;
					String phone = null;
					double ammount = 0;
					do {
						try {

							System.out.println("Enter user name:");
							name = scanner.next();
							service.ValidateName(name);
							status1 = true;
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							status1 = false;
							System.out.println(e.getMessage());
						}
					} while (!status1);

					do {
						try {
							System.out.println("Enter your email adrress:");
							email = scanner.next();
							service.validateEmail(email);
							status1 = true;
						} catch (AccountException e1) {
							// TODO Auto-generated catch block
							status1 = false;
							System.out.println(e1.getMessage());
						}
					} while (!status1);

					do {
						try {
							System.out.println("Enter your phone number:");
							phone = scanner.next();
							service.validatePhoneNumber(phone);
							status1 = true;
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							status1 = false;
							System.out.println(e.getMessage());
						}
					} while (!status1);
					System.out.println("Enter Address:");
					String address = scanner.next();
					do {
						try {
							System.out.println("Enter Amount to start your account:");
							ammount = scanner.nextDouble();
							service.validateAmount(ammount);
							status1 = true;
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							status1 = false;
							System.out.println(e.getMessage());
						}
					} while (!status1);

					try {
						accountNo = service.generateAccountNo();
						System.out.println("your accountNo is:" + accountNo);

						int password = service.getCustomerId();
						account = new Account(name, ammount, accountNo, password);
						service.addAccount(account);
						System.out.println("you are registered successfully " + "and username: " + name + "   "
								+ "password:" + password);
						customer = new Customer(password, name, email, phone, address, ammount);
						service.addCustomer(customer);
					} catch (AccountException e) {

						System.out.println(e.getMessage());
					}
				}
					break;
				case 2: {
					Account acc = null;
					
					String name = null;
					
					int pass = 0;
					boolean status=false;
					do
					{
						System.out.println("Enter username");
						 name = scanner.next();
						 System.out.println("Enter Password");
						 pass = scanner.nextInt();
						
					try {
						acc = service.ValidateLogin(name, pass);
						status=true;
						if(acc==null)
						{
							status=false;
							throw new AccountException("no suuch account");
						}
					} catch (AccountException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					}while(!status);
					System.out.println("login successfull");
					System.out.println("enter the required option");
					System.out.println("1.Withdraw\n2.deposit\n3.balance\n4.print Transaction");
					try {
					int pass1 = scanner.nextInt();
					double balan = 0;
					switch (pass1) {
					case 1: {
						double bal = 0;
						long acno = 0;
						System.out.println("enter the amount to be withdrawn");
						double amt = scanner.nextDouble();
						try {
							service.validateWithdraw(amt);
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
						try {
							service.withdraw(amt, name, pass);
							bal = acc.getBalance();
							acno = acc.getAccountNo();
							System.out.println(bal);
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
						//System.out.println("amount withdrawn successfull");
						try {
							transacId = service.dtransacId();
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
						SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
						Date d = new Date();
						String dt = formatter.format(d);
						try {
							d = formatter.parse(dt);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}

						transaction = new Transaction(transacId, "withdraw", d, pass, acno, amt, bal);
						
						try {
							service.addTransaction(transaction);
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}

					}
						break;
					case 2: {
						System.out.println("enter the amount to be deposited");
						double bal = 0;
						long acno = 0;

						double amt = scanner.nextDouble();
						try {
							service.deposit(amt, name, pass);
							bal = acc.getBalance();
							acno = acc.getAccountNo();

						} catch (AccountException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
						System.out.println("amount deposited successfuly");
						try {
							transacId = service.dtransacId();
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}
						SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
						Date d = new Date();
						String dt = formatter.format(d);
						try {
							d = formatter.parse(dt);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}

						transaction = new Transaction(transacId, "deposit", d, pass, acno, amt, bal);
						try {
							service.addTransaction(transaction);
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							System.out.println(e.getMessage());
						}

					}
						break;

					case 3: {

						try {
							balan = service.getBalance(name, pass);
							System.out.println("your balance is :" + balan);
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
						break;
					case 4: {
						System.out.println("your transactions are as given:");
						List<Transaction> list = new ArrayList<Transaction>();
						try {
							list = service.getTransaction(name, pass);
							System.out.println(list);
						} catch (AccountException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
						break;

					default: {
						System.out.println("enter valid option between 1 to 4");

					}
						break;
					} 
					}catch(InputMismatchException e) {
						System.out.println("eneterd option must be in digits only");
						
					}

				}
					break;
				case 3:{
					System.out.println("system going to be exited");
					System.exit(0);
				}
				default: {
					System.err.println("enter a valid option between 1-3");
				}
					break;
				}
			} catch (InputMismatchException e) {
				choiceflag = true;
				System.out.println("entered format should only in digits");
			}
			boolean continueValue = false;
			do {

				scanner = new Scanner(System.in);

				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					choiceflag = true;
					break;

				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					choiceflag = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (choiceflag);
	}
}

import { Component, OnInit } from '@angular/core';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
  /* providers:[DashboardComponent] */
})
export class DetailsComponent implements OnInit {


   payment:string;
  constructor(private service:CapstoreService) { }

  ngOnInit() {
   
    this.service.getCustomer().subscribe(data=>this.service.setCustomerObj(data));
    console.log(this.service.getCustomerObj());
  }

  
  
  place_order()
  {
    console.log(this.service.getPaymentMode());
  }
}

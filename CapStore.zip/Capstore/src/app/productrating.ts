import { Product } from './product';

export class Productrating {

    ratId:string;
    product:Product;
    currRating:number;
    ratingCount:number;
}

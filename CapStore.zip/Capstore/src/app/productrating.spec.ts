import { Productrating } from './productrating';

describe('Productrating', () => {
  it('should create an instance', () => {
    expect(new Productrating()).toBeTruthy();
  });
});

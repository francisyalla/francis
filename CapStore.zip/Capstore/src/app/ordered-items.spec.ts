import { OrderedItems } from './ordered-items';

describe('OrderedItems', () => {
  it('should create an instance', () => {
    expect(new OrderedItems()).toBeTruthy();
  });
});

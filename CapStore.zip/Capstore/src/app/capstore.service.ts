import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CapstoreService {

  paymentMode:String;
  customerId:string;
  customer:Customer;
  constructor(private http:HttpClient) { }

getPaymentMode()
{
  return this.paymentMode;
}

setPaymentMode(mode:String)
{
  this.paymentMode=mode;
}

getCustomerId()
{
  return this.customerId;
}
 setCustomerId()
 {
   this.customerId="CUST_00001";
 }

 getCustomer():Observable<Customer>
 {
   return this.http.get<Customer>("http://localhost:8081/getCustomer/CUST_00001");
 }

 getCustomerObj()
 {
   return this.customer;
 }

 setCustomerObj(obj:Customer)
 {
    this.customer=obj;
 }
}

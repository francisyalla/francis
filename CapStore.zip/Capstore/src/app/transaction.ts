export class Transaction {

    orderId:string;
    paymentMode:string;
}

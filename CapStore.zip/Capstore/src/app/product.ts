import { Merchant } from './merchant';
import { Productrating } from './productrating';

export class Product {
    prodId:string;
    prodName:string;
    prodCategory:string;
    price:number;
    discount:number;
    validTime:string;
    promoCode:string;
    viewsCount:string;
    merchant: Merchant;
    productRating: Productrating;
    constructor(prodId:string,prodName:string,prodCategory:string,price:number,discount:number,validTime:string,promoCode:string,viewsCount:string,merchant: Merchant,productRating: Productrating){
            this.prodId=prodId;
            this.prodName=prodName;
            this.prodCategory=prodCategory;
            this.price=price;
            this.discount=discount;
            this.validTime=validTime;
            this.promoCode=promoCode;
            this.viewsCount=viewsCount;
            this.merchant=merchant;
            this.productRating=productRating;
        }
}

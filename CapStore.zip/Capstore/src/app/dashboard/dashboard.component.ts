import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DetailsComponent } from '../details/details.component';
import { CapstoreService } from '../capstore.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  payment:String; 
  public show:boolean = false;
  constructor(private router:Router,private service:CapstoreService) { }

  ngOnInit() {}
  toggle() {
    this.show = !this.show;
  }
  enable()
  {
    
     (<HTMLInputElement >document.getElementById('continue')).removeAttribute('disabled');
     (<HTMLInputElement >document.getElementById('place')).disabled=true;
  }
  enabled()
  {
    (<HTMLInputElement >document.getElementById('place')).removeAttribute('disabled');
    (<HTMLInputElement >document.getElementById('continue')).disabled=true;
  }
  paymentMode(event:any)
  {
   this.payment=event.target.value;
   this.service.setPaymentMode(this.payment);
  } 
 
  redirect()
  {
    this.router.navigate(['/details']);
  }
}

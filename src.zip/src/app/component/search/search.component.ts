import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  products:Product[];
  searchItem:string='';
  searchedData:Product[];

  constructor(private service:ProductService) { }

  
  ngOnInit() {

    this.service.getAllProducts().subscribe((data:Product[])=>{this.products=data; 
      console.log("all"+this.products)});
  }
  search(value:string){
    this.searchedData=this.products.filter(Product=>Product.name.toLowerCase().indexOf(value.toLowerCase())!==-1);
    this.service.setSearcheddata(this.searchedData);
  }
  
}

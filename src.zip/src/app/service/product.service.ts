import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  url:string="http://localhost:5002/products";
  filterdata: Product[];
  constructor(private http:HttpClient) { }
  addProduct(product:Product){
    return this.http.post(this.url,product);
 }
 getAllProducts(){
  return this.http.get<Product[]>(this.url);
}
deleteProduct(product:Product){
  return this.http.delete<Product[]>(this.url+"/"+product.id);
}
setSearcheddata(searchedData:Product[]){
  this.filterdata=searchedData;
}
getSearcheddata(){
  return this.filterdata;
}
}

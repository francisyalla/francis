package com.cg.pd.exception;

public class SuperShopperException extends Exception {

	public SuperShopperException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}

package com.cg.pd.service;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pd.bean.Product;
import com.cg.pd.bean.Supplier;
import com.cg.pd.dao.ISuperShoppeDAO;
import com.cg.pd.dao.SuperShoppeDAOImpl;
import com.cg.pd.exception.SuperShopperException;

public class ShopperServiceImpl implements IShopperService {
	ISuperShoppeDAO superShopper = new SuperShoppeDAOImpl();
	
	@Override
	public int addProduct(Product product) {
			int productId = (int) (Math.random()*10000);
		product.setProductId(productId);
		//return type is int then how there is no error??
		return superShopper.addProduct(product);
	}

	@Override
	public int addSupplier(Supplier sup) {
		int supplierId = (int) (Math.random()*10000);
		sup.setSupplierId(supplierId);
		return superShopper.addSupplier(sup);
	}

	@Override
	public HashMap<Integer, Product> getAllProducts() {
		
		return superShopper.getAllProducts();
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() {
		
		return (HashMap<Integer, Supplier>) superShopper.supplierList;
	}
	public	boolean isNameValid(String name) {
		Pattern nameptn = Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match = nameptn.matcher(name);
		if (match.matches()) {
			return true;
		}
		return false;
	}
	public 	boolean isPhoneValid(String phone) {
		String mobile = String.valueOf(phone);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			return true;
		}
		return false;
	}
	public boolean isQuantityValid(int quantity) throws InputMismatchException, SuperShopperException
	{
	   if(quantity <=10) {
	        	throw new SuperShopperException("quantity must be greater than 10");
	        }
	   else {
		   return true;
	   }    

	}
	public boolean isPriceValid(int price) throws InputMismatchException, SuperShopperException
	{
	   if(price <= 1) {
	        	throw new SuperShopperException("Price must be greater than 0");
	        }
	   else {
		   return true;
	   }    

	}

}

package com.cg.pd.service;

import java.util.Collection;
import java.util.HashMap;

import com.cg.pd.bean.Product;
import com.cg.pd.bean.Supplier;

public interface IShopperService {
	
	public int addProduct(Product product);
	public int addSupplier(Supplier sup);
	public HashMap<Integer,Product> getAllProducts();
	public HashMap<Integer, Supplier> getAllSuppliers();
}

package DifferenceJava;

public class Differencejava {

}

package com.cg.beans;

public class Product implements Comparable<Product>{
	private int productId;
	private String name;
	private double  price;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Product(int productId, String name, double price) {
		super();
		this.productId = productId;
		this.name = name;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", price=" + price + "]";
	}
	
	

	@Override
	public int compareTo(Product p) {
		if (this.productId>p.productId)
			return 1;
		else if (this.productId>p.productId)
		return -1;
		else 
			return 0;
	}
}
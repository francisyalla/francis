package com.cg.dao;

import java.util.List;

import com.cg.beans.Product;

public interface ProductDao {
public List<Product>getAllProducts();
	
}

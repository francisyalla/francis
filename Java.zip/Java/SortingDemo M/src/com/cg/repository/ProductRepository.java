package com.cg.repository;

import java.util.HashMap;

import com.cg.beans.Product;

public class ProductRepository {
public static HashMap<Integer, Product> map=new HashMap<>();

public static HashMap<Integer, Product> getAllProducts(){
	map.put(44,new Product(44, "laptop", 98989));
	map.put(33,new Product(33, "computer", 48989));
	map.put(22,new Product(22, "ball", 58989));
	map.put(55,new Product(55, "car", 68989));
	map.put(11,new Product(11, "toy", 28989));
	return map;
	
	
	
	
	
	
	
}

}

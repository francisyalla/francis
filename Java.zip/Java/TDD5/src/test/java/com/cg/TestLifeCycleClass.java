package com.cg;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

@TestInstance(Lifecycle.PER_CLASS)
public class TestLifeCycleClass {
	static Logger log=Logger.getLogger("TestLifeCycle");

@BeforeAll
public static void beforeAllclass() {
	log.info("******** Before All********");
}

@AfterAll
public static void afterAllclass() {
	log.info("******** After All********");
}

	
	

}

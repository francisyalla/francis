package com.cg;

public class NumberStringCheck {

	public boolean isOdd(int number) {
		return number%2 !=0;
	}
	public boolean isBlank(String s) {
	return s==null || s.trim().isEmpty();
	
	
}
	}
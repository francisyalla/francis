package com.cg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


	public class HashDemo {
		public static Map<String> getNames(Map<String, String>)
	
	public static void main(String[] args) {
	
	Map<String, String> employee =new HashMap<>();{
	employee.put("Francis", "capgemini");	
	employee.put("Anji" ,"ibm");	
	employee.put("gani", "capgemini");	
	employee.put("Prithvi" ,"capgemini");	

	String org = "cg";
	
	ArrayList<String> names=getNames(employee,org);
	System.out.println(names);
	
}
	}
	}
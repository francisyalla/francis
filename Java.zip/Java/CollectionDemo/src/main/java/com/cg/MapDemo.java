package com.cg;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		
		HashMap<Integer, String> map=new HashMap<>();
		//LinkedHashMap<Integer, String> map=new LinkedHashMap<>();
		//TreeMap<Integer, String> map=new TreeMap<>();
		//Hashtable<Integer, String> map=new Hashtable<>();
		//Properties map=new Properties();
		map.put(6, "java");
		map.put(2, "cpp");
		map.put(4, "python");
		map.put(1, "c");
		map.put(3, "html");
		map.put(4, "spring");
		System.out.println(map.size());
		System.out.println(map);
		System.out.println(map.remove(3));
		System.out.println("After remove");
		System.out.println(map);
		//set of values
		Set<Integer> set=map.keySet();
		for (Integer k:set) {
			System.out.println(map.get(k));
		}
		Collection<String> collection=map.values();
		List<String> list=new ArrayList<String>();
		list.addAll(collection);
		System.out.println("List of values");
		System.out.println(list);
		
		
}}

package com.cg.client;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;

import com.cg.beans.Employee;
import com.cg.service.NameSort;
import com.cg.service.SalarySort;

public class EmployeeClient {

	
	
	public static void main(String[] args) {
		//ArrayList<Employee> emplist=new ArrayList<>();
		//HashSet<Employee> emplist=new HashSet<>();
		Scanner scanner=new Scanner(System.in);
		while (true) {
		System.out.println("Enter 1.EmpId-sort 2.Name-sort 3.Salary-sort");
		int option=scanner.nextInt();
		TreeSet<Employee> emplist=null;
		if (option==1) {
			emplist=new TreeSet<>();
		}else if (option==2) {
			emplist=new TreeSet<>(new NameSort());

		}else if (option==3){
			emplist=new TreeSet<>(new SalarySort());
		}
		else { System.exit(0);
		
		Employee e1=new Employee(123, "francis",78987,"Analyst");
		Employee e2=new Employee(121, "anji",18987,"HR");
		Employee e3=new Employee(122, "ganesh",98987,"Engineer");
		Employee e4=new Employee(124, "prithvi",58987,"Admin");
		Employee e5=new Employee(123, "vijay",48987,"Trainer");
		emplist.add(e1);
		emplist.add(e2);
		emplist.add(e3);
		emplist.add(e4);
		emplist.add(e5);
		System.out.println(emplist);

	}

}}}

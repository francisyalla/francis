package com.cg.java.day4;

import java.util.Scanner;

  class evenNumber {

	int remainder,count=0;
	public int findeven (int number) {
		while(number>0) {
			remainder= number%10;
			number= number/10;
			if(remainder%2==0)
				count++;
			
		}
		return count;
	}
  }	
	
	
	
	public class even{
		
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter value");
		int num = scanner.nextInt();
		evenNumber evennumber = new evenNumber();
		int result = evennumber.findeven(num);
		System.out.println("count is : " + result);
	}
	

}

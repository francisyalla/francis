package com.cg.java.day4;

import java.util.Scanner;

public class CubesExcercise {
	  public int cubing(int number) {
	        int remainder,result=0;
	        while(number!=0) {
	            remainder=number%10;
	            result=result + remainder*remainder*remainder;
	            number=number/10;
	               
	        }
	        return result;
	       
	    }
	    public static void main(String[] args) {
	        Scanner scanner=new Scanner(System.in);
	        System.out.println("enter value");
	        CubesExcercise cube=new CubesExcercise();
	        int number=scanner.nextInt();
	        int result=cube.cubing(number);
	        System.out.println("Cubing of the number is :" + result);
	    }
}

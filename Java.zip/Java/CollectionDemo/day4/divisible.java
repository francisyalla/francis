package com.cg.java.day4;

public class divisible {

}

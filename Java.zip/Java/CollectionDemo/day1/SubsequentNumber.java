package com.cg.java.day1;

import java.util.Scanner;

public class SubsequentNumber {
	public static int number(int n) {
		int remainder, sum=0,reverse=0;
		while(n!=0) {
			remainder=n%10;
			sum=remainder+1;
			reverse=reverse*10+sum;
			n=n/10;
		}
		int or=reverse,sum1=0,remainder1;
		while(or!=0) {
			remainder1=or%10;
			sum1=sum1*10+remainder1;
			or=or/10;
		}
		return sum1;
	}
	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		System.out.println("enter n");
		int n=scanner.nextInt();
		SubsequentNumber subsequentnumber=new SubsequentNumber();
		int result=subsequentnumber.number(n);
		System.out.println(result);
	}	

}
	

  package com.cg.java.day1;

class Employee{
	
  private int id;
  private String name;
  private double salary;
  private String designation; 
  
  public void printEmployeedetails() {
	  System.out.println("id is:" + id);
	  System.out.println("name is:" + name);
	  System.out.println("salary is:" + salary);
	  System.out.
	  
	  
	  println("desig is:" + designation);
  }
  
public class EmployeeMain {
public void main(String[] args) {
	Employee employee = new Employee();
	 
}

}}

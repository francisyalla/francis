package com.cg.java.day1;

public class sum {

}

package com.cg.lab9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class HashMapEx1 {
	   public static List<Integer> getValues(Map<Integer, Integer> map){
	        
	        List<Integer> list = new ArrayList<>(map.values());
	        Collections.sort(list);
	        return list;
	    }
	    
	    
	    public static void main(String[] args) {
	        Map<Integer, Integer> map = new HashMap<>();
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.println("Enter Elements : ");
	        for(int i=0;i<5;i++)
	        {
	            int a = scanner.nextInt();
	            map.put(i,a);
	        }
	        
	        List<Integer> list = getValues(map);
	        Iterator<Integer> itr = list.iterator();
	        
	        System.out.println("Sorted List : ");
	        while(itr.hasNext())
	        {
	            System.out.println(itr.next());
	        }
	        scanner.close();
	    }
}

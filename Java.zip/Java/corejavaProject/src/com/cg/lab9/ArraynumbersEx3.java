package com.cg.lab9;

import java.util.HashMap;
import java.util.Map;

public class ArraynumbersEx3 {
	 

    public static Map<Integer, Integer> getSquares(int arr[])
    {
        Map<Integer, Integer> map = new HashMap<>();
        for(int i=0;i<arr.length;i++)
        {
            map.put(arr[i], arr[i]*arr[i]);
        }
        return map;
    }
    
    public static void main(String[] args) {
        
        int array[]= {9,7,5,4,3,8,3,1,4};
        System.out.println(getSquares(array));    
    }

 
}

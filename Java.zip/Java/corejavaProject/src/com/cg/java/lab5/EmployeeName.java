package com.cg.java.lab5;

import java.util.Scanner;

class UserDefinedException extends Exception{ 
	 UserDefinedException() {
		 System.out.println("name should not be blank");
	 }
	}

public class EmployeeName {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter FirstName");
		String s1=scanner.nextLine();
		System.out.println("Enter LastName");
		String s2=scanner.nextLine();
		try {
			if(s1!=null) {
				throw new UserDefinedException();
			}else {
				System.out.println(s1);
				}
			if(s2!=null) {	
				throw new UserDefinedException();
			}else 
				System.out.println(s2);
			
		}catch(Exception e) {
				
		
		}
			}{
				
			}
				
				}
		
	


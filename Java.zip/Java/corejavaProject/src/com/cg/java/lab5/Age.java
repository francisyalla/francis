package com.cg.java.lab5;

import java.util.Scanner;

class AgeException extends Exception{
	AgeException(){
		System.out.println("Age should be greaterthan fifteen");
	}
}

public class Age {

	public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter age");
	int age=scanner.nextInt();
	try {
		if(age<15)
			throw new AgeException();
		else 
			System.out.println("correct age" +age);
		}catch(AgeException e) {
	}
	}

}

package com.cg.java.lab5;

import java.util.Scanner;

public class TrafficLight {
	int RED=1, GREEN=2, YELLOW=3;
		static int s;
	public void method(int s) {
		switch (s) {
		case 1:
			System.out.println("Stop");
			break;
		case 2:
			System.out.println("Go");
			break;
		case 3:
			System.out.println("Ready");
			break;
			default:
				System.out.println("please enter valid choice");
				break;
		}
	}
		public static void main(String[] args ) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter your value");
		int s=scanner.nextInt();
		TrafficLight obj=new TrafficLight();
		obj.method(s);
		scanner.close();
		}
	}



package com.cg.java.lab2;

	abstract class Item{
	    private int id=121;
	    private String title="AAAA";
	    private int numberOfCopy=54;
	    
	    public Item() {
	        super();
	    }
	    public Item(int id, String title, int numberOfCopy) {

	 

	        this.id = id;
	        this.title = title;
	        this.numberOfCopy = numberOfCopy;
	    }
	    public int getId() {
	        return id;
	    }
	    public void setId(int id) {
	        this.id = id;
	    }
	    public String getTitle() {
	        return title;
	    }
	    public void setTitle(String title) {
	        this.title = title;
	    }
	    public int getNumberOfCopy() {
	        return numberOfCopy;
	    }
	    public void setNumberOfCopy(int numberOfCopy) {
	        this.numberOfCopy = numberOfCopy;
	    }
	    @Override
	    public String toString() {
	        return "Item [id=" + id + ", title=" + title + ", numberOfCopy=" + numberOfCopy + "]";
	    }
	    
	    
	}

	 

	abstract class WrittenItem extends Item{
	    private int authorId=222;
	    private String authorName="DDDD";
	    public WrittenItem() {
	        super();
	    }
	    public WrittenItem(int authorId, String authorName) {
	        super();
	        this.authorId = authorId;
	        this.authorName = authorName;
	    }
	    public int getAuthorId() {
	        return authorId;
	    }
	    public void setAuthorId(int authorId) {
	        this.authorId = authorId;
	    }
	    public String getAuthorName() {
	        return authorName;
	    }
	    public void setAuthorName(String authorName) {
	        this.authorName = authorName;
	    }
	    @Override
	    public String toString() {
	        return "WrittenItem [authorId=" + authorId + ", authorName=" + authorName + "]";
	    }
	}

	 


	class Book extends WrittenItem {
	    
	    public void setId(int num) { super.setId(num);} 
	    public void setTitle(String num) { super.setTitle(num);}
	    public void setNumberOfCopy(int num) { super.setNumberOfCopy(num);}
	    public void setAuthorId(int num) {super.setAuthorId(num);}
	    public void setAuthorName(String num) {super.setAuthorName(num);}
	    
	    public void bookInformation(){
	        System.out.println("Id = " + getId() + " \nTitle = " + getTitle() + "\nNumberOfCopy = " + getNumberOfCopy() + "\nAuthorId = " + getAuthorId() + " \nAuthorName = " + getAuthorName());
	    }
	}

	 


	class JournalPaper extends WrittenItem {
	    private int dateOfYear = 2012;

	 

	    public int getDateOfYear() {
	        return dateOfYear;
	    }
	    public void setDateOfYear(int dateOfYear) {
	        this.dateOfYear = dateOfYear;
	    }
	    public void setId(int num) { super.setId(num);} 
	    public void setTitle(String num) { super.setTitle(num);}
	    public void setNumberOfCopy(int num) { super.setNumberOfCopy(num);}
	    public void setAuthorId(int num) {super.setAuthorId(num);}
	    public void setAuthorName(String num) {super.setAuthorName(num);}
	    
	    public void journalInformation(){
	        System.out.println("Id = " + getId() + " \nTitle=" + getTitle() + "\nNumberOfCopy = " + getNumberOfCopy() + "\nAuthorId = " + getAuthorId() + " \nAuthorName = " + getAuthorName() + "\nDateOfYear = " + dateOfYear);
	    } 
	}

	 

	abstract class MediaItem extends Item{
	    private int runtime= 3;

	 

	    
	    public MediaItem() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	    
	    public MediaItem(int runtime) {
	        super();
	        this.runtime = runtime;
	    }

	 

	    public int getRuntime() {
	        return runtime;
	    }

	 

	    public void setRuntime(int runtime) {
	        this.runtime = runtime;
	    }
	    
	}

	 

	class Video extends MediaItem{
	    private int directorId = 21;
	    private String directorName = "ZZZ";
	    private String genre = "Thriller";
	    private int yearReleased = 4035;
	    public int getDirectorId() {
	        return directorId;
	    }
	    public void setDirectorId(int directorId) {
	        this.directorId = directorId;
	    }
	    public String getDirectorName() {
	        return directorName;
	    }
	    public void setDirectorName(String directorName) {
	        this.directorName = directorName;
	    }
	    public String getGenre() {
	        return genre;
	    }
	    public void setGenre(String genre) {
	        this.genre = genre;
	    }
	    public int getYearReleased() {
	        return yearReleased;
	    }
	    public void setYearReleased(int yearReleased) {
	        this.yearReleased = yearReleased;
	    }
	    
	    public void videoInformation(){
	        System.out.println("Id = " + getId() + " \nTitle = " + getTitle() +
	                        "\nNumberOfCopy = " + getNumberOfCopy() +  
	                        " \nRunTime = " + getRuntime() + "\nDirectorId = " + getDirectorId()+
	                        "\nDirectorName = " + getDirectorName() + "\nGenre = " + getGenre()+
	                        "\nYearReleased = " + getYearReleased()
	                    );
	    } 
	}

	 

	class CD extends MediaItem{
	    private int artistId = 33;
	    private String artistName = "RRR";
	    private String genre = "Comedy";
	    private int yearReleased = 7089;
	    
	    public int getArtistId() {
	        return artistId;
	    }
	    public void setArtistId(int artistId) {
	        this.artistId = artistId;
	    }
	    public String getArtistName() {
	        return artistName;
	    }
	    public void setArtistName(String artistName) {
	        this.artistName = artistName;
	    }
	    public String getGenre() {
	        return genre;
	    }
	    public void setGenre(String genre) {
	        this.genre = genre;
	    }
	    public int getYearReleased() {
	        return yearReleased;
	    }
	    public void setYearReleased(int yearReleased) {
	        this.yearReleased = yearReleased;
	    }
	    
	    public void cdInformation(){
	        System.out.println("Id = " + getId() + " \nTitle = " + getTitle() +
	                        "\nNumberOfCopy = " + getNumberOfCopy() +  
	                        " \nRunTime = " + getRuntime() + "\nArtistId = " + getArtistId()+
	                        "\nArtistName = " + getArtistName() + "\nGenre = " + getGenre()+
	                        "\nYearReleased = " + getYearReleased()
	                    );
	    }
	    
	}

	
	public class Excercise {

	    public static void main(String[] args) {
	        Book book = new Book();
	        book.setId(10);
	        book.bookInformation();
	        
	        System.out.println("\n");
	        
	        JournalPaper journalPaper = new JournalPaper();
	        journalPaper.setAuthorId(768);
	        journalPaper.journalInformation();
	        
	        System.out.println("\n");
	        
	        Video video = new Video();
	        video.setGenre("Ride");
	        video.videoInformation();
	        
	        System.out.println("\n");
	        
	        CD cd= new CD();
	        cd.setRuntime(56);
	        cd.cdInformation();
	        
	    }
}

package com.cg.java.lab;

import java.util.Scanner;

public class Summationjava {
    int result=0;
	   public int Sum(int n) {
		   for(int i=0;i<=n;i++) {
		   if(i%3==0||i%5==0)
			   result = result + i;
		   }
		   
		   return result;
		   
	   }
	public static void main(String[] args) {
		System.out.println("enter x value");
		Scanner scanner= new Scanner(System.in);
		int x = scanner.nextInt();
		Summationjava sum = new Summationjava();
		int result = sum.Sum(x);
		System.out.println("sum is :" + result);
	}

}

package com.cg.java.lab;

import java.util.Scanner;

public class PowerOfTwo {
	  public static boolean checkNumber(int n) {
	        
	        if (n == 0)
	            return false;
	        while (n != 1) {
	            if (n % 2 == 1)
	                return false;
	            n = n / 2;
	        }
	        return true;
	    }

	 

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("enter n");
	        int n = scanner.nextInt();
	        PowerOfTwo poweroftwo = new PowerOfTwo();
	        if (poweroftwo.checkNumber(n))
	            System.out.println(n + " is a power of 2");
	        else
	            System.out.println(n + " is not a power of 2");
	    }
}

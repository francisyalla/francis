package com.cg.lab10;

public class FileThreadJavaEx1 extends CopyDataThreadEx1{
	public FileThreadJavaEx1(String inputpath) {
		super();
		
	}

public static void main(String[] args) {
	FileThreadJavaEx1 fileProgram = new FileThreadJavaEx1("C:\\CoreJavaSpace\\CoreJava\\src\\com\\cg\\java\\lab10\\source.txt");
	fileProgram.run();
}
}

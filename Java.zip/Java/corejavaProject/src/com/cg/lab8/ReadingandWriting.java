package com.cg.lab8;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class ReadingandWriting {
	 public static void main(String[] args) throws IOException
     {
     Scanner keyboard = new Scanner(System.in);
     System.out.print("Enter a file name: ");
     String filename = keyboard.nextLine();



     File file = new File(filename);
     Scanner inputFile = new Scanner(file);
     String line = inputFile.nextLine();



     while (inputFile.hasNext()){
     String name = inputFile.nextLine();



     System.out.println(name);
     }



     inputFile.close();



     }


}

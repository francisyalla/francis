package com.cg.lab3;

import java.util.Scanner;

public class Alphabetical {
	 String temp;
	    String[] sort(String array[])
	    {
	        
	        for (int i = 0; i < array.length-1; i++) {
	            for (int j = i+1; j < array.length; j++) {
	                if(array[i].compareTo(array[j])>0)
	                {
	                    temp=array[i];
	                    array[i]=array[j];
	                    array[j]=temp;
	                }
	            }
	        }

	            if (array.length%2==0) {
	                for (int i = 0; i < array.length/2; i++) {
	                    array[i]=array[i].toUpperCase();
	                }
	                
	                }
	                else {
	                
	                for(int i=0;i<array.length/2+1;i++)
	                {
	                    array[i]=array[i].toUpperCase();
	                }

	   
	                }
	            return array;
	            
	    }
	    
	 public static void main(String[] args) {
	        Alphabetical sortString =new Alphabetical();
	        Scanner scanner=new Scanner(System.in);
	        System.out.println("enter the size of the array");
	        int size=scanner.nextInt();
	        String  array[]=new String[size];
	        System.out.println("enter  a string array elements");
	        for (int i = 0; i < array.length; i++) {
	            array[i]=scanner.next();
	        }
	        sortString.sort(array);
	        Alphabetical sortString2=new Alphabetical();
	        String result[]=sortString2.sort(array);
	        for (int i = 0; i < result.length; i++) {
	            
	        
	        System.out.println(result[i]);
	        }
	    }
	}


package com.cg.lab3;

import java.util.Scanner;

public class count {
	public static void main(String args[]) {
        count();
    }
    public static void count() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter string");
        String scanner1 = scanner.next();
                
        char ch[] = scanner1.toCharArray();
        
        //for(int i=0;i<ch.length;i++)
        //{
            //System.out.println(ch[i]);
        //}
        for(int i=0;i<ch.length;i++) {
            int c=0;
            for(int j=i;j<ch.length;j++) {
                if(ch[i]==ch[j]) {
                    c++;
                }
            }
            
            System.out.println(ch[i] +" " + c);    
        }
        
    }
}

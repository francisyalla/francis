package com.cg.lab3;

import java.util.Scanner;

public class ArrayReverse {

	    int temp;
	    int[] getSorted(int[] array)
	
{
for (int i = 0; i < array.length; i++) {
    String  ss=String.valueOf(array[i]);
    StringBuilder ss1=new StringBuilder();
    ss1.append(ss);
    ss1=ss1.reverse();
    String ss2=ss1.toString();
    array[i]=Integer.parseInt(ss2);
}
    for (int i = 0; i < array.length-1; i++) {
        for (int j = i+1; j < array.length; j++) {
            if(array[i]>array[j])
            {
                temp=array[i];
                array[i]=array[j];
                array[j]=temp;
            }
            
        }
    }
    return array;
}

public static void main(String[] args) {
    ArrayReverse arReverseSort=new ArrayReverse();
    Scanner scanner=new Scanner(System.in);
    System.out.println("enter the size");
    int size= scanner.nextInt();
    int array[]=new int[size];
    System.out.println("enter array elements");
    for (int i = 0; i < array.length; i++) {
        array[i]=scanner.nextInt();
    }
    int[] output=arReverseSort.getSorted(array);
    System.out.println("reversed and sorted array");
    for (int i = 0; i < array.length; i++) {
        System.out.println(output[i]);
    }
    







}






}

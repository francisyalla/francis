package com.cg.lab13;

import java.util.function.Predicate;

public class LamdaExpressionsEx3 {
	public static void main(String[] args) {
        Predicate<String> getUserName = (name) -> name == "Francis";
        Predicate<String> getPassword = (password) -> password == "7767778639";
        boolean result = getUserName.test("Francis");
        System.out.println(result);
        boolean result2 = getPassword.test("7766567779");
        System.out.println(result2);
    }
}

package com.cg.lab13;

@FunctionalInterface
interface StringSpace {
    String getString(String name);
}
public class LamdaExpressionsEx2 {
	 
	    public static void main(String[] args) {
	        StringSpace stringspace = (v) -> v.replace("", " ").trim();
	        String name = stringspace.getString("Francis");
	        System.out.println(name);
	    }
	}


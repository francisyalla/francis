package com.cg.lab13;

interface Power
{
    double calPower(double x,double y);
}
public class LamdaExpressionsEx1 {
	
	public static void main(String args[]) {
	    Power p=(x,y)->Math.pow(x,y);
	    double a=p.calPower(2,5);
	    System.out.println(a);
	}
	
}


	
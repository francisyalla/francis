package com.cg.lab4;

import java.util.Scanner;

public class Cubes {
	public int cubing(int number) {
        int remainder,result=0;
        while(number!=0) {
            remainder=number%10;
            result=result + remainder*remainder*remainder;
            number=number/10;
                
        }
        return result;
        
    }
        
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter value");
        Cubes cube=new Cubes();
        int number=scanner.nextInt();
        int result=cube.cubing(number);
        System.out.println("Cubing of number is :" + result);

 

    }

 

}
 


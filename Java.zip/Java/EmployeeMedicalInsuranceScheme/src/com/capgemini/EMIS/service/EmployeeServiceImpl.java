package com.capgemini.EMIS.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.capgemini.EMIS.bean.Employee;
import com.capgemini.EMIS.dao.EmployeeDaoImpl;
import com.capgemini.EMIS.exception.EmployeeException;

 
public class EmployeeServiceImpl implements EmployeeService {


    EmployeeDaoImpl employeeDao = new EmployeeDaoImpl();
    
    
    public int add(Employee employee) {
        int empId = (int) (Math.random()*1000);
        employee.setEmployeeId(empId);
        return employeeDao.addEmployee(employee);
    }

    public Employee getEmployee(int employeeId) {
        return employeeDao.getEmployee(employeeId);
    }

    
    public List<Employee> getemployees() {
        
        List<Employee> empList = new ArrayList<Employee>();
        Collection<Employee> collection = employeeDao.getEmployees().values();
        empList.addAll(collection);
        return empList;
    }
    
    public boolean isNameValid(String name) throws EmployeeException
    {
        Pattern namePtn = Pattern.compile("^[A-Z]{1}[A-Za-z]{1,}$");
        Matcher match = namePtn.matcher(name);
        if(match.matches())
        {
            return true;
        }
        throw new EmployeeException("1st Letter Capital");
    }
    
    public boolean isSalaryValid(int salary)
    {
        if(salary>0)
        {
            return true;
        }
        return false;
    }
    
    public boolean isChoiceValid(int choice) 
    {
        if(choice>=0 && choice<=4 )
        {
            return true;
        }
        return false;
    }
}

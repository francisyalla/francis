package com.capgemini.EMIS.presentation;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.EMIS.bean.Employee;
import com.capgemini.EMIS.exception.EmployeeException;
import com.capgemini.EMIS.service.EmployeeServiceImpl;


public class MainUI {
	  public static void main(String[] args) {
	        EmployeeServiceImpl eis = new EmployeeServiceImpl();
	        Scanner scanner1 = new Scanner(System.in);
	        Scanner scanner2 = new Scanner(System.in);
	        String option = null;
	        do {
	            int choice = 0;
	            boolean validate = false;
	            do {
	                System.out.println("\n1.Add\n2.ViewsbyID\n3.ViewAll\n0.Exit\nEnter Choice:");
	                try {
	                    choice = scanner1.nextInt();
	                    validate = eis.isChoiceValid(choice);
	                    if (!validate) {
	                        throw new EmployeeException();
	                    }
	                } catch (InputMismatchException | EmployeeException e) {
	                    System.err.println("\nWrong Input");
	                    scanner1.nextLine();
	                }
	            } while (!validate);
	            switch (choice) {
	            case 0: {
	                scanner1.close();
	                scanner2.close();
	                System.exit(0);
	            }
	            case 1: {
	                String employeeName = null;
	                boolean validate1 = false;
	                while (!validate1) {
	                    System.out.println("\nEnter FirstName : ");
	                    try {
	                        employeeName = scanner2.next();
	                        validate1 = eis.isNameValid(employeeName);
	                        if (!validate1) {
	                            throw new EmployeeException("(1st Letter capital)");
	                        }
	                    } catch (EmployeeException e1) {
	                        System.err.println(e1.getMessage());
	                    }
	                } 

	                int employeeSalary = 0;
	                boolean validate3 = false;
	                while (!validate3) {
	                    try {
	                        System.out.println("\nEnter Salary : ");
	                        employeeSalary = scanner1.nextInt();
	                        validate3 = eis.isSalaryValid(employeeSalary);
	                        if (!validate3) {
	                            throw new EmployeeException("\nSalary not less than Zero.");
	                        }
	                    } catch (InputMismatchException e) {
	                        scanner1.nextLine();
	                        System.err.println("\nOnly Numeric values");
	                    } catch (EmployeeException e1) {
	                        System.err.println(e1.getMessage());
	                    }
	                }

	                String insuranceScheme = null;
	                String designation = null;
	                if (employeeSalary > 5000 && employeeSalary < 20000) {
	                    designation = "System Associate";
	                    insuranceScheme = "Scheme C";
	                } else if (employeeSalary >= 20000 && employeeSalary < 40000) {
	                    designation = "Programmer";
	                    insuranceScheme = "Scheme B";
	                } else if (employeeSalary >= 40000) {
	                    designation = "Manager";
	                    insuranceScheme = "Scheme C";
	                } else if (employeeSalary < 5000) {
	                    designation = "Clerk";
	                    insuranceScheme = "No Scheme";
	                }
	                Employee employee = new Employee(0, employeeName, designation, employeeSalary, insuranceScheme);
	                int empID = eis.add(employee);
	                System.out.println("\nEmployee Detail's added Successfully => " + empID);
	                break;
	            }
	            case 2:
	                int empId=0;
	                boolean validate4 = false;
	                while (!validate4) 
	                {
	                    try {
	                        System.out.println("\nEnter customer Id to View");
	                        empId = scanner1.nextInt();
	                        validate4 = true;
	                    } catch (InputMismatchException e) {
	                        System.err.println("\nOnly Integer input");
	                        scanner1.nextLine();
	                    } 
	                }
	                Employee employee = eis.getEmployee(empId);
	                if(employee!=null)
	                System.out.println(employee);
	                else
	                    System.out.println("\nEmployee id doesn't exisits....");
	                break;

	            case 3:
	                List<Employee> employeeList = eis.getemployees();
	                System.out.println(employeeList);
	                break;
	            default:
	                break;
	            }
	            System.out.println("\nPress Y to continue");
	            option = scanner2.next();
	            System.out.println();
	        } while (option.equalsIgnoreCase("y"));
	    }
}

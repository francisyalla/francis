package com.capgemini.EMIS.bean;

public class Employee {


    private int employeeId;
    private String employeeName;
    private String designation;
    private int employeeSalary;
    private String insuranceScheme;

    public Employee() {
        super();
    }

    public Employee(int employeeId, String employeeName, String designation, int employeeSalary,
            String insuranceScheme) {
        super();
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.designation = designation;
        this.employeeSalary = employeeSalary;
        this.insuranceScheme = insuranceScheme;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getDesignation() {
        return designation;
    }

 

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public int getEmployeeSalary() {
        return employeeSalary;
    }

    public void setEmployeeSalary(int employeeSalary) {
        this.employeeSalary = employeeSalary;
    }

    public String getInsuranceScheme() {
        return insuranceScheme;
    }
    
    public void setInsuranceScheme(String insuranceScheme) {
        this.insuranceScheme = insuranceScheme;
    }

    @Override
    public String toString() {
        return "\nEmployeeId=" + employeeId + ", EmployeeName=" + employeeName + ", Designation=" + designation
                + ", EmployeeSalary=" + employeeSalary + ", InsuranceScheme=" + insuranceScheme;
    }
}

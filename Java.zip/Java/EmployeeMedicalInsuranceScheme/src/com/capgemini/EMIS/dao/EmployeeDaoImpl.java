package com.capgemini.EMIS.dao;

import java.util.Map;
import com.capgemini.EMIS.bean.Employee;

 
public class EmployeeDaoImpl implements EmployeeDAO {
	  @Override
	    public int addEmployee(Employee employee) {
	        employeeList.put(employee.getEmployeeId() , employee);
	        return employee.getEmployeeId() ;
	    }

	    @Override
	    public Employee getEmployee(int employeeId) {
	        //if(employeeId!=employeeList.get(employeeId))
	        return employeeList.get(employeeId);
	    }

	    @Override
	    public Map<Integer, Employee> getEmployees() {
	        return employeeList;
	    }
}

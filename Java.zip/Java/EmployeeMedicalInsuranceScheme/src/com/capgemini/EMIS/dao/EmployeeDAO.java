package com.capgemini.EMIS.dao;
import java.util.HashMap;
import java.util.Map;
import com.capgemini.EMIS.bean.Employee;

public interface EmployeeDAO {
Map<Integer, Employee> employeeList = new HashMap<>();
    
    int addEmployee(Employee employee);
    
    Employee getEmployee(int employeeId);
    
    Map<Integer, Employee> getEmployees();
}

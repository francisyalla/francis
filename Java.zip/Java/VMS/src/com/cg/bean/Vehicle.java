package com.cg.bean;

public class Vehicle {
	private int vehicleId;
	private String vehicleName;
	private double vehicleCost;
	private String vehicleCompany;
	public Vehicle() {
		super();
	}
	public Vehicle(int vehicleId, String vehicleName, double vehicleCost, String vehicleCompany) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleName = vehicleName;
		this.vehicleCost = vehicleCost;
		this.vehicleCompany = vehicleCompany;
	}
	public Vehicle(String vehicleName2, double vehicleCost2, String company) {
		this.vehicleName = vehicleName2;
		this.vehicleCost = vehicleCost2;
		this.vehicleCompany = company;
		}
	public int getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public double getVehicleCost() {
		return vehicleCost;
	}
	public void setVehicleCost(double vehicleCost) {
		this.vehicleCost = vehicleCost;
	}
	public String getVehicleCompany() {
		return vehicleCompany;
	}
	public void setVehicleCompany(String vehicleCompany) {
		this.vehicleCompany = vehicleCompany;
	}
	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", vehicleName=" + vehicleName + ", vehicleCost=" + vehicleCost
				+ ", vehicleCompany=" + vehicleCompany + "]";
	}


	}



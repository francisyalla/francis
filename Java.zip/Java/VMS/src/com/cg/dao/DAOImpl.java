package com.cg.dao;

public class DAOImpl implements DAO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

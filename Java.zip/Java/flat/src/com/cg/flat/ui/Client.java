package com.cg.flat.ui;

import java.util.Scanner;

import com.cg.flat.service.FlatRegistrationServiceImpl;
import com.cg.flat.service.IFlatRegistrationService;

public class Client {
	
	public static void main(String [] args) {
		System.out.println("********Welcome to Flat Registration App****** ");
		IFlatRegistrationService service=new FlatRegistrationServiceImpl();
		int choice=0;
		
		try {
			do {
				System.out.println("1. Add Registration Details");
				System.out.println("2. Display Details");
				System.out.println("3. Exit");
				Scanner scanner=new Scanner(System.in);
				choice=  scanner.nextInt();
			switch (choice) {
			case 1:
				do {
					System.out.println();
				}
				
				
				break;

			default:
				break;
			}	
				
		} catch ( e) {
			// TODO: handle exception
		}
	}
}

package com.cg.flat.dao;

import java.util.ArrayList;

import com.cg.flat.bean.RegistrationDetails;
import com.cg.flat.exception.FlatException;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {

	@Override
	public RegistrationDetails registerFlat(RegistrationDetails flat) throws FlatException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Integer> getOwnerdetails() {
		// TODO Auto-generated method stub
		return null;
	}
	
}

package com.cg.flat.exception;

public class FlatException extends Exception{
public FlatException(String message) {
	super(message);

}
}
package com.cg.flat.bean;

public class RegistrationDetails {
private String FlatType; 
private int FA;
private double RentAmount;
private double DepositAmount;
public RegistrationDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public RegistrationDetails(String flatType, int fA, double rentAmount, double depositAmount) {
	super();
	FlatType = flatType;
	FA = fA;
	RentAmount = rentAmount;
	DepositAmount = depositAmount;
}
public String getFlatType() {
	return FlatType;
}
public void setFlatType(String flatType) {
	FlatType = flatType;
}
public int getFA() {
	return FA;
}
public void setFA(int fA) {
	FA = fA;
}
public double getRentAmount() {
	return RentAmount;
}
public void setRentAmount(double rentAmount) {
	RentAmount = rentAmount;
}
public double getDepositAmount() {
	return DepositAmount;
}
public void setDepositAmount(double depositAmount) {
	DepositAmount = depositAmount;
}
@Override
public String toString() {
	return "RegistrationDetails [FlatType=" + FlatType + ", FA=" + FA + ", RentAmount=" + RentAmount
			+ ", DepositAmount=" + DepositAmount + "]";
}


}

package com.cg.flat.bean;

public class OwnerDetails {
	private int ownerId;
	private String ownerName;
	private long ownerNumber;
	public OwnerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OwnerDetails(int ownerId, String ownerName, long ownerNumber) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.ownerNumber = ownerNumber;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public long getOwnerNumber() {
		return ownerNumber;
	}
	public void setOwnerNumber(long ownerNumber) {
		this.ownerNumber = ownerNumber;
	}
	@Override
	public String toString() {
		return "OwnerDetails [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownerNumber=" + ownerNumber + "]";
	}

}

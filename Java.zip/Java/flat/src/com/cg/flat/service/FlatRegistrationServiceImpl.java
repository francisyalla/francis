package com.cg.flat.service;

import java.util.ArrayList;

import com.cg.flat.bean.RegistrationDetails;
import com.cg.flat.exception.FlatException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {

	
	@Override
	public RegistrationDetails registerFlat(RegistrationDetails flat) throws FlatException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Integer> getOwnerIds() {
		// TODO Auto-generated method stub
		return null;
	}

}

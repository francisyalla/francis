package com.cg.flat.service;

import java.util.ArrayList;

import com.cg.flat.bean.RegistrationDetails;
import com.cg.flat.exception.FlatException;

public interface IFlatRegistrationService {
	RegistrationDetails registerFlat(RegistrationDetails flat) throws FlatException;
	ArrayList<Integer>getOwnerIds();
}

package com.capgemini.customerportal.service;

import java.util.List;
import com.capgemini.customerportal.bean.Customer;

import cam.capgemini.customerportal.exception.CustomerPortalException;

public interface CustomerService {
	int addCustomer(Customer customer);
	boolean updateCustomer(Customer customer) throws CustomerPortalException;
	boolean deleteCustomer(int customerId) throws CustomerPortalException;
	Customer getcustomer(int customerId);
	List<Customer> getCustomers();	
	
}

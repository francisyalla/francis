package com.capgemini.customerportal.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.customerportal.bean.Customer;

public interface CustomerDAO {
	Map<Integer, Customer> customerList=new HashMap<>();
	
	int addCustomer(Customer customer);
	boolean updateCustomer(Customer customer);
	boolean deleteCustomer(int customerId);
	Customer getcustomer(int customerId);
	Map<Integer, Customer> getCustomers();	
	
}

package com.capgemini.customerportal.presentation;

import java.util.List;
import java.util.Scanner;

import com.capgemini.customerportal.bean.Customer;
import com.capgemini.customerportal.service.CustomerService;
import com.capgemini.customerportal.service.CustomerServiceImpl;
import cam.capgemini.customerportal.exception.CustomerPortalException;
/**
 * 
 * @author ryalla
 * @version 1.0
 * This is MainUI class taking user inputs
 * 
 */
public class MainUI {
	public static void main(String[] args) {
		CustomerServiceImpl service=new CustomerServiceImpl();
		Scanner scanner=new Scanner(System.in);
		String option=null;
		do {
	System.out.println("1.Add\n2.Update\n3.Delete\n4.ViewById\n5.ViewAll");
	int choice=scanner.nextInt();
	switch(choice){
	case 0: System.exit(0);	
	case 1:{
		System.out.println("Enter Name");
		String name=scanner.next();
		System.out.println("Enter Address");
		String address=scanner.next();
		System.out.println("Enter phone");
		long phone=scanner.nextLong();
		if(!service.isNameValid(name) || !service.isPhonevalid(phone))
			try {
				throw new CustomerPortalException("Invalid credentials");
			}catch (CustomerPortalException e) {
				System.err.println(e.getMessage());
			}
		
		Customer customer=new Customer(0,name,address,phone);
		int custId=service.addCustomer(customer);
		System.out.println("Customer Registered succesfully and your id is:"+ custId);
		
	}break;
	
	case 2:{
		System.out.println("Enter customer Id to update");
		int custId=scanner.nextInt();
		System.out.println("Enter name");
		String name=scanner.next();
		System.out.println("Enter Address");
		String address=scanner.next();
		System.out.println("Enter phone");
		long phone=scanner.nextLong();
		Customer customer=new Customer(custId,name,address,phone);
		try {
		boolean status=service.updateCustomer(customer);
		if(status) {
			System.out.println("Updated succesfully");
		}
		}catch (CustomerPortalException e) {
			System.out.println(e.getMessage());
		}
	}break;
	case 3:{
		System.out.println("Enter Customer id to delete");
		int custId=scanner.nextInt();
		try {
			boolean status=service.deleteCustomer(custId);
			if(status) {
				System.out.println(custId+ "deleted succesfully");
			}
			}catch (CustomerPortalException e) {
				System.out.println(e.getMessage());
			}		
		}break;
	
	case 4:{
		System.out.println("Enter Customer id to view");
		int custId=scanner.nextInt();
		Customer c=service.getcustomer(custId);
		System.out.println(c);
	}break;
	
	case 5:{
		List<Customer> customerList=service.getCustomers();
		System.out.println(customerList);
	}break;
	}
			System.out.println("press y to continue");
			option=scanner.next();
		} while (option.equalsIgnoreCase("y"));
			
		
		scanner.close();
	}

}

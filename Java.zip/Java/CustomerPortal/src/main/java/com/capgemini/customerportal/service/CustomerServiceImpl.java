package com.capgemini.customerportal.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.customerportal.bean.Customer;
import com.capgemini.customerportal.dao.CustomerDAO;
import com.capgemini.customerportal.dao.CustomerDaoImpl;

import cam.capgemini.customerportal.exception.CustomerPortalException;

public class CustomerServiceImpl implements CustomerService {

	CustomerDAO customerDao=new CustomerDaoImpl();
	
	@Override
	public int addCustomer(Customer customer) {
		int custId=(int)(Math.random()*1000);
		//Random rand=new Random(1000);
		customer.setCustomerId(custId);
		return customerDao.addCustomer(customer);
	}

	@Override
	public boolean updateCustomer(Customer customer) throws CustomerPortalException {
		boolean status=customerDao.updateCustomer(customer);
		if (status)		
		return status ;
		else {
			throw new CustomerPortalException("Customer id doesn't exists");
		}
	}

	@Override
	public boolean deleteCustomer(int customerId) throws CustomerPortalException {
		boolean status=customerDao.deleteCustomer(customerId);
		if (status)		
			return status ;
			else {
				throw new CustomerPortalException("Customer id doesn't exists to delete");
			}
	}

	@Override
	public Customer getcustomer(int customerId) {
		return customerDao.getcustomer(customerId);
	}

	@Override
	public List<Customer> getCustomers() {
		List<Customer> custList=new ArrayList<Customer>();
		Collection<Customer> collection=customerDao.getCustomers().values();
		custList.addAll(collection);
		return custList;
	
	}
	public boolean isNameValid(String name) {
		 Pattern nameptn=Pattern.compile("^[A-Z]{1}[a-z]{4,}$");

		Matcher matcher=nameptn.matcher(name);
		if (matcher.matches()) {
			return true;
		}
		return false;
}

	 public boolean isPhonevalid(long phone) {
		 String mobile=String.valueOf(phone);
	 Pattern nameptn=Pattern.compile("^[7-9]{1}[0-9]{9,}$");
	 Matcher match=nameptn.matcher(mobile);
	 if (match.matches()) {
		return true;
	}
	return false;
}
}

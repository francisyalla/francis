package com.capgemini.customerportal;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.capgemini.customerportal.bean.Customer;
import com.capgemini.customerportal.dao.CustomerDAO;
import com.capgemini.customerportal.dao.CustomerDaoImpl;

class CustomerDaoImolTest {
	static CustomerDAO dao;
	Customer customer;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao=new CustomerDaoImpl();
	}
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	dao=null;
	}
	@BeforeEach
	void setUp() throws Exception {
		customer=new Customer(123,"francis","banglore",9878456546L);
	}
	@AfterEach
	void tearDown() throws Exception {
		customer=null;
	}
	@Test
	void testAddCustomer() {
		assertEquals(123,dao.addCustomer(customer));
	}
	@Test
	void testUpdateCustomer() {
		int custId=dao.addCustomer(customer);
		customer=new Customer(custId,"Daniel","Mumbai",9879787987L);
		assertTrue(dao.updateCustomer(customer));
		}
	@Test
	void testDeleteCustomer() {
		int custId=dao.addCustomer(customer);
		assertTrue(dao.deleteCustomer(custId));
	}
	@Test
	void testGetcustomer() {
		int custId=dao.addCustomer(customer);
		assertNotNull(dao.getcustomer(custId));	}

	@Test
	void testGetCustomers() {
		dao.customerList.clear();
		int custId=dao.addCustomer(customer);
		assertEquals(1, dao.customerList.size());
	}
}
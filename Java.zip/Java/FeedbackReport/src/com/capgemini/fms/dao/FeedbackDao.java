package com.capgemini.fms.dao;

import java.util.Map;

public interface FeedbackDao {

	Map<String, Integer> addFeedbackDetails(String teacherName, int rating, String topic);

	Map<String, Integer> getFeedbackReport();

}

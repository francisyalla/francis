package com.capgemini.fms.service;

import java.util.Map;

import com.capgemini.fms.exception.FeedbackException;

public interface FeedbackService {

	boolean isNameValid(String teacherName)throws FeedbackException;

	boolean isRatingValid(int rating)throws FeedbackException;

	boolean isTopicValid(String topic)throws FeedbackException;

	Map<String, Integer> addFeedbackDetails(String teacherName, int rating, String topic);

	Map<String, Integer> getFeedbackReport();




}

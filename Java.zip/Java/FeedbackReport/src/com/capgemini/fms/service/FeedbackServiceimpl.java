package com.capgemini.fms.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.dao.FeedbackDao;
import com.capgemini.fms.dao.FeedbackDaoImpl;

public class FeedbackServiceimpl implements FeedbackService {
	FeedbackDao dao=new FeedbackDaoImpl();

	
	@Override
	public boolean isNameValid(String teacherName) throws FeedbackException{
		String regEx="^[A-Z]{1}[a-zA-z]{4,}$";
		boolean nameFlag=false;
		if(!Pattern.matches(regEx, teacherName)) {
			throw new FeedbackException("Name should start with capital and followed by 4 characters");
		}	
		else
			nameFlag=true;
		return nameFlag;
	}

	@Override
	public boolean isRatingValid(int rating) throws FeedbackException{
		boolean ratingFlag=false;
		if(rating<1 || rating>5)
			throw new FeedbackException("Rating should be between 1 and 5");
		else
			ratingFlag=true;
		return ratingFlag;
	}

	@Override
	public boolean isTopicValid(String topic) throws FeedbackException {
		boolean topicFlag=false;
		if(topic.equals("English") || topic.equals("Maths"))
			topicFlag=true;
		else
		    throw new FeedbackException("Topic should be English or Maths only");
		return topicFlag;
	
	}

	@Override
	public Map<String, Integer> addFeedbackDetails(String teacherName, int rating, String topic) {
		return dao.addFeedbackDetails(teacherName, rating, topic);

	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		return dao.getFeedbackReport();

	}

	

}

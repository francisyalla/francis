package com.capgemini.fms.ui;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.service.FeedbackService;
import com.capgemini.fms.service.FeedbackServiceimpl;
import com.capgemini.fms.bean.Feedback;

public class MainUI {

	public static void main(String[] args) {

		FeedbackService service=new FeedbackServiceimpl();
		Scanner scanner=null;
		int choice=0;
		int rating=0;
		String teacherName=" ";
		String topic=" ";
		boolean choiceFlag=false;
		boolean nameFlag=false;
		boolean ratingFlag=false;
		boolean topicFlag=false;
		boolean optionFlag=false;
		do {
			System.out.println("***Welcome to Feedback***");
			System.out.println("1.Add Feedback");
            System.out.println("2.Print Feedback Report");
            System.out.println("3.Exit");
            scanner=new Scanner(System.in);
            System.out.println("Enter Choice");
            try {
				choice=scanner.nextInt();
				
				switch (choice) {
				case 1:
					do {
						scanner=new Scanner(System.in);
						System.out.println("Enter Teacher Name");
						try {
							teacherName=scanner.next();
							service.isNameValid(teacherName);
							nameFlag=true;
						} catch (FeedbackException e) {
							 nameFlag=false;
		                        System.err.println(e.getMessage());
						}
					} while (!nameFlag);
					do {
						try {
							scanner=new Scanner(System.in);
                            System.out.println("Enter Rating");
                            rating=scanner.nextInt();
                            service.isRatingValid(rating);
                            ratingFlag=true;
						} catch (FeedbackException e) {
							 ratingFlag=false;
		                        System.err.println(e.getMessage());	
		                        }
					} while (!ratingFlag);
					do {
						try {
							 scanner=new Scanner(System.in);
	                            System.out.println("Enter Topic");
	                            topic=scanner.nextLine();
	                            service.isTopicValid(topic);
	                            topicFlag=true;
						} catch (Exception e) {
							topicFlag=false;
                            System.err.println(e.getMessage());						}
					} while (!topicFlag);
					
					System.out.println("Feedback Added");
					Feedback feed = new Feedback(teacherName, rating, topic);
					Map<String, Integer> map = new HashMap<String, Integer>();
					map = service.addFeedbackDetails(teacherName, rating, topic);
					System.out.println(map);
					break;
				case 2:
					Map<String, Integer> feedbackMap = service.getFeedbackReport();
					System.out.println(feedbackMap);

					break;
				case 3:
					System.out.println("Great to see you bye!");
					System.exit(0);
					break;
				default:
					break;
				}

				do {
					System.out.println("Do you want to continue yes/no");
					scanner = new Scanner(System.in);
					String option = scanner.nextLine();
					optionFlag = false;
					if (option.equalsIgnoreCase("yes")) {
						optionFlag = true;
						break;
					} else if (option.equalsIgnoreCase("no")) {
						optionFlag = false;
						System.out.println("Good Bye!"); 
						System.exit(0);
					} else {
						System.err.println("Enter only yes or no");
						optionFlag = false;
						continue;
					}

				} while (!optionFlag);
			} catch (InputMismatchException e) {
				System.err.println("Choice should be 1,2,3 only");
			}finally {
				scanner.close();
			}
            }while (!choiceFlag);
			
			
		
	}}
package com.cg;

public class LambdaClient {

	public static void main(String[] args) {
		Calculator findmax=(a,b)->a>b?a:b;
		double maximum=findmax.operation(52, 98);
		System.out.println("Maximum(52,98) is:"+maximum);
		Calculator add=(double a, double b)->a+b;
		Calculator sub=(a,b)->{return a-b;};
		Calculator mul=(a,b)->a*b;
		Calculator div=(x,y)->x/y;
		System.out.println("10+20="+add.operation(10, 20));
		System.out.println("10-20="+sub.operation(10, 20));
		System.out.println("10*20="+mul.operation(10, 20));
		System.out.println("10/20="+div.operation(10, 20));

		
		
		
	}

}

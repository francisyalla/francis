package com.cg;

import java.util.Scanner;

public class StringNumber {
	public static void string() {
		int id=58;
		String ss=String.valueOf(id);
		System.out.println(ss);
	}
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int num= scanner.nextInt();
		StringNumber sn=new StringNumber();
		sn.string();
	}

}

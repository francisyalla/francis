package com.cg;

@FunctionalInterface
public interface Greeting {

	String greet(String name);
	
}

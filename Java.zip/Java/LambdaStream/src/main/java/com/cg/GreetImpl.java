package com.cg;

public class GreetImpl implements Greeting {

	public String greet(String name) {
		
		return "From Normal - Welcome"+name;
	}

}

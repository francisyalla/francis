package com.cg;

import java.util.function.Consumer;
import java.util.function.Supplier;

class Product{
	String name="Computer";
	int price=30000;
}
interface Say{
	void sayMsg();
}
public class MethodReferenceDemo {
static void sayHi() {
	System.out.println("Welcome mesg from static method");
}
void bye () { 
System.out.println("thank you");
}
	public static void main(String[] args) {
Product p=new Product();
System.out.println("Name :"+p.name);
System.out.println("Price:"+p.price);
	
	Supplier<Product> p1=Product::new;
	System.out.println("Name :"+p1.get().name);
	System.out.println("Price :"+p1.get().price);
	Say say=MethodReferenceDemo::sayHi;
	say.sayMsg();
	
	//Consumer<String> consumer=(s)->System.out.println(s);
	Consumer<String> consumer=System.out::println;
	consumer.accept("Consumer prints hi");
	}

}

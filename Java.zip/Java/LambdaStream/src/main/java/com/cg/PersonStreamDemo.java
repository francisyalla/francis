package com.cg;

import java.util.Arrays;
import java.util.List;

public class PersonStreamDemo {

	public static void main(String[] args) {
		List<Person> people=Arrays.asList(
				new Person("francis", 22,Gender.MALE),
				new Person("anji", 24,Gender.MALE),
				new Person("gani", 23,Gender.MALE),
				new Person("prithvi", 21,Gender.MALE),
				new Person("vijay", 20,Gender.MALE),
				new Person("joy", 14,Gender.FEMALE));
	//print all person details
	people.stream().forEach(System.out::println);
		//print all female names
	people.stream().filter(p->p.getGender().equals(Gender.FEMALE))
	.map(p->p.getName()).forEach(System.out::println);
		//print all males names uppercase and age>18 using method references for map
	people.stream()
	.filter(p->p.getGender().equals(Gender.FEMALE))
	.map(Person::getName)
	.map(String::toUpperCase)
	.forEach(System.out::println);
	}

}

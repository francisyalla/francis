package com.cg;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;



public class DataIO {

	
		int[] eid= {11,22,33};
		String name[]= {"qwert","asdf","zxccv"};
		double salary[]= {2312,5644,5612};
		void mywrite() throws IOException {
		DataOutputStream dataio=new DataOutputStream(
		new BufferedOutputStream(new FileOutputStream("data.txt")));
		for (int i= 0; i < 3; i++){
			dataio.writeInt(eid[i]);
			dataio.writeUTF(name[i]);
			dataio.writeDouble(salary[i]);
			dataio.close();
			
		}
		}
		void myread() throws IOException{
			DataInputStream datainput=new DataInputStream(
			new BufferedInputStream(new FileInputStream("data.txt")));
			for (int i= 0; i < 3; i++){
			System.out.println(datainput.readInt()+" "+datainput.readUTF()+" "+datainput.readDouble());
				
		}
			datainput.close();}	
		public static void main(String[] args) {
		DataIO io=new DataIO();
		try {
			io.mywrite();
			io.myread();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	


		}}

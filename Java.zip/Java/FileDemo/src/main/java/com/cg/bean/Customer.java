package com.cg.bean;
import java.io.Serializable;

public class Customer implements Serializable{
	private static final long serialVersionUID=1L;
	private int custId;
	private String username ;
	transient private String pasword ;
	private long phone;
	public Customer() {
		super();
		
		
	}
	public Customer(int custId, String username, String pasword, long phone) {
		super();
		this.custId = custId;
		this.username = username;
		this.pasword = pasword;
		this.phone = phone;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPasword() {
		return pasword;
	}
	public void setPasword(String pasword) {
		this.pasword = pasword;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", username=" + username + ", pasword=" + pasword + ", phone=" + phone
				+ "]";
	}
	
	}



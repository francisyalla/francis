package com.cg;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;


public class ConsoleIO {

	public static void main(String[] args) {
	PrintWriter pw=new PrintWriter(System.out,true);
	BufferedReader br= new BufferedReader(
			new InputStreamReader(System.in));
	try {
		pw.println("Enter a value");
		int a=Integer.parseInt(br.readLine());
		pw.println("Enter b value");
		int b=Integer.parseInt(br.readLine());
		pw.println("sum="+(a+b));
		pw.println("Enter name");
		String name=br.readLine();
		pw.println("Welcome " +name);
		String s="Hello, welcome, to java, io,world";
		StringTokenizer st=new StringTokenizer(s);
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		StringTokenizer st1=new StringTokenizer(s,",");
		while (st1.hasMoreTokens()) {
			System.out.println(st1.nextToken());
	}
		
	}catch (NumberFormatException e) {
		e.printStackTrace();
	}catch (IOException e) {
		e.printStackTrace();

	}

	}}

package com.cg.client;

import java.io.FileNotFoundException;
import java.io.FileOutputStream ;
import java.io.FileInputStream ;
import java.io.IOException ;
import java.io.ObjectOutputStream ;
import java.io.ObjectInputStream ;

import com.cg.bean.Customer;

public class SerializationClient {
	
	void serialize() {
			try(FileOutputStream fos=new FileOutputStream("serialize.txt");
			ObjectOutputStream oos=new ObjectOutputStream(fos);)
{
				Customer customer1=new Customer(123,"francis", "abc123", 738228942);
				oos.writeObject(customer1);
				oos.flush();
				System.out.println("Object saved?serialized");
				
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
}
			}

			void deserialize() {
					try(FileInputStream fis=new FileInputStream("serialize.txt");
					ObjectInputStream ois=new ObjectInputStream(fis);)
		{
						Customer customer1= (Customer)ois.readObject();
						System.out.println(customer1);
						
			}catch (FileNotFoundException e) {
					e.printStackTrace();
			}catch (IOException e) {
					e.printStackTrace();
					
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
					}
			public static void main(String[] args) {
				SerializationClient client=new SerializationClient();
				client.serialize();
				client.deserialize();

				// TODO Auto-generated method stub

			}
			
	
			
	}


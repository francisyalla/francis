
package com.cg;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NameValidation {

		
		static Pattern nameptn=Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		static boolean validateName(String name) {
			Matcher matcher=nameptn.matcher(name);
			if (matcher.matches()) {
				return true;
			}
			return false;
		
	}
		public static void main(String[] args) {
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter name");
			String name=scanner.next();
			if(validateName(name)) {
				System.out.println("Name is valid");
			}else 
				System.out.println("Name is invalid...");
		}
		
}

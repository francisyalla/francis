package com.cg;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileRW {
	
	public static void main(String[] args) {
	FileInputStream fin=null;
	FileOutputStream fout=null;
	int line=0;
	
	try {
		fin=new FileInputStream("src/main/java/com/cg/FileDemo.java");
		fout=new FileOutputStream("src/main/java/my.doc");
		int i=0;
		while(i!=-1)
		{	
			i=fin.read();
			fout.write(i);
			System.out.print((char)i);
			if(i=='\n') {
				line++;
			}
		}
		System.out.println(line);
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	}

}

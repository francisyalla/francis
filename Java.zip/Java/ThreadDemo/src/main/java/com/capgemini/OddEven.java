package com.capgemini;

public class OddEven implements Runnable {
	
	public void run() {
		for (int i = 1; i<=10; i++) {
			if (Thread.currentThread().getName().equals("odd")&& (i%2!=0)) {
				System.out.println(Thread.currentThread().getName()+"==>"+i);
			}else if (Thread.currentThread().getName().equals("even")&& (i%2==0)) {
			System.out.println(Thread.currentThread().getName()+"==>"+i);	
	}}
	}
	public static void main(String[] args) {
		OddEven odd1=new OddEven();
		OddEven even1=new OddEven();
		Thread odd=new Thread(odd1);
		odd.setName("odd");
		Thread even=new Thread(even1);
		odd.setName("even");
		odd.start();
		even.start();
	}}

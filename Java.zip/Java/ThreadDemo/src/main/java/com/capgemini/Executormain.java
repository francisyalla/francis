package com.capgemini;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Executormain {

	public static void main(String[] args) {
		MyTask task=new MyTask();
		Thread t=new Thread(task);
		t.start();
		//ExecutorService es=new Executors.newSingleThreadPool();
		//ExecutorService es=new Executors.newFixedThreadPool(3);
		ExecutorService es=new Executors.newCachedThreadPool();

		
	}

}

package com.capgemini;

public class TwoString {

	 public void display(String s1,String s2) {
		 synchronized(this) {
		System.out.println(s1+"=>");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(s2);
		
	}
	
	
}
}
package com.capgemini.gst.service;

import java.util.List;

import com.capgemini.gst.bean.GSTBean;
import com.capgemini.gst.exception.GSTException;

public interface GSTService {

	boolean isNameValid(String productName) throws GSTException;


	boolean isWeightValid(int productWeight) throws GSTException;


	boolean isDistanceValid(int productDistance) throws GSTException;


	int addProduct(GSTBean product) throws GSTException;


	double getTransportCharge(int productDistance, int productWeight);


	List<GSTBean> getAllProducts() throws Exception;


	double getGST(double transportCharges);



}

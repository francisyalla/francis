package com.capgemini.gst.bean;

public class GSTBean {
	private int productId; 
	private String productname;
	private int productWeight;
	private int Distance;
	public GSTBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getProductWeight() {
		return productWeight;
	}
	public void setProductWeight(int productWeight) {
		this.productWeight = productWeight;
	}
	public int getDistance() {
		return Distance;
	}
	public void setDistance(int distance) {
		Distance = distance;
	}
	public GSTBean(int productId, String productname, int productWeight, int distance) {
		super();
		this.productId = productId;
		this.productname = productname;
		this.productWeight = productWeight;
		Distance = distance;
	}
	public GSTBean(String productname, int productWeight, int distance) {
		super();
		this.productname = productname;
		this.productWeight = productWeight;
		Distance = distance;
	}
	@Override
	public String toString() {
		return "GSTBean [productId=" + productId + ", productname=" + productname + ", productWeight=" + productWeight
				+ ", Distance=" + Distance + "]";
	}
	
	
	
}

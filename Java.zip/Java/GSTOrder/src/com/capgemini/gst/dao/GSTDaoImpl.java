package com.capgemini.gst.dao;

import java.util.Map;

import com.capgemini.gst.bean.GSTBean;
import com.capgemini.gst.utility.ProductDetails;

public class GSTDaoImpl implements GSTDao {
	Map<Integer, GSTBean>map=ProductDetails.getProductlist();

	
	public int addProduct(GSTBean product) {
		int generatedId=(int) (Math.random()*1000);
		product.setProductId(generatedId);
		map.put(generatedId,product);
		return generatedId;
		
	}

	@Override
	public double getTranportcharge(int productDistance, int productWeight) {
		double transportCharges=2*productDistance*productWeight;
		return transportCharges;
	}

	
	@Override
	public Map<Integer, GSTBean> getAllProducts() throws Exception {
		return ProductDetails.getProductlist();
		
	}

	@Override
	public double getGST(double transportCharges) {
		double CGST=(transportCharges*3.5)/100;
		double SGST=(transportCharges*3.5)/100;
		double GST=CGST+SGST;
		return GST;
	}

}

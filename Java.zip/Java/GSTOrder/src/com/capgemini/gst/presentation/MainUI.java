package com.capgemini.gst.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.gst.service.GSTService;
import com.capgemini.gst.service.GSTServiceImpl;
import com.capgemini.gst.bean.GSTBean;
import com.capgemini.gst.exception.GSTException;

public class MainUI {
	
	public static void main(String[] args) {
		String option=null;
		System.out.println("*****Welcome to GST****");
				
		GSTService service=new GSTServiceImpl();
		Scanner scanner=null;
		int choice=0;
		String productName=" ";
		int productWeight=0;
		int productDistance=0;
		int generatedId=0;
		boolean nameFlag=false;
		boolean weightFlag=false;
		boolean distanceFlag=false;
		boolean optionFlag=false;
		boolean choiceFlag=false;
		
		try {
			do {
				System.out.println("1.Add product");
				System.out.println("2.Get All Products");
				System.out.println("3.Exit");
				scanner=new Scanner(System.in);
				choice = scanner.nextInt();
			//	choiceFlag=true;
				switch (choice) {
				case 1:{
					try {
						scanner=new Scanner(System.in);
						System.out.println("Enter productName");
						productName=scanner.nextLine();
						service.isNameValid(productName);
						nameFlag=true;
					} catch (GSTException e) {
						nameFlag=false;
						System.err.println(e.getMessage());
					}
				} while (!nameFlag);
					do {
						try {
							scanner=new Scanner(System.in);
							System.out.println("Enter productWeight");
							productWeight=scanner.nextInt();
							service.isWeightValid(productWeight);
							weightFlag=true;
						} catch (GSTException e) {
							weightFlag=false;
							System.err.println(e.getMessage());
						} 
					} while (!weightFlag);
						do {
							try {
								scanner=new Scanner(System.in);
								System.out.println("Enter productDistance");
								productDistance=scanner.nextInt();
								service.isDistanceValid(productDistance);
								distanceFlag=true;
							} catch (GSTException e) {
								distanceFlag=false;
								System.err.println(e.getMessage());
							} 
						} while (!distanceFlag);				
		
				GSTBean product=new GSTBean(productName,productWeight,productDistance);
				try {
					generatedId=service.addProduct(product);
					double transportCharges=service.getTransportCharge(productDistance,productWeight);
					double GST=service.getGST(transportCharges);
					System.out.println("Product added with id is:"+generatedId);
					System.out.println("Transport charges for the product is:"+transportCharges);
					System.out.println("GST for the product is:"+GST);
					} catch (Exception e) {
						System.err.println(e.getMessage());
					}
					break;
					
			case 2:{
				
					List<GSTBean> products=null;
					try {
						products = service.getAllProducts();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					Iterator<GSTBean> iterator = products.iterator();
					while (iterator.hasNext()) {
						System.out.println(iterator.next());
						
					}
			}
				break;
			case 3:
				System.out.println("Great to see you bye!");
				System.exit(0);
				break;	

			default:
				System.err.println("Enter 1,2 or 3 only");
				break;
			}
		
				System.out.println("Do you want to continue yes/no");
				scanner = new Scanner(System.in);
				 option = scanner.next();
			
		} while (option.equalsIgnoreCase("yes"));
	} catch (InputMismatchException e) {
		System.err.println("Please enter digits only");
	}finally {
		scanner.close();
	}
}

}

package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileDAO {

	List<Mobiles> getAllMobiles();

	boolean deleteMobile(int mobileId);


}

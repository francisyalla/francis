package com.cg.mobshop.exception;

public class MobileException extends Exception{

	public MobileException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}

package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductService {

	boolean isCategoryValid(String productCategory)throws ProductException;

	boolean isHikeValid(int hike)throws ProductException;

	boolean updateProducts(String productCategory, int hike);
	Map<String, Integer> getProductDetails();


}

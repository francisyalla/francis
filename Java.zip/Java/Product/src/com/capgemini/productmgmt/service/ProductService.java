package com.capgemini.productmgmt.service;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public class ProductService implements IProductService {

	@Override
	public boolean isCategoryValid(String productCategory) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isHikeValid(int hike) throws ProductException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateProducts(String productCategory, int hike) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Map<String, Integer> getProductDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
}

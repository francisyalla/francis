package com.capgemini.productmgmt.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale.Category;
import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {
	static Map<String, String> productDetails;
	static Map<String, Integer> salesDetails;
	static {
		productDetails=new HashMap<>();
		productDetails.put("lux", "soap");
		productDetails.put("colgate", "paste");
		productDetails.put("pears", "soap");
		productDetails.put("sony", "electronics");
		productDetails.put("samsung", "electronics");
		productDetails.put("facepack", "cosmatics");
		productDetails.put("facecream", "cosmatics");
		
		salesDetails=new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 600);

	}
	@Override
	public int updateProducts(String category, int hike) throws ProductException {
		  List<String> categoryList=new ArrayList();
	        Collection<String> collection=productDetails.keySet();
	        categoryList.addAll(collection);
	        Iterator<String> iterator=categoryList.iterator();
	        while(iterator.hasNext()) {
	            String key=iterator.next().toString();
	            String value=productDetails.get(key);
	            if(value.equalsIgnoreCase(category)) {
	                int o=salesDetails.get(key);
	                int h1=(hike*o)/100;
	                int h=o+h1;
	                salesDetails.replace(key,o,h);
	            }
	        }
	        return hike;
		}
		
	
	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		
		
		return null;
	}
}

package com.capgemini.productmgmt.dao;

import java.util.Map;

import com.capgemini.productmgmt.exception.ProductException;

public interface IProductDAO {

	int updateProducts(String category, int hike) throws ProductException;
	
	Map<String, Integer>getProductDetails() throws ProductException;
}

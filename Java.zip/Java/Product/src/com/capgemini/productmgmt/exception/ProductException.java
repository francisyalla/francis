package com.capgemini.productmgmt.exception;

public class ProductException extends Exception{

	public ProductException(String message) {
		super(message);
	}

}

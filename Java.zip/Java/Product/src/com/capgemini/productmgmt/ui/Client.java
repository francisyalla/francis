package com.capgemini.productmgmt.ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.productmgmt.exception.ProductException;
import com.capgemini.productmgmt.service.IProductService;
import com.capgemini.productmgmt.service.ProductService;

public class Client {

	public static void main(String[] args) {
		
		IProductService service=new ProductService();
		
		Scanner scanner=new Scanner(System.in);
		int choice=0;
		boolean choiceFlag=false;
		boolean categoryFlag=false;
		boolean hikeFlag=false;
		String productCategory=" ";
		int hike=0;
		do {
			System.out.println("****Welcome to Product Details***");
			System.out.println("1.Update Product Price");
			System.out.println("2.Display Product list");
			System.out.println("3.Exit");
			scanner=new Scanner(System.in);
			System.out.println("Enter your choice");
			try {
				choice=scanner.nextInt();
				switch (choice) {
				case 1:{
					do {
						scanner=new Scanner(System.in);
						System.out.println("Enter the Product Category");
						try {
							productCategory=scanner.next();
							service.isCategoryValid(productCategory);
							categoryFlag=true;
						} catch (ProductException e) {
							categoryFlag=false;
	                        System.err.println(e.getMessage());

						}
					} while (!categoryFlag);
					do {
						try {
							System.out.println("Enter hike Rate : ");
							scanner = new Scanner(System.in);
							hike = scanner.nextInt();
							service.isHikeValid(hike);
							hikeFlag = true;
						} catch (ProductException e) {
							System.err.println(e.getMessage());
							hikeFlag = false;
							scanner.nextLine();
						} catch (InputMismatchException e) {
							System.err.println("\nInput should contain only digits");
							hikeFlag= false;
							scanner.nextLine();
						}
					} while (!hikeFlag);
					service.updateProducts(productCategory, hike);
				}
					break;
			case 2:{
				Map<String, Integer> productMap = service.getProductDetails();
				List<String> list = new ArrayList<>();
				Collection<String> collection = productMap.keySet();
				list.addAll(collection);
				Iterator<String> iterator = list.iterator();
				System.out.println("\nProduct Details");
				while (iterator.hasNext()) {
					String key = iterator.next().toString();
					System.out.println(key + " : " + productMap.get(key));
				}
			}
				break;
			case 3:{
				scanner.close();
				System.exit(0);
			}
				break;
		
				}
			}catch (Exception e) {
				// TODO: handle exception
			}
			
		} while (choiceFlag);
			}
	


}
	

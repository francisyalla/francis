package com.cg.eis.dao;

public interface EmployeeDAO {

}

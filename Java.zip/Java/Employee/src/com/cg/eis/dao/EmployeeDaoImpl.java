package com.cg.eis.dao;

public class EmployeeDaoImpl {

}

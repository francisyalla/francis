package com.cg.eis.bean;

	public class Employee {
		private int employeeId; 
		private int employeesalary;
		private String employeename;
		private String designation;
		private String insurancescheme;
		
		public Employee() {
			super();


}

		public Employee(int employeeId, int employeesalary, String name, String designation, String insurancescheme) {
			super();
			this.employeeId = employeeId;
			this.employeesalary = employeesalary;
			this.employeename = employeename;
			this.designation = designation;
			this.insurancescheme = insurancescheme;
		}

		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		public int getEmployeesalary() {
			return employeesalary;
		}

		public void setEmployeesalary(int employeesalary) {
			this.employeesalary = employeesalary;
		}

		public String getName() {
			return employeename;
		}

		public void setName(String name) {
			this.employeename = name;
		}

		public String getDesignation() {
			return designation;
		}

		public void setDesignation(String designation) {
			this.designation = designation;
		}

		public String getInsurancescheme() {
			return insurancescheme;
		}

		public void setInsurancescheme(String insurancescheme) {
			this.insurancescheme = insurancescheme;
		}

		@Override
		public String toString() {
			return "Employee [employeeId=" + employeeId + ", employeesalary=" + employeesalary + ", name=" + employeename
					+ ", designation=" + designation + ", insurancescheme=" + insurancescheme + "]";
		}
		
		
		
		
		
		
		
}
package com.cg.product.service;

import com.cg.product.Exception.LCException;

public interface LocalCurrencyService {

	boolean  IsNameValid(String productName)throws LCException;

}

package com.cg.product.presentation;

import java.util.Scanner;

import com.cg.product.bean.Product;
import com.cg.product.service.LocalCurrencyService;
import com.cg.product.service.LocalCurrencySeviceImpl;

public class ClientUI {
	
public static void main (System[] args) {
	System.out.println("**********Welcome to Local currency*******");
	LocalCurrencyService service= new LocalCurrencySeviceImpl();
	
	Scanner scanner=null;
	String productName="";
	boolean nameFlag=false;
	do {
		System.out.println("1 Add product details");
		System.out.println("2 Show Product details by ProductId");
		System.out.println("3 Show All Products");
		System.out.println("4 Exit");
		
		int choice = 0;
		boolean choiceFlag = false;
		scanner = new Scanner(System.in);
		choice = scanner.nextInt();
		
		switch (choice) {
		case 1:
			do {
				System.out.println("Enter Product Name");
				try {
					productName=scanner.nextLine();
					service.IsNameValid(productName);
					nameFlag= false;
				} catch (Exception e) {
					// TODO: handle exception
				}
					
					
				
				
				
				
				
			} while (choiceFlag);
			
			break;

		default:
			break;
		}
		
		
		
	}
		
		
}
	
	
	
	
	
	
	
	
	
	
	
	
	



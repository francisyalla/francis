package com.cg.product.dao;

public interface ProductDao {

}

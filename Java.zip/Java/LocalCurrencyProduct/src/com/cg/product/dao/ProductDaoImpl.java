package com.cg.product.dao;

public class ProductDaoImpl implements ProductDao {

}

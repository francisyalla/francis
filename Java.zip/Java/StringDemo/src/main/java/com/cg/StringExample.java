package com.cg;

public class StringExample {
	
	public static void main(String[] args) {
		String s1="Hi";
		String s2="Hi";
		String s3=new String("Hi");
		String s4=new String("Hi");
		System.out.println("s1==s2:"+s1.equals(s2));
		System.out.println("s1==s3:"+s1.equals(s3));
		System.out.println("s3==s4:"+s3.equals(s4));
		s1=s1.concat("welcome");
		System.out.println(s1);
		System.out.println(s1.length());
		System.out.println(s1.substring(3));
		System.out.println(s1.substring(4,8));
	}

}

package com.capgemini.employee.presentation;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.employee.bean.Employee;
import com.capgemini.employee.service.EmployeeService;
import com.capgemini.employee.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {

		EmployeeService service = new EmployeeServiceImpl();

		System.out.println("Welcome To Employee");
		Scanner scanner = null;

		int choice = 0;
		int employeeId=0;
		int generatedId=0;
		String empName = "";
		double empSalary = 0;
		String designation = "";
		boolean choiceFlag = false;
		do {
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.View By Id Employee");
			System.out.println("5.Display All Employee");
			System.out.println("6.Exit");

			scanner = new Scanner(System.in);
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				scanner = new Scanner(System.in);
				System.out.println("Enter Employee Name");
				empName = scanner.nextLine();
				System.out.println("Enter Employee Salary");
				empSalary = scanner.nextDouble();
				System.out.println("Enter Employee Designation");
				scanner.nextLine();
				designation = scanner.nextLine();
				
				Employee employee=new Employee(0,empName,empSalary,designation);
				generatedId=service.addEmployee(employee);
				System.out.println("Employee added successfully with Id: " + generatedId);
				
				break;
			case 2:System.out.println("Enter the Employee Id to update");
					employeeId=scanner.nextInt();
					service.updateEmployee(employeeId);

				break;
			case 3:System.out.println("Enter Id to delete");
					employeeId=scanner.nextInt();
					service.deleteEmployee(employeeId);
					System.out.println("�mployee deleted successfully");
				break;
			case 4:
				System.out.println("Enter Id to View");
				employeeId=scanner.nextInt();
				Employee employee2=service.viewById(employeeId);
				System.out.println(employee2);
				break;
			case 5:
				Map<Integer, Employee> map1=service.displayAll();
				Iterator<Integer> iterator=map1.keySet().iterator();
				while (iterator.hasNext()) {
					int id= iterator.next();
					Employee employee1=map1.get(id);
					System.out.println(id  + ":" + employee1);	
				}
				
				break;
			case 6:
				System.out.println("Thank you for visiting");
				System.exit(0);
				break;
			default:
				System.err.println("Enter only 1 to 6");
				break;
			}
		} while (!choiceFlag);
	}

}

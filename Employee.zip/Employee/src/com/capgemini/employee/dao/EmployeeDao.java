package com.capgemini.employee.dao;

import java.util.Map;

import com.capgemini.employee.bean.Employee;

public interface EmployeeDao {

	int addEmployee(Employee employee);

	boolean updateEmployee(int employeeId);

	Map<Integer, Employee> displayAll();

	boolean deleteemployee(int employeeId);

	Employee viewById(int employeeId);

	

}

package com.capgemini.employee.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.employee.bean.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
	Map<Integer, Employee> map=new HashMap<>();

	@Override
	public int addEmployee(Employee employee) {
		
		int generatedId=(int) (Math.random()*1000);
		employee.setEmployeeId(generatedId);
		map.put(generatedId, employee);
		
		return generatedId;
	}

	@Override
	public boolean updateEmployee(int employeeId) {
		//map.replace(employeeId, newValue)
		return false;
	}

	@Override
	public Map<Integer, Employee> displayAll() {
		
		return map;
	}

	@Override
	public boolean deleteemployee(int employeeId) {
		map.remove(employeeId);
		return false;
	}

	@Override
	public Employee viewById(int employeeId) {
		
		return map.get(employeeId);
	}

	

	

}

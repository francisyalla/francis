package com.capgemini.employee.exception;

public class EException extends Exception{

	public EException(String message) {
		super(message);
		
	}
	

}

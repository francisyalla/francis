package com.capgemini.employee.service;

import java.util.Map;

import com.capgemini.employee.bean.Employee;
import com.capgemini.employee.dao.EmployeeDao;
import com.capgemini.employee.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService{
	
	EmployeeDao dao=new EmployeeDaoImpl();

	@Override
	public int addEmployee(Employee employee) {
		
		return dao.addEmployee(employee);
	}

	@Override
	public boolean updateEmployee(int employeeId) {
		
		return dao.updateEmployee(employeeId);
	}

	@Override
	public Map<Integer, Employee> displayAll() {
		
		return dao.displayAll();
	}

	@Override
	public boolean deleteEmployee(int employeeId) {
		
		return dao.deleteemployee(employeeId);
	}

	@Override
	public Employee viewById(int employeeId) {
		
		return dao.viewById(employeeId);
	}

	
	
	
}

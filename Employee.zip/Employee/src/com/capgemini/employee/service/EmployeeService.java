package com.capgemini.employee.service;



import java.util.Map;

import com.capgemini.employee.bean.Employee;

public interface EmployeeService {

	int addEmployee(Employee employee);

	boolean updateEmployee(int employeeId);

	Map<Integer, Employee> displayAll();

	boolean deleteEmployee(int employeeId);

	Employee viewById(int employeeId);

	

}

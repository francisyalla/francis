package com.cg.fms.dao;

import java.util.HashMap;
import java.util.Map;

public class FeedbackDAO implements IFeedbackDAO {
	static	Map<String, Integer> mathFeedBackMap=new HashMap<String, Integer>();
	static	Map<String, Integer> englishFeedBackMap=new HashMap<String, Integer>();
	static Map<String, Integer> feedbackMap=new HashMap<String, Integer>();

	@Override
	public Map<String, Integer> addFeedbackDetails(String teacherName, int rating, String topic) {
		if(topic.equalsIgnoreCase("Maths")) {
			if(feedbackMap.containsKey(teacherName)) {
				if(rating<feedbackMap.get(teacherName))
				{
					feedbackMap.put(teacherName, feedbackMap.get(teacherName));
				}
				else {
					feedbackMap.put(teacherName, rating);
				}
			}
			else {
				feedbackMap.put(teacherName, rating);
			}
			mathFeedBackMap.put(teacherName, rating);
			return mathFeedBackMap;
		}
		else {
			if(feedbackMap.containsKey(teacherName)) {
				if(rating<feedbackMap.get(teacherName)) {
					feedbackMap.put(teacherName, feedbackMap.get(teacherName));
				}
				else {
					feedbackMap.put(teacherName, rating);
				}
			}
			else {
				feedbackMap.put(teacherName, rating);
			}
			englishFeedBackMap.put(teacherName, rating);
			return englishFeedBackMap;
		}
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		return feedbackMap;
	}

}

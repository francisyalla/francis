package com.cg.fms.dao;

import java.util.Map;

public interface IFeedbackDAO {

	Map<String, Integer> addFeedbackDetails(String teacherName, int rating, String topic);

	Map<String, Integer> getFeedbackReport();

}

package com.cg.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.dao.EmployeeRepository;
import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
/**
 * 
 * @author ryalla
 *Date of creation 21-08-2019
 *class Employee Service Implementation
 */
@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository empdao;
	/**
	 * Author:
	 * Date:
	 * Method name:
	 * Parameters:Nil
	 * return value : List of emplpoyees
	 * purpose to 
	 */
	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		try {
			return empdao.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
}
	}
	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		try {
			Optional<Employee> data=empdao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new EmployeeException("Employee with Id "+id+"does not exist");
			}
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		try {
			if(employee.getAge()>55) {
				throw new EmployeeException("Age cannot exceed 55");
			}
			if(employee.getDepartment().equals("IT")||employee.getDepartment().equals("Sales")||employee.getDepartment().equals("HR")) {
				
			}else {
				throw new EmployeeException("Department should be either IT,Sales or HR");
			}
			empdao.save(employee);
			return getAllEmployees();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}
	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		
		if (empdao.existsById(id)) {
			empdao.deleteById(id);
			return getAllEmployees();
		} else {
			throw new EmployeeException("cannot Delete. Employee with Id "+id+" does not exist");
		}
	}
	@Override
	public List<Employee> updateEmployee(int id,Employee employee) throws EmployeeException {
		if (empdao.existsById(id)) {
			
			empdao.save(employee);
			return getAllEmployees();
		} else {
			throw new EmployeeException("Invalid Employee,cannot be updated");
		}
	}
	@Override
	public List<Employee> getEmployeeByDepartment(String deptName) throws EmployeeException {
		// TODO Auto-generated method stub
		return empdao.getEmployeeByDepartment(deptName);
	}

}

package com.cg.prod.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.prod.dao.ProductRepository;
import com.cg.prod.dto.Product;
import com.cg.prod.exception.ProductException;

@Service 
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository proddao;
	
	@Override
	public List<Product> getAllProducts() throws ProductException {		
		try {
			return proddao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	@Override
	public List<Product> addProduct(Product product) throws ProductException {
		try {
			
			if(product.getPrice() < 1) {
                throw new ProductException("Price should be greater than 0");
                }
            if(product.getCategory().equals("Mobile") ||
            product.getCategory().equals("Tv") || product.getCategory().equals("Laptop"))
            {
                proddao.save(product);
                return getAllProducts();
                } else {
                    throw new ProductException("Invaliid Category");
                    }
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	
	@Override
	public Product getProductById(int id) throws ProductException {
		try {
			Optional<Product> data=proddao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new ProductException("Product with Id "+id+"does not exist");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	@Override
	public List<Product> deleteProduct(int id) throws ProductException {
		if (proddao.existsById(id)) {
			proddao.deleteById(id);
			return getAllProducts();
		} else {
			throw new ProductException("cannot Delete. Employee with Id "+id+" does not exist");
		}
	}
	
	
	@Override
	public List<Product> updateProduct(int id, Product product) throws ProductException {
		if (proddao.existsById(id)) {
		Product prod=	proddao.findById(id).get();
		prod.setPrice(product.getPrice());
		prod.setQuantity(product.getQuantity());
			proddao.save(prod);
			return getAllProducts();
		} else {
			throw new ProductException("Invalid Product,cannot be updated");
		}
}
}

package com.cg.prod.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.prod.dto.Product;
import com.cg.prod.exception.ProductException;
import com.cg.prod.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	private ProductService prodservice;
	@GetMapping("/products")
	public List<Product>getAllProducts() throws ProductException{
		return prodservice.getAllProducts();
	}
	
	//@RequestMapping(value = "/products",method = RequestMethod.POST)
	@PostMapping("/products")
		public List<Product>addProduct(@RequestBody Product product) throws ProductException{
			return prodservice.addProduct(product);
}
	@GetMapping("/products/{id}")
	public Product getProductById(@PathVariable int id) throws ProductException{
		return prodservice.getProductById(id);	
	}
	
	//@RequestMapping(value = "/products/{id}",method = RequestMethod.DELETE)
	@DeleteMapping("/products/{id}")
	public List<Product> deleteProduct(@PathVariable int id) throws ProductException{
		return prodservice.deleteProduct(id);
	}
	
	//@RequestMapping(value = "/products/{id}",method = RequestMethod.PUT)
		@PutMapping("/products/{id}")
	public List<Product> updateProduct(@RequestBody Product product,@PathVariable int id)throws ProductException{
		return prodservice.updateProduct(id, product);
	}
		@ExceptionHandler(Exception.class)
		public ResponseEntity<String> handleErrors(Exception ex){
			return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
		}
}
package com.cg.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entities.CustomerDetails;

public interface ICustomerDetails extends JpaRepository<CustomerDetails, Long> {

	@Query("select caccount,cname from CustomerDetails where caccount =?1")
	Optional<CustomerDetails> accountsDetails(@Param("c") Long accNo);

	@Query("select be.cbalance from CustomerDetails be where be.caccount =?1")
	Optional<Double> showBalance(@Param("c") Long accNo);
}






package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Table(name = "custmerdetails")
@Entity
public class CustomerDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "a")
	@SequenceGenerator(name = "a", sequenceName = "banksq2")
	private Long caccount;
	private String cname;
	private Double cbalance;
	private String cpassword;
	private Long cmobile;
	public Long getCaccount() {
		return caccount;
	}
	public void setCaccount(Long caccount) {
		this.caccount = caccount;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public Double getCbalance() {
		return cbalance;
	}
	public void setCbalance(Double cbalance) {
		this.cbalance = cbalance;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	public Long getCmobile() {
		return cmobile;
	}
	public void setCmobile(Long cmobile) {
		this.cmobile = cmobile;
	}
	public CustomerDetails(Long caccount, String cname, Double cbalance, String cpassword, Long cmobile) {
		super();
		this.caccount = caccount;
		this.cname = cname;
		this.cbalance = cbalance;
		this.cpassword = cpassword;
		this.cmobile = cmobile;
	}
	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}

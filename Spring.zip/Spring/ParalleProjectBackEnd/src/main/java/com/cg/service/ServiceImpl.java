package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICustomerDetails;
import com.cg.dao.ITransactionDetails;
import com.cg.entities.CustomerDetails;
import com.cg.entities.TransactionDetails;
import com.cg.exception.AccountNotFoundException;

@Service
public class ServiceImpl implements IService {

	@Autowired
	ICustomerDetails customerDao;

	@Autowired
	ITransactionDetails transactionDao;

	@Override
	public CustomerDetails createAccount(CustomerDetails customerDetails) throws AccountNotFoundException {
		if (customerDetails.getCbalance() == null || customerDetails.getCbalance() <= 0) {
			throw new AccountNotFoundException("Atleast initial balance should be more than zero");
		} else {
			customerDao.save(customerDetails);
			return customerDao.findById(customerDetails.getCaccount()).get();
		}
	}

	@Override
	public CustomerDetails accountsDetails(Long accNo) throws AccountNotFoundException {
		if (!customerDao.findById(accNo).isPresent()) {
			throw new AccountNotFoundException("Invalid account number!!!");
		} else {
			return customerDao.findById(accNo).get();
		}
	}

	@Override
	public Double showBalance(Long accNo) throws AccountNotFoundException {
		if (!customerDao.findById(accNo).isPresent()) {
			throw new AccountNotFoundException("Invalid account number!!!");
		} else {
			return customerDao.findById(accNo).get().getCbalance();
		}

	}

	@Override
	public Double deposit(Long accNo, Double amt) throws AccountNotFoundException {

		Optional<CustomerDetails> bank = customerDao.findById(accNo);
		if (bank.isPresent()) {
			CustomerDetails tempEntity = bank.get();
			tempEntity.setCbalance(bank.get().getCbalance() + amt);
			customerDao.save(tempEntity);
			TransactionDetails trans = new TransactionDetails();
			trans.setTamount(amt);
			trans.setTtype("Deposit");
			trans.setTaccount_sender(accNo);
			transactionDao.save(trans);
			return showBalance(accNo);
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double withdraw(Long accNo, Double amt) throws AccountNotFoundException {
		Optional<CustomerDetails> bank = customerDao.findById(accNo);
		if (bank.isPresent()) {
			if (amt > showBalance(accNo)) {
				throw new AccountNotFoundException("Low balance");
			} else {
				CustomerDetails tempEntity = bank.get();
				tempEntity.setCbalance(bank.get().getCbalance() - amt);
				customerDao.save(tempEntity);
				TransactionDetails trans = new TransactionDetails();
				trans.setTamount(amt);
				trans.setTtype("Withdraw");
				trans.setTaccount_sender(accNo);
				transactionDao.save(trans);
				return showBalance(accNo);
			}
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double fundTransfer(Long accNo, Double amt, Long accNo1) throws AccountNotFoundException {
		Optional<CustomerDetails> senderAccount = customerDao.findById(accNo);
		Optional<CustomerDetails> reciverAccount = customerDao.findById(accNo1);
		if (senderAccount.isPresent() && reciverAccount.isPresent()) {

			CustomerDetails sender = senderAccount.get();
			sender.setCbalance(senderAccount.get().getCbalance() - amt);
			customerDao.save(sender);

			CustomerDetails reciver = reciverAccount.get();
			reciver.setCbalance(reciverAccount.get().getCbalance() + amt);
			customerDao.save(reciver);

			TransactionDetails senderTrans = new TransactionDetails();
			senderTrans.setTaccount_sender(accNo);
			senderTrans.setTamount(amt);
			senderTrans.setTaccount_reciver(accNo1);
			senderTrans.setTtype("Fund Transfer");
			transactionDao.save(senderTrans);
			
			TransactionDetails reciverTrans = new TransactionDetails();
			reciverTrans.setTaccount_sender(accNo1);
			reciverTrans.setTamount(amt);
			reciverTrans.setTaccount_reciver(accNo);
			reciverTrans.setTtype("Fund Transfer");
			transactionDao.save(reciverTrans);

			return showBalance(accNo);
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public List<TransactionDetails> printTransaction(Long accNo) {
		return transactionDao.printTransaction(accNo);
	}

	@Override
	public List<CustomerDetails> showAllAccounts() {
		return customerDao.findAll();
	}
}

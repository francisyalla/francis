package com.cg.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.ProductRepository;
import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;

/**
 * 
 * @author ryalla
 *Date of creation 23-09-2019
 *class product service implementation
 */
@Service
public class ProductServiceImpl implements ProductService{
	/*
	 * Autowiring with repository
	 */
	
	@Autowired
	private ProductRepository proddao;
	
	/**
	 * Author:ryalla
	 * Date:23-09-2019
	 * Method name:view products
	 * return value : List of products
	 */
	
	/*
	 * To view all the products
	 */
	
	@Override
	public List<Product> viewProducts() throws ProductException {
		try {
			return proddao.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	
	/*
	 * To add the object into Database
	 */
	@Override
	public List<Product> createProduct(Product product) throws ProductException {
	try {
		proddao.save(product);
		return viewProducts();
	} catch (Exception e) {
		throw new ProductException(e.getMessage());

	}
	}
	/*
	 * To delete product based on ID
	 */
	@Override
	public List<Product> deleteProduct(String id) throws ProductException {
		if (proddao.existsById(id)) {
			proddao.deleteById(id);
			return viewProducts();
		} else {
			throw new ProductException("cannot Delete. product with Id "+id+" does not exist");
		}
	}
	/*
	 * To update the name or price or model
	 */
	@Override
	public List<Product> updateProduct(String id, Product product) throws ProductException {
		try {
			if (proddao.existsById(product.getId())) {
				Product updateProduct=product;
				updateProduct.setId(id);
				proddao.save(updateProduct);
				return viewProducts();
			} else {
				throw new ProductException("Invalid Product,cannot be updated");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}
	/*
	 * To find product based on ID
	 */
	@Override
	public Product FindProductById(String id) throws ProductException {
		try {
			Optional<Product> data=proddao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new ProductException("Product with Id "+id+"does not exist");
			}
		} catch (Exception e) {
			throw new ProductException(e.getMessage());
		}
	}

	


	

}

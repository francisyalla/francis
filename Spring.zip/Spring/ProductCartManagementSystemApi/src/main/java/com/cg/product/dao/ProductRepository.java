package com.cg.product.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.Product;

/*
 * Extending JpaRepository to perform basic CRUD Operations
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, String>{

}

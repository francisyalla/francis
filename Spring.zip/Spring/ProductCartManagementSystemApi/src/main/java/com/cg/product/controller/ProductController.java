package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;
import com.cg.product.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private ProductService prodService;
	
	/*
	 * To handle viewAll request
	 */
	
	@GetMapping("/products")
	public List<Product>viewProducts() throws ProductException{
		return prodService.viewProducts();
	}
	
	/*
	 * To handle create request
	 */
	
	//@RequestMapping(value = "/products",method = RequestMethod.POST)
	@PostMapping("/products")
	public List<Product>createProduct(@RequestBody Product product) throws ProductException{
		return prodService.createProduct(product);
}
	
	/*
	 * To handle delete request
	 */
	
	//@RequestMapping(value = "/products/{id}",method = RequestMethod.DELETE)
		@DeleteMapping("/products/{id}")
		public List<Product> deleteProduct(@PathVariable String id) throws ProductException{
			return prodService.deleteProduct(id);
		}
		
		/*
		 * To handle update request
		 */
		
	//@RequestMapping(value = "/products/{id}",method = RequestMethod.PUT)
		@PutMapping("/products/{id}")
		public List<Product> updateProduct(@RequestBody Product product,@PathVariable String id)throws ProductException{
			return prodService.updateProduct(id, product);
			
		}
		
		/*
		 * To handle search request
		 */
		
		@GetMapping("/products/{id}")
		public Product findProductById(@PathVariable String id) throws ProductException{
			return prodService.FindProductById(id);	
		}
}

package com.cg.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartManagementSystemApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementSystemApiApplication.class, args);
	}

}

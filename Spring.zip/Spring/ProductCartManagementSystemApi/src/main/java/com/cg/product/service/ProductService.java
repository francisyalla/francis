package com.cg.product.service;

import java.util.List;

import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;

public interface ProductService {

	List<Product> viewProducts() throws ProductException;
	List<Product> createProduct(Product product)throws ProductException;
	List<Product> deleteProduct(String id) throws ProductException;
	List<Product> updateProduct(String id,Product product) throws ProductException;
	Product FindProductById(String id) throws ProductException;

}

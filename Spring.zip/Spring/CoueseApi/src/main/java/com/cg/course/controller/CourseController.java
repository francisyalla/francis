package com.cg.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;
import com.cg.course.service.CourseService;


@RestController
@RequestMapping("/api")
public class CourseController {

	@Autowired
	private CourseService courseService;
	
	@GetMapping("/courses")
	public List<Course>getAllCourseDetails() throws CourseException{
		return courseService.getAllCourseDetails();
	}
	//@RequestMapping(value = "/courses",method = RequestMethod.POST)
		@PostMapping("/courses")
		public List<Course>addCourse(@RequestBody Course course) throws CourseException{
			return courseService.addCourse(course);
		}

		@GetMapping("/courses/{courseId}")
		public Course getCourseById(@PathVariable String courseId) throws CourseException{
			return courseService.getCourseById(courseId);	
		}
		
		//@RequestMapping(value = "/courses/{courseId}",method = RequestMethod.DELETE)
		@DeleteMapping("/courses/{courseId}")
		public List<Course> deleteCourse(@PathVariable String courseId) throws CourseException{
			return courseService.deleteCourse(courseId);
		}
		//@RequestMapping(value = "/courses/{courseId}",method = RequestMethod.PUT)
		@PutMapping("/courses/{courseId}")
		public List<Course> updateCourse(@RequestBody Course course,@PathVariable String courseId)throws CourseException{
			return courseService.updateCourse(courseId,course);
		}
		@GetMapping("/courses/mode")
		public List<Course> getCourseByMod(@RequestParam String modName)throws CourseException{
			 return courseService.getCourseByMod(modName);
		
}
		@ExceptionHandler(Exception.class)
		public ResponseEntity<String> handleErrors(Exception ex){
			return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
		}
}

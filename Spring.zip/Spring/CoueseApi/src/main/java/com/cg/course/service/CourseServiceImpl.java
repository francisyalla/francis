package com.cg.course.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.dao.CourseRepository;
import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;

@Service
public class CourseServiceImpl implements CourseService{
@Autowired
	private CourseRepository coursedao;
	
	@Override
	public List<Course> getAllCourseDetails() throws CourseException {
		try {
			return coursedao.findAll();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
	}}

	@Override
	public List<Course> addCourse(Course course) throws CourseException {
		try {
			if(course.getDuration()<3) {
				throw new CourseException("Duration cannot be lessthan 3");
			}
			if(course.getMode().equals("Classroom")||course.getMode().equals("Online")) {
				coursedao.save(course);
				return getAllCourseDetails();
			}else {
				throw new CourseException("Mode should be either Classroom or Online");
			}
			
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public Course getCourseById(String courseId) throws CourseException {
		try {
			Optional<Course> data=coursedao.findById(courseId);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new CourseException("Course with Id "+courseId+"does not exist");
			}
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> deleteCourse(String courseId) throws CourseException {
		if (coursedao.existsById(courseId)) {
			coursedao.deleteById(courseId);
			return getAllCourseDetails();
		} else {
			throw new CourseException("cannot Delete. Course with courseId "+courseId+" does not exist");
		}
	}

	@Override
	public List<Course> updateCourse(String courseId, Course course) throws CourseException {
		if (coursedao.existsById(courseId)) {
			coursedao.save(course);
			return getAllCourseDetails();
		} else {
			throw new CourseException("Invalid Course,cannot be updated");
		}
	}

	@Override
	public List<Course> getCourseByMod(String modName) throws CourseException {
		// TODO Auto-generated method stub
		return coursedao.getCourseByMod(modName);
	}

	
}

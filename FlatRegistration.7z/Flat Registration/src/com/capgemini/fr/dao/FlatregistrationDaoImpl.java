package com.capgemini.fr.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.fr.bean.FlatRegistration;
import com.capgemini.fr.exception.FRException;


public class FlatregistrationDaoImpl implements IFlatRegitrationDao{
	
	static Map<Integer, FlatRegistration> map1=new HashMap<>();

	@Override
	public int addRegisteredFlat(FlatRegistration registeredFlat) {
		int generatedId=0;
		double randomNum=0;
		randomNum=Math.random()*1000;
		
		generatedId=(int) randomNum;
		map1.put(generatedId, registeredFlat);
		
		return generatedId;
	}

	@Override
	public Map<Integer, FlatRegistration> displayAllFlats() throws FRException {
		
		return map1;
	}
	
	

	
		


	
	
	
}

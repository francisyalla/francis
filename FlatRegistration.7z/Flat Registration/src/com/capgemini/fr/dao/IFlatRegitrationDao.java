package com.capgemini.fr.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.fr.bean.FlatRegistration;
import com.capgemini.fr.exception.FRException;

public interface IFlatRegitrationDao {
	
	Map<Integer, FlatRegistration> map=new HashMap<>();
	
	int addRegisteredFlat(FlatRegistration registeredFlat) throws FRException;

	Map<Integer, FlatRegistration> displayAllFlats()throws FRException;
}

package com.capgemini.fr.bean;

public class FlatOwner {

	private int ownerId;
	private String ownerName;
	private long ownerNumber;
	public FlatOwner() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FlatOwner(int ownerId, String ownerName, long ownerNumber) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.ownerNumber = ownerNumber;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public long getOwnerNumber() {
		return ownerNumber;
	}
	public void setOwnerNumber(long ownerNumber) {
		this.ownerNumber = ownerNumber;
	}
	@Override
	public String toString() {
		return "FlatOwner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownerNumber=" + ownerNumber + "]";
	}
	
	
}

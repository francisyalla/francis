package com.capgemini.fr.bean;

public class FlatRegistration {
	
	private int flatId;
	private int flatType;
	private double flatArea;
	private double rentAmount;
	private double depositAmount;
	public FlatRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FlatRegistration(int flatId, int flatType, double flatArea, double rentAmount, double depositAmount) {
		super();
		this.flatId = flatId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}
	public int getFlatId() {
		return flatId;
	}
	public void setFlatId(int flatId) {
		this.flatId = flatId;
	}
	public int getFlatType() {
		return flatType;
	}
	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}
	public double getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(double flatArea) {
		this.flatArea = flatArea;
	}
	public double getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}
	public double getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(double depositAmount) {
		this.depositAmount = depositAmount;
	}
	@Override
	public String toString() {
		return "FlatRegistration [flatId=" + flatId + ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", depositAmount=" + depositAmount + "]";
	}
	
	

}

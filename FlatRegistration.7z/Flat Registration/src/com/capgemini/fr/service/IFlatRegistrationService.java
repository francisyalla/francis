package com.capgemini.fr.service;

import java.util.Map;

import com.capgemini.fr.bean.FlatRegistration;
import com.capgemini.fr.exception.FRException;

public interface IFlatRegistrationService {

	boolean isDepositValid(double flatDepositAmount, double flatAmount) throws FRException;

	boolean isRentValid(double flatAmount)throws FRException;

	boolean isAreaValid(double flatArea)throws FRException;

	boolean isTypeValid(int flatType)throws FRException;

	boolean isIdValid(int ownerId)throws FRException;

	int addRegisteredFlat(FlatRegistration registeredFlat)throws FRException;

	Map<Integer, FlatRegistration> displayAllFlats() throws FRException;

	

	
	



}

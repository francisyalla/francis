package com.capgemini.fr.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.fr.bean.FlatOwner;

public class FlatOwnerDB {

	static Map<Integer, FlatOwner> owners=new HashMap<>();
	
	static {
	owners.put(1,new FlatOwner(1,"Swetha", 9099090909L));
	owners.put(2,new FlatOwner(2,"Aarthi", 9199090909L));
	owners.put(3,new FlatOwner(3,"Haritha", 9399090909L));
	}

	public static Map<Integer, FlatOwner> getOwners() {
		return owners;
	}

	public static void setOwners(Map<Integer, FlatOwner> owners) {
		FlatOwnerDB.owners = owners;
	}
	
	
}

package com.capgemini.fr.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.fr.bean.FlatOwner;
import com.capgemini.fr.bean.FlatRegistration;
import com.capgemini.fr.exception.FRException;
import com.capgemini.fr.service.FlatRegistrationServiceImpl;
import com.capgemini.fr.service.IFlatRegistrationService;
import com.capgemini.fr.utility.FlatOwnerDB;
/**
 * 
 * @author maryadav
 *this is the main class used to take the user input
 */

public class Client {
	

	public static void main(String[] args) {

		System.out.println("Welcome to Flat Registration Application");

		IFlatRegistrationService service = new FlatRegistrationServiceImpl();

		Scanner scanner = null;
		int choice = 0;
		int ownerId = 0;
		int flatType = 0;
		double flatArea = 0;
		double flatAmount = 0;
		int generatedId1=0;
		double flatDepositAmount = 0;
		boolean choiceFlag = false;
		boolean ownerIdFlag = false;
		boolean flatTypeFlag = false;
		boolean flatAreaFlag = false;
		boolean flatAmountFlag = false;
		boolean flatDepositFlag = false;
		/**
		 * Services provided to the user
		 */
		do {
			System.out.println("1. Register Flat");
			System.out.println("2. Display Flat Registration Details");
			System.out.println("3. Exit");

			scanner = new Scanner(System.in);
			choice = scanner.nextInt();

			switch (choice) {
			/**
			 * Registers the flat details
			 */
			case 1: {
				System.out.print("Existing owner Ids are:");
				System.out.print("[");
				Map<Integer, FlatOwner> fowner = FlatOwnerDB.getOwners();
				Iterator<Integer> iterator = fowner.keySet().iterator();
				while (iterator.hasNext()) {
					System.out.print(iterator.next() + ", ");

				}
				System.out.println("]");
				System.out.println();

				do {
					System.out.println("Select the owner Id from above");
					scanner = new Scanner(System.in);
					
					try {
						ownerId = scanner.nextInt();
						service.isIdValid(ownerId);
						ownerIdFlag=true;
					} catch (FRException e) {
						ownerIdFlag=false;
						System.err.println(e.getMessage());
					}
					
				} while (!ownerIdFlag);

				do {
					System.out.println("Select Flat Type (1-1BHK, 2-2BHK)");
					scanner = new Scanner(System.in);
					try {
						flatType = scanner.nextInt();
						service.isTypeValid(flatType);
						flatTypeFlag = true;
					} catch (FRException e) {
						flatTypeFlag = false;
						System.err.println(e.getMessage());
					} catch (InputMismatchException e) {
						System.err.println("Please enter only digits");
					}
				} while (!flatTypeFlag);

				do {
					System.out.println("Enter Flat Area");
					scanner = new Scanner(System.in);
					
					try {
						flatArea = scanner.nextDouble();
						service.isAreaValid(flatArea);
						flatAreaFlag = true;
					} catch (FRException e) {
						flatAreaFlag = false;
						System.err.println(e.getMessage());
					} catch (InputMismatchException e) {
						System.err.println("Please enter only digits");
					}
					
				} while (!flatAreaFlag);

				do {
					System.out.println("Enter desired Rent Amount");
					scanner = new Scanner(System.in);
					try {
						flatAmount = scanner.nextDouble();
						service.isRentValid(flatAmount);
						flatAmountFlag = true;
					} catch (FRException e) {
						flatAmountFlag = false;
						System.err.println(e.getMessage());
					} catch (InputMismatchException e) {
						System.err.println("Please enter only digits");
					}
				} while (!flatAmountFlag);

				do {
					System.out.println("Enter desired deposit Amount");
					scanner = new Scanner(System.in);

					try {
						flatDepositAmount = scanner.nextDouble();
						service.isDepositValid(flatDepositAmount, flatAmount);
						flatDepositFlag = true;
					} catch (FRException e) {
						flatDepositFlag = false;
						System.err.println(e.getMessage());
					} catch (InputMismatchException e) {
						System.err.println("Please enter only digits");
					}

				} while (!flatDepositFlag);
			}

			FlatRegistration registeredFlat=new FlatRegistration(ownerId, flatType, flatArea, flatAmount, flatDepositAmount);
				try {
					generatedId1=service.addRegisteredFlat(registeredFlat);
					System.out.println("Flat Registered Successfully with Id: " + generatedId1);
				} catch (FRException e) {
					System.out.println(e.getMessage());
				}
					
				break;
			case 2:{
					Map<Integer, FlatRegistration> list=new HashMap<>();
					try {
						list = service.displayAllFlats();
						Iterator<FlatRegistration> iterator = list.values().iterator();
						while (iterator.hasNext()) {
							System.out.println(iterator.next());
							} 
					}catch (FRException e) {
					System.err.println(e.getMessage());
						
					}	
					}

				break;
			case 3: {
				System.out.println("Thanks for your visit");
				System.exit(0);
			}

				break;
			default:
				System.err.println("Please enter only 1,2 or 3");
				break;
			}
			
		} while (!choiceFlag);

	}

}

package com.capgemini.fr.exception;

public class FRException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FRException(String message) {
		super(message);
	
	}
	
	

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './component/add/add.component';
import { ShowComponent } from './component/show/show.component';
import { SearchComponent } from './component/search/search.component';
import { ShowsearcheddataComponent } from './component/showsearcheddata/showsearcheddata.component';



const routes: Routes = [
  
  
  {path:'add',component:AddComponent},
  {path:'show',component:ShowComponent},
  {path:'search',component:SearchComponent},
  {path:'showsearcheddata',component:ShowsearcheddataComponent},
                  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

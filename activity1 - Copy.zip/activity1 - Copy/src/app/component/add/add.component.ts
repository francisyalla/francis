import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product';
import { ProductService } from 'src/app/service/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  productData:Product={"id":0,"name":'',"price":0,"brand":''};
 
  constructor(private productService:ProductService,private router:Router) { }

  ngOnInit() {

  }
add(){
   console.log(this.productData.name);
  this.productService.addProduct(this.productData).subscribe((data)=>{this.router.navigate(['show']);}
   );
   
}}

import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/service/product.service';
import { Product } from 'src/app/product';

@Component({
  selector: 'app-showsearcheddata',
  templateUrl: './showsearcheddata.component.html',
  styleUrls: ['./showsearcheddata.component.css']
})
export class ShowsearcheddataComponent implements OnInit {
  searchedData:Product[];

  constructor(private service:ProductService) { }

  ngOnInit() {
    this.searchedData=this.service.getSearcheddata();
  }

}

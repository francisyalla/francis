import { Component, OnInit } from '@angular/core';

import { ProductService } from 'src/app/service/product.service';
import { Product } from 'src/app/product';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
products:Product[];

  constructor(private productService:ProductService) { }

  ngOnInit() {
    this.productService.getAllProducts().subscribe((data:Product[])=>{this.products=data; 
      console.log("all"+this.products)});
  }
  deleteProduct(product:Product){
    this.productService.deleteProduct(product).subscribe((data)=>{this.products=this.products.filter(c=>c!==product)});
  }
  
}

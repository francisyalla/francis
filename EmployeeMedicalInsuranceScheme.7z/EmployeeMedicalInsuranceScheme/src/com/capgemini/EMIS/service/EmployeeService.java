package com.capgemini.EMIS.service;
import java.util.List;
import com.capgemini.EMIS.bean.Employee;

public interface EmployeeService {
	 int add(Employee employee);
	    Employee getEmployee(int employeeId);
	    List<Employee> getemployees();
}

package com.capgemini.shopping.service;

import java.util.List;

import com.capgemini.shopping.bean.Review;

public interface ReviewService {
	List<Review> getAllReviews() ;
	List<Review> addReview(Review review) ;
	List<Review> deleteReview(int Id) ;
	List<Review> editReview(int Id,Review review);
	Review getReviewById(int Id);
}

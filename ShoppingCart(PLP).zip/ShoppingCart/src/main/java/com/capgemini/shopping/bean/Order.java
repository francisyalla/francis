package com.capgemini.shopping.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name = "orderid",initialValue =1,allocationSize = 1)
@SequenceGenerator(name = "orderno",initialValue = 1,allocationSize = 1)
@Table(name="Books_order")
public class Order {
	@Id
	@GeneratedValue(generator = "orderid",strategy = GenerationType.SEQUENCE)
	private int orderid;
	private String booktitle;
	private String author;
	private int quantity;
	private double price;
	private double subtotal;
	@OneToMany
	private List<OrderedBook> books;
	
	public List<OrderedBook> getBooks() {
		return books;
	}
	public void setBooks(List<OrderedBook> books) {
		this.books = books;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public String getBooktitle() {
		return booktitle;
	}
	public void setBooktitle(String booktitle) {
		this.booktitle = booktitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}
	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", booktitle=" + booktitle + ", author=" + author + ", quantity="
				+ quantity + ", price=" + price + ", subtotal=" + subtotal + ", books=" + books + "]";
	}
	
	
	
}

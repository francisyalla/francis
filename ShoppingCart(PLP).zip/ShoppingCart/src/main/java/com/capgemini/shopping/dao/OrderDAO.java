package com.capgemini.shopping.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.shopping.bean.Order;

@Repository
public interface OrderDAO extends JpaRepository<Order, Integer>{

}

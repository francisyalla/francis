package com.capgemini.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.shopping.bean.Book;
import com.capgemini.shopping.bean.Order;
import com.capgemini.shopping.bean.OrderedBook;
import com.capgemini.shopping.service.OrderService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	@PostMapping
	public void createOrder(@RequestBody Order order) {
		orderService.createOrder(order);
	}
	
	@DeleteMapping("/delete/{orderedBookId}")
	public List<OrderedBook> deleteOrder(@PathVariable int orderedBookId) {
		System.out.println(orderedBookId);
		return orderService.deleteOrder(orderedBookId);
	}
	
	 @PostMapping("/createOrderedBook")
	 public void createOrderedBook(@RequestBody OrderedBook orderedBook){
		 System.out.println(orderedBook);
		 orderService.createOrderedBook(orderedBook);
	 }
	 
	 @GetMapping("/getAllOrderedBooks")
	 public List<OrderedBook> getAllOrderedBooks(){
		 System.out.println("hi");
		 return orderService.getAllOrderedBooks();
	 }
	 
	 @GetMapping("/getOrderById/{orderedBookId}")
	 public OrderedBook getOrderedBookById(@PathVariable int orderedBookId) {
		 return orderService.getOrderedBookByID(orderedBookId);
	 }
	 
	 @PostMapping("/placeOrder")
	 public void placeOrder(@RequestBody Order order) {
		 orderService.placeOrder(order);
	 }
}

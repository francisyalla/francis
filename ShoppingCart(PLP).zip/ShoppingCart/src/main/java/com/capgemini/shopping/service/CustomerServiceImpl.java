package com.capgemini.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.shopping.bean.Customer;
import com.capgemini.shopping.dao.CustomerDAO;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerDAO customerDao;
	@Override
	public void createCustomer(Customer customer) {
		long millis=System.currentTimeMillis();
        java.sql.Date date=new java.sql.Date(millis);
        customer.setRegisteredDate(date);
		customerDao.save(customer);
		
	}
	@Override
	public Customer getCustomerByEmail(String emailAddress) {
		return customerDao.getCustomerByEmail(emailAddress);
	}
	@Override
	public Customer getCustomerById(int id) {
		System.out.println(customerDao.findById(id).get());
		return customerDao.findById(id).get();
	}
	@Override
	public List<Customer> getAllCustomers() {
		return customerDao.findAll();
	}
	@Override
	public List<Customer> deleteCustomer(int id) {
		customerDao.deleteById(id);
		return getAllCustomers();
	}

}

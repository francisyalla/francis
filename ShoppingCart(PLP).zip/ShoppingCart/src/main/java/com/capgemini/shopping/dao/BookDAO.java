package com.capgemini.shopping.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.shopping.bean.Book;

@Repository
public interface BookDAO extends JpaRepository<Book,Integer> {
	@Query("from Book where category_categoryId=:categoryId")
	public List<Book> getBookByCategoryId(int categoryId);
}

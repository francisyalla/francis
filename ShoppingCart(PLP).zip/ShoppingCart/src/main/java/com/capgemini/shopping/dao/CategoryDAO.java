package com.capgemini.shopping.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capgemini.shopping.bean.Category;

@Repository
public interface CategoryDAO extends JpaRepository<Category, Integer>{
	@Query("from Category where categoryName=:categoryName")
	public Category getCategoryByName(String categoryName);
}

package com.capgemini.shopping.service;

import java.util.List;

import com.capgemini.shopping.bean.Customer;

public interface CustomerService {
	public void createCustomer(Customer customer);
	public Customer getCustomerByEmail(String emailAddress);
	public Customer getCustomerById(int id);
	public List<Customer> getAllCustomers();
	public List<Customer> deleteCustomer(int id);
}

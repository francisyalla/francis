package com.capgemini.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.shopping.bean.Admin;
import com.capgemini.shopping.dao.AdminDAO;

@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminDAO adminDao;
	
	@Override
	public List<Admin> getUsers() {
		return adminDao.findAll();	
	}

	@Override
	public List<Admin> createUser(Admin admin) {
		adminDao.save(admin);
		return getUsers();
	}

	@Override
	public List<Admin> editUser(Admin admin, int id) {
		if(adminDao.existsById(id)) {
			adminDao.save(admin);
		}
		return getUsers();
	}

	@Override
	public Admin getUserById(int id) {
		 return adminDao.findById(id).get();
	}

	@Override
	public List<Admin> deleteUser(int id) {
		if(adminDao.existsById(id)) {
			adminDao.deleteById(id);
		}
		return getUsers();
	}

	@Override
	public Admin getAdminByEmail(String email) {
		System.out.println(adminDao.findByEmail(email));
		return adminDao.findByEmail(email);
	}
}

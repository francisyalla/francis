package com.capgemini.shopping.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.shopping.bean.Book;
import com.capgemini.shopping.bean.Customer;
import com.capgemini.shopping.bean.Order;
import com.capgemini.shopping.bean.OrderedBook;
import com.capgemini.shopping.dao.CustomerDAO;
import com.capgemini.shopping.dao.OrderDAO;
import com.capgemini.shopping.dao.OrderedBookDAO;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	OrderDAO orderDao;
	@Autowired
	CustomerDAO customerDao;
	@Autowired
	OrderedBookDAO orderedBookDao;
	static List<OrderedBook> books=new ArrayList<>();
	@Override
	public void createOrder(Order order) {
		orderDao.save(order);
		
	}
	@Override
	public List<OrderedBook> deleteOrder(int orderedBookId) {
		orderedBookDao.deleteById(orderedBookId);
		return getAllOrderedBooks();
		
	}
	@Override
	public List<OrderedBook> getAllOrderedBooks() {
		return orderedBookDao.findAll();
	}
	@Override
	public void createOrderedBook(OrderedBook orderedBook) {
		orderedBookDao.save(orderedBook);
		System.out.println(orderedBook);
		books.add(orderedBook);
		System.out.println(books);
	}
	@Override
	public OrderedBook getOrderedBookByID(int orderedBookId) {
		Optional<OrderedBook> orderedBook=orderedBookDao.findById(orderedBookId);
		return orderedBook.get();
	}
	@Override
	public void placeOrder(Order order) {
		System.out.println(books);
		order.setBooks(getAllOrderedBooks());
		orderDao.save(order);
		System.out.println(orderDao.findAll());
		
	}
	

}

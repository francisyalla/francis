package com.capgemini.shopping.service;

import java.util.List;

import com.capgemini.shopping.bean.Admin;

public interface AdminService {
	List<Admin> getUsers();
	Admin getUserById(int id);
	List<Admin> createUser(Admin user);
	List<Admin> deleteUser(int id);
	List<Admin> editUser(Admin user,int id);
	Admin getAdminByEmail(String email);
}

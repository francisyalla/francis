package com.capgemini.shopping.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class OrderedBook {
	@Id
	@GeneratedValue(generator = "orderedBookId",strategy = GenerationType.AUTO)
	private int orderedBookId;
	@ManyToOne
	private Book book;
	private int quantity;
	private double subtotal;
	public int getOrderedBookId() {
		return orderedBookId;
	}
	public void setOrderedBookId(int orderedBookId) {
		this.orderedBookId = orderedBookId;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public double getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}
	@Override
	public String toString() {
		return "OrderedBook [orderedBookId=" + orderedBookId + ", book=" + book + ", quantity=" + quantity + "]";
	}
	
}

package com.capgemini.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.shopping.bean.Category;
import com.capgemini.shopping.service.CategoryService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CategoryController {
		@Autowired
	   private CategoryService categoryService;
		
		@GetMapping("/getCategory")
		public List<Category> getAllCategories(){
			return categoryService.getAllCategories();
		}
		@PostMapping("/createCategory")
		public List<Category> addCategory(@RequestBody Category category){
			return categoryService.addCategory(category);
		}
		@DeleteMapping("/deleteCategory/{id}")
		public List<Category> deleteCategory(@PathVariable int id){
			System.out.println(id);
			return categoryService.deleteCategory(id);
		}
		@PutMapping("/updateCategory/{id}")
		public List<Category> updateCategory(@PathVariable int id,@RequestBody Category category){
			return categoryService.updateCategory(id,category);
		}
		@GetMapping("/categoryById/{id}")
		public Category getById(@PathVariable int id)
		{
			return categoryService.getByid(id);
		}
		@GetMapping("/getCategoryByName/{categoryName}")
		public Category getCategoryByName(@PathVariable String categoryName) {
			return categoryService.getCategoryByName(categoryName);
		}
}

package com.capgemini.shopping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.shopping.bean.Review;
import com.capgemini.shopping.dao.ReviewDAO;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private ReviewDAO reviewDao;
	@Override
	public List<Review> getAllReviews(){
		return reviewDao.findAll();
	}

	@Override
	public List<Review> addReview(Review review){
		long millis=System.currentTimeMillis();
        java.sql.Date date=new java.sql.Date(millis);
        review.setReviewOn(date);
        System.out.println(review);
        reviewDao.save(review);
        return getAllReviews();
		
	}

	@Override
	public List<Review> deleteReview(int Id){
		reviewDao.deleteById(Id);
		return getAllReviews();
	}

	@Override
	public List<Review> editReview(int Id, Review review)  {
		
		if(reviewDao.existsById(review.getId())) {
            Review rev=reviewDao.findById(Id).get();
            rev.setHeadline(review.getHeadline());
            rev.setReviewOn(review.getReviewOn());
            reviewDao.save(rev);
           
        }
		 return getAllReviews();
	}
	@Override
    public Review getReviewById(int Id){
        
      
            Optional<Review> data=reviewDao.findById(Id);
                return data.get();
      
       
	}

}

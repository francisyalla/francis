package com.capgemini.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.shopping.bean.Customer;
import com.capgemini.shopping.service.CustomerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	@PostMapping(value = "/createCustomer")
	public void createCustomer(@RequestBody Customer customer) {
		System.out.println(customer);
		customerService.createCustomer(customer);
	}
	
	@GetMapping("/getCustomerByEmail/{emailAddress}")
	public Customer getCustomerByEmail(@PathVariable String emailAddress) {
		return customerService.getCustomerByEmail(emailAddress);
	}
	
	@GetMapping("/getCustomerById/{id}")
	public Customer getCustomerById(@PathVariable int id) {
		System.out.println(id);
		return customerService.getCustomerById(id);
	}
	
	@GetMapping("/getAllCustomers")
	public List<Customer> getAllCustomers(){
		return customerService.getAllCustomers();
	}
	
	@DeleteMapping("/deleteCustomer/{id}")
    public List<Customer> deleteCustomer(@PathVariable int id) {
        System.out.println("id = " + id);
        return customerService.deleteCustomer(id);
    }
}

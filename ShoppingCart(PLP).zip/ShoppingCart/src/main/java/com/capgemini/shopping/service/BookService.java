package com.capgemini.shopping.service;

import java.util.List;

import com.capgemini.shopping.bean.Book;
import org.springframework.http.ResponseEntity;
public interface BookService {
	List<Book> getBooks();
	Book getBookById(int id);
	List<Book> createBook(Book book) ;
	List<Book> deleteBook(int bookId);
	List<Book> editBook(Book book,int id);
	List<Book> getBookByCategoryId(int categoryId);
}

package com.capgemini.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.shopping.bean.Book;
import com.capgemini.shopping.service.BookService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BookController {
	@Autowired
	private BookService bookService;
	@GetMapping("/getAllBooks")
	public List<Book> getBooks(){
		// TODO Auto-generated method stub
		return bookService.getBooks();
	}
	
	@PostMapping("/createBook")
	public List<Book> createBook(@RequestBody Book book){
		System.out.println(book);
		return bookService.createBook(book);
	}
	
	@PutMapping("/editBook/{id}")
	public List<Book> editBook(@RequestBody Book book,@PathVariable int id){
		System.out.println(id);
		return bookService.editBook(book,id);
	}
	
	@GetMapping("/getBookById/{bookId}")
	public Book getBookById(@PathVariable int bookId) {
		return bookService.getBookById(bookId);
	}
	
	@DeleteMapping("/deleteBook/{bookId}")
	public List<Book> deleteBook(@PathVariable int bookId){
		System.out.println(bookId);
		return bookService.deleteBook(bookId);
		
	}
	
	@GetMapping("/getBookByCategoryId/{categoryId}")
	public List<Book> getBookByCategoryId(@PathVariable int categoryId){
		return bookService.getBookByCategoryId(categoryId);
	}
  
}

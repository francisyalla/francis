package com.capgemini.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.shopping.bean.Review;
import com.capgemini.shopping.service.ReviewService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ReviewController {
	@Autowired
	private ReviewService reviewService;
	
	
	@GetMapping("/reviews")
	public List<Review> getAllReviews(){
		System.out.println(reviewService.getAllReviews());
		return reviewService.getAllReviews();
	}
	
	@PostMapping("/reviews")
	public List<Review> addReview(@RequestBody Review review){
		return reviewService.addReview(review);
	}
	
	@DeleteMapping("/reviews/{Id}")
	public List<Review> deleteReview(@PathVariable int Id){
			return reviewService.deleteReview(Id);
	
	}
	
	@PutMapping("/reviews/{Id}")
	public List<Review> editReview(@RequestBody Review review,@PathVariable int Id){
		return reviewService.editReview(Id,review);
	}
	
	@GetMapping("/reviews/{Id}")
    public Review getReviewById(@PathVariable int Id) {
        return reviewService.getReviewById(Id);
    }
}

package com.capgemini.shopping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.capgemini.shopping.bean.Book;
import com.capgemini.shopping.bean.Category;
import com.capgemini.shopping.dao.BookDAO;
import com.capgemini.shopping.dao.CategoryDAO;

@Service
public class BookServiceImpl implements BookService {
	@Autowired
	private BookDAO bookDao;
	@Autowired 
	private CategoryDAO categoryDao;
	static List<Book> books=new ArrayList<>();
	@Override
	public List<Book> getBooks() {
		return bookDao.findAll();
		
	}

	@Override
	public Book getBookById(int bookId){
			Optional<Book>data=bookDao.findById(bookId);
			return data.get();
	}

	@Override
	public List<Book> createBook(Book book) {
		  long millis=System.currentTimeMillis();
	        java.sql.Date date=new java.sql.Date(millis);
	        book.setPublishDate(date);
		  Category category=book.getCategory();
		  category.setCategoryId(categoryDao.getCategoryByName(category.getCategoryName
		  ()).getCategoryId()); book.setCategory(category); System.out.println(book);
		bookDao.save(book);
        return getBooks();
	}

	@Override
	public List<Book> deleteBook(int bookId)  {
		//List<Book> books=categoryDao.fin
		if(bookDao.existsById(bookId)) {
			bookDao.deleteById(bookId);
			
		}
		return getBooks();
	}

	@Override
	public List<Book> editBook(Book book, int id) {
		if(bookDao.existsById(id)) {
			bookDao.save(book);
			
		}
		return getBooks();
	}

	@Override
	public List<Book> getBookByCategoryId(int categoryId) {
		return bookDao.getBookByCategoryId(categoryId);
	}

}

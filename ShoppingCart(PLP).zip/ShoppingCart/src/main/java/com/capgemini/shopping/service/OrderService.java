package com.capgemini.shopping.service;

import java.util.List;

import com.capgemini.shopping.bean.Book;
import com.capgemini.shopping.bean.Customer;
import com.capgemini.shopping.bean.Order;
import com.capgemini.shopping.bean.OrderedBook;

public interface OrderService {
	public void createOrder(Order order);
	public List<OrderedBook> deleteOrder(int orderedBookId);
	public List<OrderedBook> getAllOrderedBooks();
	public void createOrderedBook(OrderedBook orderedBook); 
	public OrderedBook getOrderedBookByID(int orderedBookId);
	public void placeOrder(Order order);
}

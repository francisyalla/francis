package com.capgemini.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.shopping.bean.Category;
import com.capgemini.shopping.dao.CategoryDAO;

@Service
public class CategoryServiceImpl implements CategoryService {
	@Autowired
    private CategoryDAO categoryDao;
	@Override
	public List<Category> getAllCategories() {
		
		return categoryDao.findAll();
	}

	@Override
	public List<Category> addCategory(Category category) {
		System.out.println(category.getCategoryId());
		Category category1=categoryDao.getCategoryByName(category.getCategoryName());
		if(category1!=null)
			return getAllCategories();
		else {
			categoryDao.save(category);
		return getAllCategories();
		}
	}

	@Override
	public List<Category> updateCategory(int id,Category category) {
		if(categoryDao.existsById(id)) {
			categoryDao.save(category);
		}
		return getAllCategories();
		
	}

	@Override
	public List<Category> deleteCategory(int id) {
		categoryDao.deleteById(id);
		return getAllCategories();
	}

	@Override
	public Category getByid(int id) {
		// TODO Auto-generated method stub
		return categoryDao.findById(id).get();
	}

	@Override
	public Category getCategoryByName(String categoryName) {
		return categoryDao.getCategoryByName(categoryName);
	}

}

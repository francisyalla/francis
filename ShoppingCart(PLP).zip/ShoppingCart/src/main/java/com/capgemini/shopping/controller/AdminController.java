package com.capgemini.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.shopping.bean.Admin;
import com.capgemini.shopping.service.AdminService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AdminController {
	@Autowired
	private AdminService adminService;
	@GetMapping("/getAdmins")
	public List<Admin> getUsers()  {
		return adminService.getUsers();
	}
	
	@PostMapping("/createAdmin")
	public List<Admin> createUser(@RequestBody Admin admin) {
		return adminService.createUser(admin);
	}
	
	@PutMapping("/editAdmin/{id}")
	public List<Admin> editUser(@RequestBody Admin user,@PathVariable int id){
		System.out.println(id);
		return adminService.editUser(user,id);
	}
	
	@GetMapping("/getAdminById/{id}")
	public Admin getUserById(@PathVariable int id){
		return adminService.getUserById(id);
	}
	
	@DeleteMapping("/deleteAdmin/{id}")
	public List<Admin> deleteEmployee(@PathVariable int id){
		return adminService.deleteUser(id);
		
	}
	
	@GetMapping("/getAdminByEmail/{email}")
	public Admin getAdminByEmail(@PathVariable String email) {
		System.out.println("skdjgvksdgvjn");
		System.out.println(email);
		return adminService.getAdminByEmail(email);
	}
	
}

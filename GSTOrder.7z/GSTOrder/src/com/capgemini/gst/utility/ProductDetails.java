package com.capgemini.gst.utility;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.gst.bean.GSTBean;

public class ProductDetails {
	static Map<Integer, GSTBean> productlist=new HashMap<>();
	static {
		productlist.put(111, new GSTBean(111,"Rice",50,200));
		productlist.put(222, new GSTBean(222,"Rice",60,300));
		productlist.put(333, new GSTBean(333,"Rice",70,400));
		productlist.put(444, new GSTBean(444,"Rice",80,500));
	}
	public static Map<Integer, GSTBean> getProductlist() {
		return productlist;
	}
	public static void setProductlist(Map<Integer, GSTBean> productlist) {
		ProductDetails.productlist = productlist;
	}
	
	
	
	}

	


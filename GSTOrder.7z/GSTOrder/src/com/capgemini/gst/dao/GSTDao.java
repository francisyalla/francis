package com.capgemini.gst.dao;

import java.util.Map;

import com.capgemini.gst.bean.GSTBean;

public interface GSTDao {

	int addProduct(GSTBean product);

	double getTranportcharge(int productDistance, int productWeight);

	Map<Integer, GSTBean>  getAllProducts() throws Exception;

	double getGST(double transportCharges);

}

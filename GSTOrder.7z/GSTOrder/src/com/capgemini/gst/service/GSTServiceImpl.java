package com.capgemini.gst.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.gst.bean.GSTBean;
import com.capgemini.gst.dao.GSTDao;
import com.capgemini.gst.dao.GSTDaoImpl;
import com.capgemini.gst.exception.GSTException;;

public class GSTServiceImpl implements GSTService {

	GSTDao dao=new GSTDaoImpl();
	@Override
	public boolean isNameValid(String productName) throws GSTException {
		String regEx="^[A-Z]{1}[a-zA-z]{4,}$";
		boolean nameFlag=false;
		if(!Pattern.matches(regEx, productName)) {
			throw new GSTException("Name should start with capital and followed by 4 characters");
		}	
		else
			nameFlag=true;
		return nameFlag;
		
	}

	@Override
	public boolean isWeightValid(int productWeight) throws GSTException {
		boolean weightFlag=false;
		if(productWeight<1) {
			throw new GSTException("Weight should be greater than 1kg");
		}
		else
			weightFlag=true;
		return weightFlag;
		
	}

	@Override
	public boolean isDistanceValid(int productDistance) throws GSTException {
		boolean distanceFlag=false;
		if(productDistance<=100) {
			throw new GSTException("Distance should be greater than 100Km");
		}
		else
			distanceFlag=true;
		return distanceFlag;
	}

	@Override
	
	public int addProduct(GSTBean product) throws GSTException{

		return dao.addProduct (product);
	}

	@Override
	public double getTransportCharge(int productDistance, int productWeight) {
		return dao.getTranportcharge(productDistance,productWeight);
	}

	@Override
	public double getGST(double transportCharges) {
		return dao.getGST(transportCharges);
	}

	@Override
	public List<GSTBean> getAllProducts() throws Exception {
		List<GSTBean> list  =new  ArrayList<GSTBean>();
		Collection<GSTBean> col =dao.getAllProducts().values();
		list.addAll(col);
		return list;
		
	}

	
	
	}



package com.capgemini.shopping.service;

import java.util.List;

import com.capgemini.shopping.bean.Order;

public interface OrderService {
	public List<Order> getAllOrders();
	public void createOrder(Order order);
}

package com.capgemini.shopping.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name = "orderid",initialValue =1,allocationSize = 1)
@Table(name="Books_order")
public class Order {
	@Id
	@GeneratedValue(generator = "orderid",strategy = GenerationType.SEQUENCE)
	private int id;
	private String booktitle;
	private int quantity;
	private float price;
	private float subtotal;
	public int getOrderId() {
		return id;
	}
	public void setOrderId(int id) {
		this.id = id;
	}
	public String getBookTitle() {
		return booktitle;
	}
	public void setBookTitle(String booktitle) {
		this.booktitle = booktitle;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getSubTotal() {
		return subtotal;
	}
	public void setSubTotal(float subtotal) {
		this.subtotal = subtotal;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + id + ", bookTitle=" + booktitle + ", quantity=" + quantity + ", price=" + price
				+ ", subTotal=" + subtotal + "]";
	}
	
	
}

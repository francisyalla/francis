import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateorderComponent } from './createorder.component';
import { ShoppingcartpageComponent } from './shoppingcartpage.component';
import { CheckoutpageComponent } from './checkoutpage.component';
import { UpdateshoppingcartComponent } from './updateshoppingcart.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { CustomerloginComponent } from './components/customer/customerlogin/customerlogin.component';
import { CustomerregisterComponent } from './components/customer/customerregister/customerregister.component';
import { AddcategoryComponent } from './components/category/addcategory.component';
import { EditcategoryComponent } from './components/category/editcategory.component';
import { CategorylistComponent } from './components/category/categorylist.component';
import { CustomerpageComponent } from './components/customer/customerpage/customerpage.component';
import { AddadminComponent } from './components/admin/addadmin.component';
import { AdminlistComponent } from './components/admin/adminlist.component';
import { EditadminComponent } from './components/admin/editadmin.component';
import { AdminhomepageComponent } from './components/admin/adminhomepage.component';
import { AdminloginComponent } from './components/admin/adminlogin.component';
import { BooklistComponent } from './components/book/booklist/booklist.component';
import { AddbookComponent } from './components/book/addbbok/addbook.component';
import { EditbookComponent } from './components/book/editbook/editbook.component';
import { CustomerlistComponent } from './components/customer/customerlist/customerlist.component';
import { ReviewlistComponent } from './components/review/reviewlist/reviewlist.component';
import { CreatecustomerComponent } from './components/customer/createcustomer.component';
import { EditcustomerComponent } from './components/customer/editcustomer/editcustomer.component';
import { BookdetailComponent } from './components/book/bookdetail/bookdetail.component';
import { EditreviewComponent } from './components/review/editreview/editreview.component';
import { MyordersComponent } from './components/customer/myorders.component';


const routes: Routes = [
  {path:'',component:HomepageComponent},
  {path:"editReview/:id",component:EditreviewComponent},
  {path:"customerpage/homepage",component:HomepageComponent},
  {path:"customerpage/:id/shoppingcart",component:ShoppingcartpageComponent},
  {path:"login",component:CustomerloginComponent},
  {path:"create",component:CreateorderComponent},
  {path:"shoppingcart",component:ShoppingcartpageComponent},
  {path:"shoppingcart/checkout",component:CheckoutpageComponent},
  {path:"shoppingcart/update",component:UpdateshoppingcartComponent},
  {path:"customerlogin",component:CustomerloginComponent},
  {path:"register",component:CustomerregisterComponent},
  {path:"addCategory",component:AddcategoryComponent},
  {path:"category",component:CategorylistComponent},
  {path:"category/update/:id",component:EditcategoryComponent},
  {path:"customerpage/:customerId",component:CustomerpageComponent},
  {path:"shoppingcart/customerpage",component:CustomerpageComponent},
  {path:'adminlist',component : AdminlistComponent},
  {path:'create',component : AddadminComponent},
  {path:'adminlist/edit/:id',component : EditadminComponent},
  {path:'adminhomepage/:id',component:AdminhomepageComponent},
  {path:"adminhomepage/:id/adminlogin",component:AdminloginComponent},
  {path:"adminhomepage/:id/adminlist",component:AdminlistComponent},
  {path:"categorylist",component:CategorylistComponent},
  {path:"booklist",component:BooklistComponent},
  {path:"createbook",component:AddbookComponent},
  {path:"addcategory",component:AddcategoryComponent},
  {path:"category/addcategory",component:AddcategoryComponent},
  {path:"booklist",component:BooklistComponent},
  {path:"booklist/edit/:bookId",component:EditbookComponent},
  {path:"createCustomer",component:CreatecustomerComponent},
  {path:"reviewlist",component:ReviewlistComponent},
  {path:"customerlist",component:CustomerlistComponent},
  {path:"edit/:customerId",component:EditcustomerComponent},
  {path:"bookdetail/:bookId/:customerId",component:BookdetailComponent},
  {path:"bookdetail/:bookId/:customerId/shoppingcart/:bookId/:customerId",component:ShoppingcartpageComponent},
  {path:"bookdetail/:bookId/:customerId/shoppingcart/:bookId/:customerId/customerpage/:customerId",component:CustomerpageComponent},
  {path:"adminlogin",component:AdminloginComponent},
  {path:"adminlist/customerlist",component:CustomerlistComponent},
  {path:"adminlist",component:AdminlistComponent},
  {path:"adminlist/categorylist",component:CategorylistComponent},
  {path:"adminhomepage/:id/adminlist/categorylist",component:CategorylistComponent},
  {path:"adminhomepage/:id/adminlist/booklist",component:BooklistComponent},
  {path:"adminhomepage/:id/adminlist/customerlist",component:CustomerlistComponent},
  {path:"adminhomepage/:id/booklist/edit/:bookId",component:EditbookComponent},
  {path:"adminhomepage/:id/adminlist/reviewlist",component:ReviewlistComponent},
  {path:"adminhomepage/:id/addadmin",component:AddadminComponent},
  {path:"adminhomepage/:id/createcustomer",component:CreatecustomerComponent},
  {path:"adminhomepage/:id/addcategory",component:AddcategoryComponent},
  {path:"adminhomepage/:id/addcustomer",component:CreatecustomerComponent},
  {path:"shoppingcart/:bookId/:customerId",component:ShoppingcartpageComponent},
  {path:"shoppingcart/:bookId/:id/customerpage/:customerId",component:CustomerpageComponent},
  {path:"adminhomepage/:id/categorylist/booklist",component:BooklistComponent},
  {path:"adminhomepage/:id/adminlist/booklist/edit/:bookId",component:EditbookComponent},
  {path:"adminhomepage/:id/adminlist/categorylist/booklist",component:BooklistComponent},
  {path:"addbook",component:AddbookComponent},
  {path:"addadmin",component:AddadminComponent},
  {path:"myorders",component:MyordersComponent},
  {path:"checkout",component:CheckoutpageComponent},
  {path:"booklist/:id",component:BooklistComponent},
  {path:"addbook/:id",component:AddbookComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

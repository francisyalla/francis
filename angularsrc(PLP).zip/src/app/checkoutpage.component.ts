import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import { Order } from './order';
import { Orderedbook } from './bean/orderedbook/orderedbook';

@Component({
  selector: 'app-checkoutpage',
  templateUrl: './checkoutpage.component.html',
  styleUrls: ['./checkoutpage.component.css']
})
export class CheckoutpageComponent implements OnInit {
  orderedBooks:Orderedbook[];
  constructor(private orderService:OrderService) { }

  ngOnInit() {
    console.log(this.orderedBooks);
    this.orderService.getAllOrderedBooks().subscribe(data=>{this.orderedBooks=data});
  }

}

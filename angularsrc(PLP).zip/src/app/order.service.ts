import { Injectable } from '@angular/core';
import { Order } from './order';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';
import { Customer } from './bean/customer/customer';
import { Book } from './bean/book/book';
import { Orderedbook } from './bean/orderedbook/orderedbook';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  orders:Order;
  url:string="http://localhost:9090/";
  constructor(private http:HttpClient) { }
  public getOrders(){
    return this.http.get<Order[]>(this.url);
  }
  public deleteOrders(){
    return this.http.delete(this.url);
  }
  deleteOrder(orderedBook:Orderedbook){
    return this.http.delete<Order[]>(this.url+"/delete/"+orderedBook.orderedBookId);
  }
  createOrder(order:Order){
    //console.log(order);
    return this.http.post(this.url,order);
  }
  register(customer: Customer) {
    //console.log(customer);
    return this.http.post(this.url+"/createCustomer",customer);
}
  isLoggedIn(customer:Customer):Observable<Customer>{
    //console.log(customer);
    return this.http.get<Customer>(this.url+"/getCustomerByEmail/"+customer.emailAddress);
  }
  getAllCustomers(){
    return this.http.get<Customer[]>(this.url+"/getAllCustomers");
    }
    getCustomerById(id:number){
      //console.log(id);
      return this.http.get<Customer>(this.url+"/getCustomerById/"+id);
    }
    deleteCustomer(customer:Customer){
 
      return this.http.delete<Customer[]>(this.url+"/deleteCustomer/"+customer.customerId);
     }
      
    createCustomer(customer:Customer){
      return this.http.post<Customer[]>(this.url+"/createCustomer",customer);
    }
    getOrderById(id:number){
      return this.http.get<Order>(this.url+"/getOrderById/"+id);
    }
    createOrderedBook(orderedBook:Orderedbook){
      console.log(orderedBook);
      return this.http.post(this.url+"/createOrderedBook",orderedBook);
    }
    getAllOrderedBooks(){
      return this.http.get<Orderedbook[]>(this.url+"/getAllOrderedBooks");
    }
}


import { Orderedbook } from './bean/orderedbook/orderedbook';

export class Order {
    orderid:number;
    booktitle:string;
    author:string;
    quantity:number;
    price:number;
    subtotal:number;
    orderedBooks:Orderedbook[];
}

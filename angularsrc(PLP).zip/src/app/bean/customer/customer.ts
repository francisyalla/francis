export class Customer {
    customerId:number;
    emailAddress:string;
    fullName:string;
    password:string;
    phoneNumber:number;
    address:string;
    city:string;
    zipCode:number;
    registeredDate:Date;
    country:string;
}

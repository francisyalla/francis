import { Orderedbook } from './orderedbook';

describe('Orderedbook', () => {
  it('should create an instance', () => {
    expect(new Orderedbook()).toBeTruthy();
  });
});

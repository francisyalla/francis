export class Admin {
    id:number;
    email:string;
    fullname:string;
    password:string;
}

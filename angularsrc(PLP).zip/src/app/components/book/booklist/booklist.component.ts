import { Component, OnInit } from '@angular/core';
import { Book } from '../../../bean/book/book';
import { BookService } from '../../../service/book/book.service';
import { Category } from 'src/app/bean/category/category';
import { Admin } from '../../../bean/admin/admin';
import { AdminService } from '../../../service/admin/admin.service';
import { ActivatedRoute } from '../../../../../node_modules/@angular/router';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  books:Book[];
  categories:Category[];
  admin:Admin={"id":0,"fullname":'',"password":'',"email":''};
  constructor(private bookService:BookService,private adminService:AdminService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.bookService.getAllBooks().subscribe((data:Book[])=>{console.log(data);this.books=data;
    //for(let i=0;i<data.length;i++){
      //this.categories[i]=data[i].category;
   // }
   this.route.params.subscribe((params) => {
    this.adminService.getAdmin(params['bookId'])
    .subscribe((result) => { this.admin = result })})
    });

  
   
  }
  deleteBook(book:Book){
    if(window.confirm("Are you sure you want to delte book with id "+book.bookId))
    this.bookService.deleteBook(book).subscribe((data)=>{this.books=this.books.filter(c=>c!==book)});
  }

}

import { Component, OnInit } from '@angular/core';
import { Book } from '../../../bean/book/book';
import { BookService } from '../../../service/book/book.service';
import { Router, ActivatedRoute } from '../../../../../node_modules/@angular/router';
import { Category } from '../../../bean/category/category';
import { CategoryService } from '../../../service/category/category.service';
import { Review } from '../../../bean/review/review';
import { Admin } from '../../../bean/admin/admin';
import { AdminService } from '../../../service/admin/admin.service';
import { ReviewService } from '../../../service/review/review.service';
import { THIS_EXPR } from '../../../../../node_modules/@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {
  category:Category={"categoryId":0,categoryName:''}
  reviews:Review[];
  review:Review={"index":0,"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''}
  bookData:Book={"bookId":0,"title":'',"author":'',"isbn":0,"category":{"categoryId":0,"categoryName":''},"price":0,"description":'',"publishDate":new Date('yyyy-mmm-dd'),"reviews":this.reviews};
  categories:Array<string>;
  admin:Admin={"id":0,"email":'',"fullname":'',"password":''}
  constructor(private bookService:BookService,private categoryService:CategoryService,private adminService:AdminService,
    private router:Router,private route:ActivatedRoute,private reviewService:ReviewService) { }

  ngOnInit() {
    this.categoryService.getAllCategories().subscribe(data=>{this.categories = this.distinct(data)});
    this.route.params.subscribe((params) => {this.adminService.getAdmin(params['bookId']).subscribe((result) => { this.admin = result })})
  }
create(){
  //  this.categoryService.getCategoryByName(this.bookData.category.categoryName).subscribe(data=>{console.log(data);this.category=data;
  // this.bookData.category=data});
  //this.reviews.push(this.bookData.description);
  this.review.book=this.bookData.title;
  this.review.rating=5;
  this.review.headline=this.bookData.description;
  this.review.customer=this.admin.fullname;
  this.reviewService.addReview(this.review).subscribe(data=>this.)
  this.bookService.createBook(this.bookData).subscribe(data=>{this.router.navigate(['booklist'])});
}
  distinct(data):Array<string>{
    const categories = new Set();
    const result:Array<string>=[];
    data.map(obj => {if(obj && obj.categoryName)categories.add(obj.categoryName)})
    Array.from(categories).map((cat:string)=>result.push(cat));
    return result;
  }

  categoryName(category:Category){
    this.bookData.category = category;
    return this.bookData.category.categoryName;
    }
}

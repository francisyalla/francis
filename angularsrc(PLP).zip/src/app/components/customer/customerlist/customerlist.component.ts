import { Component, OnInit } from '@angular/core';
import { Customer } from '../../../bean/customer/customer';
import { OrderService } from '../../../order.service';
import { Router } from '../../../../../node_modules/@angular/router';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
  customers:Customer[];
  customerData:Customer={"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipCode":0,"registeredDate":null,"city":'',"country":''}
  constructor(private orderService:OrderService,private route:Router) { }
  
  ngOnInit() {
  
  this.orderService.getAllCustomers().subscribe
  ((data:Customer[])=>{this.customers=data;
  console.log("all"+this.customers)});
  }
  deleteCustomer(customer:Customer){
  if (window.confirm(" Are you sure you want to delete the customer with id "+customer.customerId)) { 
  
  this.orderService.deleteCustomer(customer).subscribe((data)=>{this.customers=this.customers.filter(c=>c!==customer)});
  }
  
  
  
  }
  editCustomer(customer:Customer){
  this.orderService.getCustomerById(customer.customerId).subscribe((data)=>{this.customers=this.customers.filter(c=>c!==customer)});
  }
  
}

import { Component, OnInit } from '@angular/core';
import { Customer } from '../../../bean/customer/customer';
import { OrderService } from '../../../order.service';
import { Router } from '../../../../../node_modules/@angular/router';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {
  customerData:Customer;
  Emailaddress:string='';
  password:string='';
  customer:Customer={"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"city":'',"zipCode":0,"registeredDate":null,"country":''};
  constructor(private orderService:OrderService,private router:Router) { }

  ngOnInit() {
  }
  login() {
    this.orderService.isLoggedIn(this.customer).subscribe(data=>{
      //console.log(data.id);
      if(this.customer.password==data.password){
        this.router.navigate(['customerpage',data.customerId]);
      }
      else{
        alert("login denied");
      }
    });
  }
}

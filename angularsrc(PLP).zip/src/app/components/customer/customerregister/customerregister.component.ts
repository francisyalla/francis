import { Component, OnInit } from '@angular/core';
import { Customer } from '../../../bean/customer/customer';
import { OrderService } from '../../../order.service';
import { Router } from '../../../../../node_modules/@angular/router';


@Component({
  selector: 'app-customerregister',
  templateUrl: './customerregister.component.html',
  styleUrls: ['./customerregister.component.css']
})
export class CustomerregisterComponent implements OnInit {
  customerData:Customer={"registeredDate":null,"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"city":'',"zipCode":0,"country":''};
  constructor(private orderService: OrderService,private router:Router) { }

  ngOnInit() {
  }
  Register(){
    console.log(this.customerData);
    this.orderService.register(this.customerData).subscribe(data=>{this.router.navigate(['customerlogin'])});

  }
}

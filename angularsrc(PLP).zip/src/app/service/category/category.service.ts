import { Injectable } from '@angular/core';
import { HttpClient } from '../../../../node_modules/@angular/common/http';
import { Category } from '../../bean/category/category';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  url:string="http://localhost:9090/";
  constructor(private http:HttpClient) { }
  addCategory(category:Category){
    return this.http.post(this.url+"/createCategory",category);
  }
  getAllCategories(){
    return this.http.get<Category[]>(this.url+"/getCategory");
  }
  deleteCategory(category:Category){
    return this.http.delete<Category[]>(this.url+"/deleteCategory/"+category.categoryId);
  }
  updateCategory(category:Category){
    return this.http.put(this.url+"/updateCategory/"+category.categoryId,category);
  }
  getCategory(id:number){
    console.log(id);
    return this.http.get<Category>(this.url+"/categoryById/"+id);
  }
  sortByName(categories:Category[]){
    return categories.sort((a, b) => a['name'] > b['name'] ? 1 : a['name'] === b['name'] ? 0 : -1);
  }
  getCategoryByName(name:string){
    return this.http.get<Category>(this.url+"/getCategoryByName/"+name);
  }
}

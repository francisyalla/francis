import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShoppingcartpageComponent } from './shoppingcartpage.component';
import { OrderService } from './order.service';
import { HttpClientModule } from '@angular/common/http';
import { CreateorderComponent } from './createorder.component';
import { CheckoutpageComponent } from './checkoutpage.component';
import { UpdateshoppingcartComponent } from './updateshoppingcart.component';
import { CustomerloginComponent } from 'src/app/components/customer/customerlogin/customerlogin.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { CustomerregisterComponent } from './components/customer/customerregister/customerregister.component';
import { AddcategoryComponent } from './components/category/addcategory.component';
import { CategoryService } from 'src/app/service/category/category.service';
import { CategorylistComponent } from './components/category/categorylist.component';
import { EditcategoryComponent } from './components/category/editcategory.component';
import { CustomerpageComponent } from './components/customer/customerpage/customerpage.component';
import { AddadminComponent } from './components/admin/addadmin.component';
import { AdminhomepageComponent } from './components/admin/adminhomepage.component';
import { AdminService } from 'src/app/service/admin/admin.service';
import { EditadminComponent } from './components/admin/editadmin.component';
import { AdminlistComponent } from './components/admin/adminlist.component';
import { AdminloginComponent } from './components/admin/adminlogin.component';
import { MyordersComponent } from './components/customer/myorders.component';
import { ReviewlistComponent } from './components/review/reviewlist/reviewlist.component';
import { DeletereviewComponent } from './components/review/deletereview/deletereview.component';
import { EditreviewComponent } from './components/review/editreview/editreview.component';
import { AddbookComponent } from './components/book/addbbok/addbook.component';
import { BooklistComponent } from './components/book/booklist/booklist.component';
import { EditbookComponent } from './components/book/editbook/editbook.component';
import { HeaderComponent } from './components/header/header.component';
import { CustomerlistComponent } from './components/customer/customerlist/customerlist.component';
import { CreatecustomerComponent } from './components/customer/createcustomer.component';
import { EditcustomerComponent } from './components/customer/editcustomer/editcustomer.component';
import { BookdetailComponent } from './components/book/bookdetail/bookdetail.component';
import { AddtocartComponent } from './addtocart.component';
@NgModule({
  declarations: [
    AppComponent,
    ShoppingcartpageComponent,
    CreateorderComponent,
    CheckoutpageComponent,
    UpdateshoppingcartComponent,
    CustomerloginComponent,
    HomepageComponent,
    CustomerregisterComponent,
    AddcategoryComponent,
    CategorylistComponent,
    EditcategoryComponent,
    CustomerpageComponent,
    AddadminComponent,
    AdminhomepageComponent,
    EditadminComponent,
    AdminlistComponent,
    AdminloginComponent,
    MyordersComponent,
    ReviewlistComponent,
    DeletereviewComponent,
    EditreviewComponent,
    AddbookComponent,
    BooklistComponent,
    EditbookComponent,
    HeaderComponent,
    CustomerlistComponent,
    CreatecustomerComponent,
    EditcustomerComponent,
    BookdetailComponent,
    AddtocartComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [OrderService,CategoryService,AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }

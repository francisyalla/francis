import { Component, OnInit } from '@angular/core';
import { Order } from './order';
import { OrderService } from './order.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Book } from './bean/book/book';
import { Review } from './bean/review/review';
import { BookService } from './service/book/book.service';
import { Customer } from './bean/customer/customer';
import { Orderedbook } from './bean/orderedbook/orderedbook';

@Component({
  selector: 'app-shoppingcartpage',
  templateUrl: './shoppingcartpage.component.html',
  styleUrls: ['./shoppingcartpage.component.css']
})
export class ShoppingcartpageComponent implements OnInit {
  
  //={"no":0,"boottitle":'',"quantity":0,"price":0,"subtotal":0};
  // reviews:Review[];
   customer:Customer={"registeredDate":null,"customerId":0,"emailAddress":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"city":'',"zipCode":0,"country":''};
  // books:Book[];
  // book:Book={"bookId":0,"title":'',"author":'',"isbn":0,"category":{"categoryId":0,"categoryName":''},"price":0,"description":'',"publishDate":new Date('yyyy-mmm-dd'),"reviews":this.reviews};
  // orderedBook:Orderedbook[];
  // orders:Order={"orderid":0,"booktitle":'',"author":'',"quantity":0,"price":0,"subtotal":0,"orderedBooks":this.orderedBook};
  reviews:Review[];
  book:Book={"bookId":0,"title":'',"author":'',"isbn":0,"category":{"categoryId":0,"categoryName":''},"price":0,"description":'',"publishDate":new Date('yyyy-mmm-dd'),"reviews":this.reviews};
  orderedBook:Orderedbook={"orderedBookId":0,"book":this.book,"quantity":0,"subtotal":0};
  orderedBooks:Orderedbook[];
  constructor(private router:Router,private orderService:OrderService,private route:ActivatedRoute,private bookService:BookService) { }

  ngOnInit() {
    let i=1;
    this.route.params.subscribe((params)=>{this.bookService.getBook(params['bookId']).subscribe((result)=>{this.book=result;this.orderedBook.subtotal=result.price*1})});
    this.orderService.getAllOrderedBooks().subscribe(data=>{console.log(data);this.orderedBooks=data});
    this.route.params.subscribe((params)=>{this.orderService.getCustomerById(params['customerId']).subscribe((result)=>{this.customer=result;})});
  }
  // deleteAllOrders(){
  //   this.orderService.deleteOrders().subscribe(data=>this.router.navigate(['shoppingcart']));
  // }
    deleteOrder(orderedBook:Orderedbook){
      if(window.confirm("Are your sure you want to delete the ordered book with id "+orderedBook.orderedBookId)){
      this.orderService.deleteOrder(orderedBook).subscribe(data=>{this.orderedBooks=this.orderedBooks.filter(o=>o!==orderedBook)});
   }}
  // update(){
  //   this.orderService.getOrders().subscribe(data=>{this.orders=data});
  // }
  checkout(){
    this.orderService.getAllOrderedBooks().subscribe(data=>{this.router.navigate(['/checkout'])});
  }
}
